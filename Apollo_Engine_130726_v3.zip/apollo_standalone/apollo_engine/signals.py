"""
Signal implementations for the Apollo Analysis Engine.

All 19 signals across 5 pools are implemented as standalone functions.
Each function returns (points_earned: int, is_fired: bool).

Pool A  - RSI Recovery (42 pts max)       : A1-A6
Pool B  - Price Structure (25 pts max)    : B1-B5
Pool C  - Multi-TF Confirmation (18 pts)  : C1-C4
Bonus A - Volume & Support (8 pts max)    : BA1-BA3
Bonus B - Uptrend Context (10 pts max)    : BB1-BB3
"""

import numpy as np
import pandas as pd

from apollo_engine.indicators import (
    compute_rsi,
    compute_tp28,
    compute_wc50,
    detect_trough_rsi,
)


def _graded(threshold: float, value: float, max_pts: float,
             buffer_lo: float, buffer_hi: float) -> tuple:
    """
    Graded scoring with linear interpolation in a buffer zone.

    Zones:
        value <= buffer_lo        → 0 pts (clearly below)
        buffer_lo < value < buffer_hi → linear 0..max_pts
        value >= buffer_hi       → max_pts (clearly above)

    Returns (points_earned: float, is_fired: bool).
    """
    if np.isnan(value):
        return (0.0, False)
    if value >= buffer_hi:
        return (max_pts, True)
    if value <= buffer_lo:
        return (0.0, False)
    # Linear interpolation within the buffer
    ratio = (value - buffer_lo) / (buffer_hi - buffer_lo)
    pts = round(max_pts * ratio, 2)
    fired = pts > 0
    return (pts, fired)


# ---------------------------------------------------------------------------
# Pool A — RSI Recovery | 42 pts
# ---------------------------------------------------------------------------

def signal_a1(df_daily: pd.DataFrame, rsi21_d: pd.Series, idx: int) -> tuple:
    """
    A1 — Trough Detected (Daily) | 10 pts

    Condition: RSI21 <= 40 at the daily trough, and the trough is an 11-bar
    local minimum (5 bars each side).

    Returns the most recent trough bar index and checks if it exists.
    """
    troughs = detect_trough_rsi(rsi21_d, rsi_threshold=40.0, window=11)
    trough_indices = troughs[troughs].index

    if len(trough_indices) == 0 or idx < trough_indices.get_loc(trough_indices[0]):
        return (0, False)

    # Most recent trough on or before idx
    valid = trough_indices[trough_indices <= df_daily.index[idx]]
    if len(valid) == 0:
        return (0, False)

    latest_trough_idx = valid[-1]
    trough_rsi = rsi21_d.loc[latest_trough_idx]
    return (10, True) if not np.isnan(trough_rsi) else (0, False)


def signal_a2(df_4h: pd.DataFrame, rsi21_4h: pd.Series, idx: int) -> tuple:
    """
    A2 — Trough Detected (4H) | 8 pts

    Condition: RSI21 <= 38 at the 4H trough, and the trough is a 5-bar
    local minimum (2 bars each side).
    """
    troughs = detect_trough_rsi(rsi21_4h, rsi_threshold=38.0, window=5)
    trough_indices = troughs[troughs].index

    if len(trough_indices) == 0 or idx < trough_indices.get_loc(trough_indices[0]):
        return (0, False)

    valid = trough_indices[trough_indices <= df_4h.index[idx]]
    if len(valid) == 0:
        return (0, False)

    latest_trough_idx = valid[-1]
    trough_rsi = rsi21_4h.loc[latest_trough_idx]
    return (8, True) if not np.isnan(trough_rsi) else (0, False)


def signal_a3(
    rsi21_d: pd.Series, idx: int, trough_loc: int
) -> tuple:
    """
    A3 — Recovery Momentum (Daily) | 8 pts

    Condition: RSI21 gained >= 8 points from the Daily trough within <= 10 bars.
    """
    if trough_loc is None or np.isnan(rsi21_d.iloc[trough_loc]):
        return (0, False)

    trough_val = rsi21_d.iloc[trough_loc]
    current_val = rsi21_d.iloc[idx]
    bars_since = idx - trough_loc

    if bars_since <= 0 or bars_since > 10:
        return (0, False)

    gain = current_val - trough_val
    return (8, True) if gain >= 8.0 else (0, False)


def signal_a4(
    rsi21_4h: pd.Series, df_4h: pd.DataFrame, idx: int, trough_loc: int
) -> tuple:
    """
    A4 — Recovery Momentum (4H) | 6 pts

    Condition: RSI21 gained >= 10 points from the 4H trough within <= 12 bars.
    """
    if trough_loc is None or np.isnan(rsi21_4h.iloc[trough_loc]):
        return (0, False)

    trough_val = rsi21_4h.iloc[trough_loc]
    current_val = rsi21_4h.iloc[idx]
    bars_since = idx - trough_loc

    if bars_since <= 0 or bars_since > 12:
        return (0, False)

    gain = current_val - trough_val
    return (6, True) if gain >= 10.0 else (0, False)


def signal_a5(rsi21_4h: pd.Series, idx: int) -> tuple:
    """
    A5 — RSI21 Above 50 (4H) | 6 pts (graded)

    Graded buffer zone:
        4H-RSI21 <= 45   → 0 pts
        4H-RSI21  45–55  → linear 0–6 pts
        4H-RSI21 >= 55   → 6 pts
    """
    val = rsi21_4h.iloc[idx]
    if np.isnan(val):
        return (0.0, False)
    return _graded(threshold=50.0, value=val, max_pts=6.0,
                   buffer_lo=45.0, buffer_hi=55.0)


def signal_a6(rsi21_d: pd.Series, rsi36_d: pd.Series, idx: int) -> tuple:
    """
    A6 — Multi-Speed Alignment (Daily) | 4 pts (graded)

    Graded buffer zone (based on RSI21 - RSI36 spread):
        spread <= -2   → 0 pts
        spread  -2 to +2 → linear 0–4 pts
        spread >= +2   → 4 pts
    """
    v21 = rsi21_d.iloc[idx]
    v36 = rsi36_d.iloc[idx]
    if np.isnan(v21) or np.isnan(v36):
        return (0.0, False)
    spread = v21 - v36
    return _graded(threshold=0.0, value=spread, max_pts=4.0,
                   buffer_lo=-2.0, buffer_hi=2.0)


# ---------------------------------------------------------------------------
# Pool B — Price Structure | 25 pts
# ---------------------------------------------------------------------------

def signal_b1(df_4h: pd.DataFrame, tp28_4h: pd.Series, idx: int) -> tuple:
    """
    B1 — Close > TP28 (4H) | 7 pts (graded)

    Graded buffer zone (based on % distance from TP28):
        close <= tp28 * 0.98   → 0 pts
        close  0.98x–1.01x TP28 → linear 0–7 pts
        close >= tp28 * 1.01   → 7 pts
    """
    close = df_4h["close"].iloc[idx]
    tp = tp28_4h.iloc[idx]
    if np.isnan(tp):
        return (0.0, False)
    pct_above = (close - tp) / tp * 100.0  # percentage distance
    return _graded(threshold=0.0, value=pct_above, max_pts=7.0,
                   buffer_lo=-2.0, buffer_hi=1.0)


def signal_b2(df_4h: pd.DataFrame, wc50_4h: pd.Series, idx: int) -> tuple:
    """
    B2 — Close > WC50 (4H) | 6 pts (graded)

    Graded buffer zone (based on % distance from WC50):
        close <= wc50 * 0.98   → 0 pts
        close  0.98x–1.01x WC50 → linear 0–6 pts
        close >= wc50 * 1.01   → 6 pts
    """
    close = df_4h["close"].iloc[idx]
    wc = wc50_4h.iloc[idx]
    if np.isnan(wc):
        return (0.0, False)
    pct_above = (close - wc) / wc * 100.0
    return _graded(threshold=0.0, value=pct_above, max_pts=6.0,
                   buffer_lo=-2.0, buffer_hi=1.0)


def signal_b3(df_daily: pd.DataFrame, tp28_d: pd.Series, idx: int) -> tuple:
    """
    B3 — Approaching D-TP28 (Daily) | 5 pts

    Condition: D-Close is within 3% below D-TP28.
    i.e., close >= tp28 * 0.97 and close < tp28
    """
    close = df_daily["close"].iloc[idx]
    tp = tp28_d.iloc[idx]
    if np.isnan(tp):
        return (0, False)
    if close < tp and close >= tp * 0.97:
        return (5, True)
    return (0, False)


def signal_b4(
    df_daily: pd.DataFrame, idx: int, daily_trough_low: float
) -> tuple:
    """
    B4 — Higher Low Forming (Daily) | 4 pts

    Condition: Current bar's Low > previous trough's Low.
    """
    current_low = df_daily["low"].iloc[idx]
    if daily_trough_low is None or np.isnan(daily_trough_low):
        return (0, False)
    return (4, True) if current_low > daily_trough_low else (0, False)


def signal_b5(df_daily: pd.DataFrame, idx: int, trough_low: float) -> tuple:
    """
    B5 — Price Above Trough + 10% (Daily) | 3 pts

    Condition: Close > Trough Low * 1.10
    """
    close = df_daily["close"].iloc[idx]
    if trough_low is None or np.isnan(trough_low):
        return (0, False)
    return (3, True) if close > trough_low * 1.10 else (0, False)


# ---------------------------------------------------------------------------
# Pool C — Multi-TF Confirmation | 18 pts
# ---------------------------------------------------------------------------

def signal_c1(
    daily_trough_date, fourh_trough_date, max_bar_gap: int = 3,
    df_daily: pd.DataFrame = None,
) -> tuple:
    """
    C1 — Cross-TF Trough Agreement | 6 pts

    Condition: Daily and 4H troughs occurred within `max_bar_gap` daily
    trading bars of each other.

    If df_daily is provided, counts actual trading bars between the two
    dates (handles weekends/holidays correctly). Otherwise falls back to
    calendar-day comparison with a宽容 buffer (+2 days) to roughly
    account for non-trading days.
    """
    if daily_trough_date is None or fourh_trough_date is None:
        return (0, False)

    # Normalize both to date (strip time from 4H timestamp)
    fourh_date = pd.Timestamp(fourh_trough_date).date()
    daily_date = pd.Timestamp(daily_trough_date).date()

    if df_daily is not None and isinstance(df_daily.index, pd.DatetimeIndex):
        # Count trading bars BETWEEN the two dates (exclusive of endpoints).
        # Same day → 0 bars gap. Adjacent days → 0 bars between.
        # "Within 3 bars" means at most 3 intervening trading bars.
        earlier = min(fourh_date, daily_date)
        later = max(fourh_date, daily_date)
        mask = (df_daily.index.date > earlier) & (df_daily.index.date < later)
        trading_bars = int(mask.sum())
        return (6, True) if trading_bars <= max_bar_gap else (0, False)
    else:
        # Fallback: calendar days with buffer for weekends
        gap_days = abs((daily_date - fourh_date).days)
        return (6, True) if gap_days <= (max_bar_gap + 2) else (0, False)


def signal_c2(rsi36_4h: pd.Series, idx: int) -> tuple:
    """
    C2 — 4H RSI36 > 45 | 4 pts (graded)

    Graded buffer zone:
        4H-RSI36 <= 40   → 0 pts
        4H-RSI36  40–50  → linear 0–4 pts
        4H-RSI36 >= 50   → 4 pts
    """
    val = rsi36_4h.iloc[idx]
    if np.isnan(val):
        return (0.0, False)
    return _graded(threshold=45.0, value=val, max_pts=4.0,
                   buffer_lo=40.0, buffer_hi=50.0)


def signal_c3(rsi56_w: pd.Series, idx: int) -> tuple:
    """
    C3 — W-RSI56 > 50 (previous completed week) | 4 pts

    Condition: Last completed weekly bar's RSI56 > 50.
    Uses the weekly bar BEFORE the current evaluation point.
    """
    if idx < 1:
        return (0, False)
    # Use the previous weekly bar
    prev_w_rsi56 = rsi56_w.iloc[idx - 1]
    if np.isnan(prev_w_rsi56):
        return (0, False)
    return (4, True) if prev_w_rsi56 > 50.0 else (0, False)


def signal_c4(rsi21_d: pd.Series, idx: int) -> tuple:
    """
    C4 — D-RSI21 > 45 | 4 pts (graded)

    Graded buffer zone:
        D-RSI21 <= 40   → 0 pts
        D-RSI21  40–50  → linear 0–4 pts
        D-RSI21 >= 50   → 4 pts
    """
    val = rsi21_d.iloc[idx]
    if np.isnan(val):
        return (0.0, False)
    return _graded(threshold=45.0, value=val, max_pts=4.0,
                   buffer_lo=40.0, buffer_hi=50.0)


# ---------------------------------------------------------------------------
# Bonus A — Volume and Support | 8 pts
# ---------------------------------------------------------------------------

def signal_ba1(df_daily: pd.DataFrame, daily_trough_idx: int, idx: int) -> tuple:
    """
    BA1 — Selling Exhaustion | 3 pts

    Condition: Volume on the trough day < 30-day average volume.
    """
    if daily_trough_idx is None:
        return (0, False)

    trough_vol = df_daily["volume"].iloc[daily_trough_idx]
    # 30-day average ending before the trough day
    if daily_trough_idx < 30:
        return (0, False)

    avg_vol = df_daily["volume"].iloc[daily_trough_idx - 30 : daily_trough_idx].mean()
    if np.isnan(avg_vol) or np.isnan(trough_vol):
        return (0, False)
    return (3, True) if trough_vol < avg_vol else (0, False)


def signal_ba2(df_daily: pd.DataFrame, idx: int, trough_low: float) -> tuple:
    """
    BA2 — Price Holding Above Trough + 10% | 3 pts

    Condition: Close > Trough Low * 1.10.
    (Note: This is structurally identical to B5 but scored in the bonus pool.)
    """
    close = df_daily["close"].iloc[idx]
    if trough_low is None or np.isnan(trough_low):
        return (0, False)
    return (3, True) if close > trough_low * 1.10 else (0, False)


def signal_ba3(df_4h: pd.DataFrame, idx: int) -> tuple:
    """
    BA3 — 4H Volume Expansion on Recovery | 2 pts

    Condition: Any 4H bar in the last 3 days has volume > 1.5x the 20-bar
    average volume. "3 days" = 18 bars on 4H chart (6 bars/day).
    """
    bars_to_check = 18  # 3 days * 6 bars/day on 4H
    start = max(0, idx - bars_to_check)

    if idx < 20:
        return (0, False)

    avg_20 = df_4h["volume"].iloc[idx - 20 : idx].mean()
    if np.isnan(avg_20) or avg_20 == 0:
        return (0, False)

    recent_vols = df_4h["volume"].iloc[start : idx + 1]
    for vol in recent_vols:
        if not np.isnan(vol) and vol > avg_20 * 1.5:
            return (2, True)
    return (0, False)


# ---------------------------------------------------------------------------
# Bonus B — Uptrend Correction Context | 10 pts
# ---------------------------------------------------------------------------

def signal_bb1(df_daily: pd.DataFrame, idx: int) -> tuple:
    """
    BB1 — 52-Week High > Current * 1.5 | 3 pts

    Condition: The 52-week high (rolling 252 bars) > current close * 1.5.
    """
    lookback = min(252, idx)
    if lookback < 20:
        return (0, False)

    high_52w = df_daily["high"].iloc[idx - lookback : idx + 1].max()
    current_close = df_daily["close"].iloc[idx]
    return (3, True) if high_52w > current_close * 1.5 else (0, False)


def signal_bb2(
    df_daily: pd.DataFrame, idx: int, support_low: float, support_high: float
) -> tuple:
    """
    BB2 — Multi-Touch of Support Zone | 4 pts

    Condition: 2nd or subsequent touch of the support zone [support_low,
    support_high] in the lookback period (252 bars). A "touch" means the
    bar's low entered the zone.

    If support_low and support_high are None, auto-detects the support zone
    from recent trough lows.
    """
    lookback = min(252, idx)
    if lookback < 30:
        return (0, False)

    window = df_daily.iloc[idx - lookback : idx + 1]
    lows = window["low"]

    # Auto-detect support zone if not provided
    if support_low is None or support_high is None:
        # Find trough lows (local minima in a 21-bar window)
        rolling_min = lows.rolling(window=21, center=True, min_periods=21).min()
        trough_mask = lows == rolling_min
        trough_lows = lows[trough_mask].dropna()
        if len(trough_lows) < 2:
            return (0, False)
        support_low = trough_lows.min()
        support_high = support_low + (trough_lows.max() - trough_lows.min()) * 0.3
    else:
        if np.isnan(support_low) or np.isnan(support_high):
            return (0, False)

    # Count touches: bars where low is within the support zone
    touches = lows[(lows >= support_low) & (lows <= support_high)]
    return (4, True) if len(touches) >= 2 else (0, False)


def signal_bb3(rsi21_w: pd.Series, rsi56_w: pd.Series, idx: int) -> tuple:
    """
    BB3 — Weekly RSI21 > RSI56 Reversal Setup | 3 pts

    Condition: W-RSI21 had dropped below W-RSI56 but is now rising
    (i.e., W-RSI21 > W-RSI56 on the current weekly bar).
    """
    if idx < 5:
        return (0, False)

    current_rsi21 = rsi21_w.iloc[idx]
    current_rsi56 = rsi56_w.iloc[idx]

    if np.isnan(current_rsi21) or np.isnan(current_rsi56):
        return (0, False)

    # Check that W-RSI21 was below W-RSI56 at some point in the last 12 weeks
    past_21 = rsi21_w.iloc[max(0, idx - 12) : idx]
    past_56 = rsi56_w.iloc[max(0, idx - 12) : idx]

    was_below = False
    for p21, p56 in zip(past_21, past_56):
        if not np.isnan(p21) and not np.isnan(p56) and p21 < p56:
            was_below = True
            break

    # Must have been below before, and now is above
    if was_below and current_rsi21 > current_rsi56:
        return (3, True)
    return (0, False)