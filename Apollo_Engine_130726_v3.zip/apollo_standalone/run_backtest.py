#!/usr/bin/env python3
"""
Apollo Scout Engine - Standalone Backtest Runner

Usage:
    python run_backtest.py                  # Run backtest, save report to ./output/
    python run_backtest.py --output ./      # Custom output directory
    APOLLO_OUTPUT_DIR=/path python run_backtest.py  # Env var override

Requires: pip install pandas numpy openpyxl
"""

import sys
import os
import numpy as np
from datetime import datetime

# Ensure this directory is on the path so apollo_engine and templates resolve
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)

from apollo_backtest import load_apollo_data, run_backtest, extract_trades
from apollo_backtest import extract_trough_cycles, generate_report


def main():
    # Resolve output directory
    default_output = os.path.join(_SCRIPT_DIR, "output")
    output_dir = os.environ.get("APOLLO_OUTPUT_DIR", default_output)
    os.makedirs(output_dir, exist_ok=True)

    # Look for data in ./data/APOLLO/ (relative to this script)
    data_dir = os.path.join(_SCRIPT_DIR, "data", "APOLLO")
    if not os.path.isdir(data_dir):
        data_dir = os.path.join(os.getcwd(), "data", "APOLLO")
    if not os.path.isdir(data_dir):
        print(f"ERROR: Data directory not found.")
        print(f"       Expected: {os.path.join(_SCRIPT_DIR, 'data', 'APOLLO')}")
        sys.exit(1)

    print("Loading APOLLO data...")
    df_d, df_4h, df_w = load_apollo_data(base_dir=data_dir)
    print(f"Daily:   {len(df_d)} bars ({df_d.index[0].date()} to {df_d.index[-1].date()})")
    print(f"4H:      {len(df_4h)} bars ({df_4h.index[0].date()} to {df_4h.index[-1].date()})")
    print(f"Weekly:  {len(df_w)} bars ({df_w.index[0].date()} to {df_w.index[-1].date()})")

    print("\nRunning backtest (this may take a moment)...")
    results = run_backtest(df_d, df_4h, df_w, start_date="2025-01-01")
    print(f"Scored {len(results)} trading days")

    if not results:
        print("ERROR: No results.")
        sys.exit(1)

    print("Extracting trades...")
    trades, trade_events = extract_trades(results)
    print(f"  Completed trades: {len(trades)}, Events: {len(trade_events)}")

    print("Extracting trough cycles...")
    trough_cycles = extract_trough_cycles(df_d, df_4h, results)
    print(f"  Trough cycles: {len(trough_cycles)}")

    scores = [r["total_score"] for r in results]
    print(f"\n--- Quick Summary ---")
    print(f"Avg Score: {np.mean(scores):.1f} | Peak: {max(scores)} | Median: {np.median(scores):.0f}")
    print(f"Price: {results[0]['close']:.2f} -> {results[-1]['close']:.2f} ({(results[-1]['close']/results[0]['close']-1)*100:.1f}%)")
    print(f"Trades: {len(trades)} | Wins: {len([t for t in trades if t['pnl_pct']>0])} | Losses: {len([t for t in trades if t['pnl_pct']<=0])}")
    if trades:
        print(f"Cumulative P&L: {sum(t['pnl_pct'] for t in trades):.1f}%")

    # Auto-version: {ENGINE_NAME}_BT_{ddmmyy}_v{N}.xlsx
    engine_name = "Apollo_Engine"
    date_tag = datetime.now().strftime("%d%m%y")
    prefix = f"{engine_name}_BT_{date_tag}"
    ver = 1
    while os.path.exists(os.path.join(output_dir, f"{prefix}_v{ver}.xlsx")):
        ver += 1
    output_path = os.path.join(output_dir, f"{prefix}_v{ver}.xlsx")

    print(f"\nGenerating XLSX report ({prefix}_v{ver})...")
    generate_report(results, trades, trade_events, trough_cycles, df_d, output_path)
    print(f"\nDone! Saved: {output_path}")


if __name__ == "__main__":
    main()