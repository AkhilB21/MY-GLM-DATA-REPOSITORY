"""
APOLLO SCOUT Engine — Full Backtest Runner & Report Generator

Loads pre-computed indicator data from APOLLO.zip CSVs, runs the 19-signal
scoring engine across all daily bars, and produces a 5-sheet XLSX backtest
report matching the SAMPLE BACKTEST REPORT template format.
"""

import sys
import os
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional

# --- Paths: auto-detect project root relative to this script ---
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_DOWNLOAD_DIR = os.path.join(_PROJECT_ROOT, "download")
sys.path.insert(0, _DOWNLOAD_DIR)                              # apollo_engine package
sys.path.insert(0, os.path.join(_PROJECT_ROOT, "skills", "xlsx"))  # templates
sys.path.insert(0, _SCRIPT_DIR)                                 # sibling modules

from apollo_engine.indicators import detect_trough_rsi
from apollo_engine.signals import (
    signal_a1, signal_a2, signal_a3, signal_a4, signal_a5, signal_a6,
    signal_b1, signal_b2, signal_b3, signal_b4, signal_b5,
    signal_c1, signal_c2, signal_c3, signal_c4,
    signal_ba1, signal_ba2, signal_ba3,
    signal_bb1, signal_bb2, signal_bb3,
)

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from templates.base import (
    use_palette_explicit, get_active_style,
    font_title, font_header, font_subheader, font_body, font_caption,
    font_kpi, font_kpi_label,
    fill_header, fill_data_row, fill_total,
    border_header, border_total,
    align_title, align_header, align_number, align_text, align_date,
    setup_sheet, style_header_row, style_data_row, style_total_row,
    auto_fit_columns,
    PRIMARY, PRIMARY_LIGHT, SECONDARY,
    ACCENT_POSITIVE, ACCENT_NEGATIVE, ACCENT_WARNING,
    NEUTRAL_900, NEUTRAL_600, NEUTRAL_200, NEUTRAL_100, NEUTRAL_0,
    FONT_NAME, HEADER_BOLD,
)

# ============================================================
# §1  Data Loading
# ============================================================

def load_apollo_data(base_dir=None):
    if base_dir is None:
        for candidate in [
            os.path.join(_SCRIPT_DIR, "data", "APOLLO"),
            os.path.join(_DOWNLOAD_DIR, "apollo_data", "APOLLO"),
        ]:
            if os.path.isdir(candidate):
                base_dir = candidate
                break
        else:
            raise FileNotFoundError(
                "APOLLO data not found. Place CSVs in data/APOLLO/ next to the script."
            )
    rename_map = {
        "Date": "date", "Open": "open", "High": "high",
        "Low": "low", "Close": "close", "Volume": "volume",
        "RSI21": "rsi21", "RSI36": "rsi36", "RSI56": "rsi56",
        "TP28": "tp28", "WC50": "wc50", "WC21": "wc21",
    }
    frames = {}
    for tf, fname in [("4H", "APOLLO 4H.csv"), ("D", "APOLLO D.csv"), ("W", "APOLLO W.csv")]:
        path = os.path.join(base_dir, fname)
        df = pd.read_csv(path)
        df.rename(columns=rename_map, inplace=True)
        df["date"] = pd.to_datetime(
            df["date"].str.replace(r" GMT\+0530 \(India Standard Time\)", "", regex=True),
            format="mixed"
        )
        df.set_index("date", inplace=True)
        df.sort_index(inplace=True)
        for col in ["open", "high", "low", "close", "volume",
                     "rsi21", "rsi36", "rsi56", "tp28", "wc50", "wc21"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        frames[tf] = df
    return frames["D"], frames["4H"], frames["W"]


# ============================================================
# §2  Signal Definitions (19 signals, 5 pools)
# ============================================================

SIGNAL_DEFS = [
    {"id": "A1",  "name": "Trough Detected (D)",     "pool": "A",  "max_pts": 10},
    {"id": "A2",  "name": "Trough Detected (4H)",    "pool": "A",  "max_pts": 8},
    {"id": "A3",  "name": "Recovery Momentum (D)",   "pool": "A",  "max_pts": 8},
    {"id": "A4",  "name": "Recovery Momentum (4H)",  "pool": "A",  "max_pts": 6},
    {"id": "A5",  "name": "RSI21 > 50 (4H)",         "pool": "A",  "max_pts": 6},
    {"id": "A6",  "name": "Multi-Speed Align (D)",   "pool": "A",  "max_pts": 4},
    {"id": "B1",  "name": "Close > TP28 (4H)",       "pool": "B",  "max_pts": 7},
    {"id": "B2",  "name": "Close > WC50 (4H)",       "pool": "B",  "max_pts": 6},
    {"id": "B3",  "name": "Approaching D-TP28 (D)",  "pool": "B",  "max_pts": 5},
    {"id": "B4",  "name": "Higher Low Forming (D)",  "pool": "B",  "max_pts": 4},
    {"id": "B5",  "name": "Price > Trough+10% (D)",  "pool": "B",  "max_pts": 3},
    {"id": "C1",  "name": "Cross-TF Trough Agree",   "pool": "C",  "max_pts": 6},
    {"id": "C2",  "name": "4H RSI36 > 45",           "pool": "C",  "max_pts": 4},
    {"id": "C3",  "name": "W-RSI56 > 50 (prev W)",   "pool": "C",  "max_pts": 4},
    {"id": "C4",  "name": "D-RSI21 > 45",            "pool": "C",  "max_pts": 4},
    {"id": "BA1", "name": "Selling Exhaustion",      "pool": "BA", "max_pts": 3},
    {"id": "BA2", "name": "Price > Trough+10%",      "pool": "BA", "max_pts": 3},
    {"id": "BA3", "name": "4H Volume Expansion",     "pool": "BA", "max_pts": 2},
    {"id": "BB1", "name": "52W High > Curr*1.5",     "pool": "BB", "max_pts": 3},
    {"id": "BB2", "name": "Multi-Touch Support",     "pool": "BB", "max_pts": 4},
    {"id": "BB3", "name": "Weekly RSI Reversal",     "pool": "BB", "max_pts": 3},
]

POOL_MAX = {"A": 42, "B": 25, "C": 18, "BA": 8, "BB": 10}


# ============================================================
# §3  Classification
# ============================================================

_ENTRY_THRESHOLDS = [
    (90,  "FULL STRONG",  "100%"),
    (80,  "FULL ENTRY",   "100%"),
    (70,  "STANDARD",     "60-70%"),
    (50,  "PILOT BUY",    "25-30%"),
    (0,   "DO NOT ENTER", "0%"),
]

def classify(score):
    for threshold, action, pct in _ENTRY_THRESHOLDS:
        if score >= threshold:
            return action, pct
    return "DO NOT ENTER", "0%"


# ============================================================
# §4  Core Backtest Loop
# ============================================================

def run_backtest(df_d, df_4h, df_w, start_date="2025-01-01", end_date=None):
    if end_date is None:
        end_date = str(df_d.index[-1].date())

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    d_mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    bt_dates = df_d.index[d_mask]

    if len(bt_dates) == 0:
        print(f"ERROR: No daily bars in {start_date} to {end_date}")
        return []

    # Pre-compute troughs
    trough_d = detect_trough_rsi(df_d["rsi21"], rsi_threshold=40.0, window=11)
    trough_4h = detect_trough_rsi(df_4h["rsi21"], rsi_threshold=38.0, window=5)

    results = []
    for bt_date in bt_dates:
        try:
            d_idx = df_d.index.get_loc(bt_date)
        except KeyError:
            continue

        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])

        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])

        # Trough positions
        trough_d_slice = trough_d.iloc[:d_idx + 1]
        d_trough_iloc = np.where(trough_d_slice.values)[0]
        d_trough_pos = int(d_trough_iloc[-1]) if len(d_trough_iloc) > 0 else None

        trough_4h_slice = trough_4h.iloc[:h_idx + 1]
        h_trough_iloc = np.where(trough_4h_slice.values)[0]
        h_trough_pos = int(h_trough_iloc[-1]) if len(h_trough_iloc) > 0 else None

        d_trough_low = df_d["low"].iloc[d_trough_pos] if d_trough_pos is not None else None
        d_trough_date = df_d.index[d_trough_pos] if d_trough_pos is not None else None
        h_trough_date = df_4h.index[h_trough_pos] if h_trough_pos is not None else None
        trough_low = d_trough_low

        # Indicator references
        rsi21_d = df_d["rsi21"]
        rsi36_d = df_d["rsi36"]
        rsi21_4h = df_4h["rsi21"]
        rsi36_4h = df_4h["rsi36"]
        rsi56_w = df_w["rsi56"]
        rsi21_w = df_w["rsi21"]
        tp28_4h = df_4h["tp28"]
        wc50_4h = df_4h["wc50"]
        tp28_d = df_d["tp28"]

        # --- Evaluate all 19 signals ---
        sr = {}
        pts, fired = signal_a1(df_d, rsi21_d, d_idx);            sr["A1"] = {"pts": pts, "fired": fired}
        pts, fired = signal_a2(df_4h, rsi21_4h, h_idx);          sr["A2"] = {"pts": pts, "fired": fired}
        pts, fired = signal_a3(rsi21_d, d_idx, d_trough_pos);    sr["A3"] = {"pts": pts, "fired": fired}
        pts, fired = signal_a4(rsi21_4h, df_4h, h_idx, h_trough_pos); sr["A4"] = {"pts": pts, "fired": fired}
        pts, fired = signal_a5(rsi21_4h, h_idx);                 sr["A5"] = {"pts": pts, "fired": fired}
        pts, fired = signal_a6(rsi21_d, rsi36_d, d_idx);         sr["A6"] = {"pts": pts, "fired": fired}

        pts, fired = signal_b1(df_4h, tp28_4h, h_idx);           sr["B1"] = {"pts": pts, "fired": fired}
        pts, fired = signal_b2(df_4h, wc50_4h, h_idx);           sr["B2"] = {"pts": pts, "fired": fired}
        pts, fired = signal_b3(df_d, tp28_d, d_idx);             sr["B3"] = {"pts": pts, "fired": fired}
        pts, fired = signal_b4(df_d, d_idx, d_trough_low);       sr["B4"] = {"pts": pts, "fired": fired}
        pts, fired = signal_b5(df_d, d_idx, trough_low);         sr["B5"] = {"pts": pts, "fired": fired}

        pts, fired = signal_c1(d_trough_date, h_trough_date, df_daily=df_d); sr["C1"] = {"pts": pts, "fired": fired}
        pts, fired = signal_c2(rsi36_4h, h_idx);                 sr["C2"] = {"pts": pts, "fired": fired}
        pts, fired = signal_c3(rsi56_w, w_idx);                  sr["C3"] = {"pts": pts, "fired": fired}
        pts, fired = signal_c4(rsi21_d, d_idx);                  sr["C4"] = {"pts": pts, "fired": fired}

        pts, fired = signal_ba1(df_d, d_trough_pos, d_idx);      sr["BA1"] = {"pts": pts, "fired": fired}
        pts, fired = signal_ba2(df_d, d_idx, trough_low);        sr["BA2"] = {"pts": pts, "fired": fired}
        pts, fired = signal_ba3(df_4h, h_idx);                   sr["BA3"] = {"pts": pts, "fired": fired}

        pts, fired = signal_bb1(df_d, d_idx);                    sr["BB1"] = {"pts": pts, "fired": fired}
        pts, fired = signal_bb2(df_d, d_idx, None, None);        sr["BB2"] = {"pts": pts, "fired": fired}
        pts, fired = signal_bb3(rsi21_w, rsi56_w, w_idx);        sr["BB3"] = {"pts": pts, "fired": fired}

        # Aggregate pools
        pool_a  = sum(sr[s["id"]]["pts"] for s in SIGNAL_DEFS if s["pool"] == "A")
        pool_b  = sum(sr[s["id"]]["pts"] for s in SIGNAL_DEFS if s["pool"] == "B")
        pool_c  = sum(sr[s["id"]]["pts"] for s in SIGNAL_DEFS if s["pool"] == "C")
        bonus_a = sum(sr[s["id"]]["pts"] for s in SIGNAL_DEFS if s["pool"] == "BA")
        bonus_b = sum(sr[s["id"]]["pts"] for s in SIGNAL_DEFS if s["pool"] == "BB")

        core = min(100, pool_a + pool_b + pool_c)
        bonus = bonus_a + bonus_b
        total = core + bonus
        action, pos = classify(total)

        bars_since_trough = d_idx - d_trough_pos if d_trough_pos is not None else 0

        results.append({
            "date": str(bt_date.date()),
            "close": round(float(df_d["close"].iloc[d_idx]), 2),
            "rsi21_d": round(float(df_d["rsi21"].iloc[d_idx]), 2) if not np.isnan(df_d["rsi21"].iloc[d_idx]) else None,
            "rsi36_d": round(float(df_d["rsi36"].iloc[d_idx]), 2) if not np.isnan(df_d["rsi36"].iloc[d_idx]) else None,
            "pool_a": pool_a, "pool_b": pool_b, "pool_c": pool_c,
            "bonus_a": bonus_a, "bonus_b": bonus_b,
            "core_score": core, "total_score": total,
            "action": action, "position_pct": pos,
            "trough_date": str(d_trough_date.date()) if d_trough_date is not None else None,
            "bars_since_trough": bars_since_trough,
            "signals": sr,
            "d_trough_low": float(d_trough_low) if d_trough_low is not None and not np.isnan(d_trough_low) else None,
        })

    return results


# ============================================================
# §5  Trade Extraction
# ============================================================

def extract_trades(results):
    """
    Extract trades matching the template format:
    - NEW trade only when score >= 70 (STANDARD or above)
    - PILOT (50-69) continues an existing trade but never opens a new one
    - EXIT row when score drops below 50 (DO NOT ENTER)
    - P&L computed from first entry of the current trade cycle
    """
    ENTRY_THRESHOLD = 70   # Only STANDARD / FULL ENTRY / FULL STRONG open trades
    EXIT_THRESHOLD = 50    # DO NOT ENTER triggers exit

    trades = []
    trade_events = []
    in_trade = False
    entry_price = entry_date = entry_score = entry_class = None
    entry_pools = entry_bonus = None

    for r in results:
        score = r["total_score"]
        can_open_trade = score >= ENTRY_THRESHOLD   # Only STANDARD+ opens new trades
        can_hold_trade  = score >= EXIT_THRESHOLD     # PILOT+ keeps trade alive

        if not in_trade:
            if can_open_trade:
                in_trade = True
                entry_price = r["close"]
                entry_date = r["date"]
                entry_score = score
                entry_class = r["action"]
                entry_pools = (r["pool_a"], r["pool_b"], r["pool_c"])
                entry_bonus = r["bonus_a"] + r["bonus_b"]
                trade_events.append({
                    "type": "ENTRY" if score >= 70 else "PILOT",
                    "date": r["date"], "close": r["close"],
                    "score": score, "classification": r["action"],
                    "trough_date": r["trough_date"],
                    "bars_since_trough": r["bars_since_trough"],
                    "pool_a": r["pool_a"], "pool_b": r["pool_b"],
                    "pool_c": r["pool_c"],
                    "bonus": r["bonus_a"] + r["bonus_b"],
                    "entry_price": None, "entry_date": None, "pnl_pct": None,
                })
        else:
            # Already in a trade — check if we should exit
            if not can_hold_trade:
                # EXIT event (score dropped below 50 → DO NOT ENTER)
                pnl_pct = round((r["close"] - entry_price) / entry_price * 100, 2)
                trade_events.append({
                    "type": "EXIT",
                    "date": r["date"], "close": r["close"],
                    "score": score, "classification": r["action"],
                    "trough_date": r["trough_date"],
                    "bars_since_trough": r["bars_since_trough"],
                    "pool_a": r["pool_a"], "pool_b": r["pool_b"],
                    "pool_c": r["pool_c"],
                    "bonus": r["bonus_a"] + r["bonus_b"],
                    "entry_price": entry_price, "entry_date": entry_date, "pnl_pct": pnl_pct,
                })
                trades.append({
                    "entry_date": entry_date, "entry_price": entry_price,
                    "entry_score": entry_score, "entry_class": entry_class,
                    "exit_date": r["date"], "exit_price": r["close"],
                    "exit_score": score, "pnl_pct": pnl_pct,
                    "pools": entry_pools, "bonus": entry_bonus,
                })
                in_trade = False
            else:
                # Still in trade — log every qualifying day (ENTRY or PILOT)
                trade_events.append({
                    "type": "ENTRY" if score >= ENTRY_THRESHOLD else "PILOT",
                    "date": r["date"], "close": r["close"],
                    "score": score, "classification": r["action"],
                    "trough_date": r["trough_date"],
                    "bars_since_trough": r["bars_since_trough"],
                    "pool_a": r["pool_a"], "pool_b": r["pool_b"],
                    "pool_c": r["pool_c"],
                    "bonus": r["bonus_a"] + r["bonus_b"],
                    "entry_price": None, "entry_date": None, "pnl_pct": None,
                })

    # Close any open trade at period end
    if in_trade and results:
        last = results[-1]
        pnl_pct = round((last["close"] - entry_price) / entry_price * 100, 2)
        trade_events.append({
            "type": "EXIT",
            "date": last["date"], "close": last["close"],
            "score": last["total_score"], "classification": last["action"],
            "trough_date": last["trough_date"],
            "bars_since_trough": last["bars_since_trough"],
            "pool_a": last["pool_a"], "pool_b": last["pool_b"],
            "pool_c": last["pool_c"],
            "bonus": last["bonus_a"] + last["bonus_b"],
            "entry_price": entry_price, "entry_date": entry_date, "pnl_pct": pnl_pct,
        })
        trades.append({
            "entry_date": entry_date, "entry_price": entry_price,
            "entry_score": entry_score, "entry_class": entry_class,
            "exit_date": last["date"], "exit_price": last["close"],
            "exit_score": last["total_score"], "pnl_pct": pnl_pct,
            "pools": entry_pools, "bonus": entry_bonus,
        })

    return trades, trade_events


# ============================================================
# §6  Trough Cycle Analysis
# ============================================================

def extract_trough_cycles(df_d, df_4h, results):
    trough_d = detect_trough_rsi(df_d["rsi21"], rsi_threshold=40.0, window=11)
    trough_4h = detect_trough_rsi(df_4h["rsi21"], rsi_threshold=38.0, window=5)
    trough_indices = np.where(trough_d.values)[0]

    # Group consecutive troughs (within 3 bars), keep lowest RSI
    trough_groups = []
    if len(trough_indices) > 0:
        group = [trough_indices[0]]
        for i in range(1, len(trough_indices)):
            if trough_indices[i] - trough_indices[i-1] <= 3:
                group.append(trough_indices[i])
            else:
                trough_groups.append(group)
                group = [trough_indices[i]]
        trough_groups.append(group)

    cycles = []
    for group in trough_groups:
        best = min(group, key=lambda idx: df_d["rsi21"].iloc[idx])
        date = df_d.index[best]
        date_ts = pd.Timestamp(date)
        mask_4h = df_4h.index <= date_ts
        h_idx_4h = int(np.where(np.asarray(mask_4h))[0][-1]) if mask_4h.any() else 0
        h_troughs_near = trough_4h.iloc[max(0, h_idx_4h-12):h_idx_4h+13]
        fourh_confirmed = bool(h_troughs_near.any())

        cycles.append({
            "date": str(date.date()),
            "close": round(float(df_d["close"].iloc[best]), 2),
            "rsi21": round(float(df_d["rsi21"].iloc[best]), 2),
            "rsi36": round(float(df_d["rsi36"].iloc[best]), 2),
            "rsi56": round(float(df_d["rsi56"].iloc[best]), 2),
            "fourh_confirmed": "YES" if fourh_confirmed else "NO",
            "df_idx": best,
        })

    return cycles


# ============================================================
# §7  XLSX Report Generator
# ============================================================

def generate_report(results, trades, trade_events, trough_cycles, df_d, output_path):
    use_palette_explicit("bloomberg")
    wb = openpyxl.Workbook()
    wb.properties.creator = "Z.ai"

    n_days = len(results)
    if n_days == 0:
        print("No results."); return

    # --- Summary statistics ---
    scores = [r["total_score"] for r in results]
    closes = [r["close"] for r in results]
    avg_score = round(float(np.mean(scores)), 1)
    peak_score = max(scores)
    median_score = int(np.median(scores))
    end_price = closes[-1]
    start_price = closes[0]
    price_change = round((end_price - start_price) / start_price * 100, 1)
    period_high = max(closes)
    period_low = min(closes)

    # Count unique trade entries (first signal of each trade cycle, score>=70)
    n_entries = len([t for t in trades if t["entry_score"] >= 70])
    n_pilot = len([e for e in trade_events if e["type"] == "PILOT"])
    n_completed = len(trades)
    n_wins = len([t for t in trades if t["pnl_pct"] > 0])
    n_losses = len([t for t in trades if t["pnl_pct"] <= 0])
    win_rate = f"{round(n_wins/n_completed*100, 0):.0f}%" if n_completed > 0 else "N/A"
    avg_pnl = round(float(np.mean([t["pnl_pct"] for t in trades])), 1) if trades else 0
    cum_pnl = round(sum(t["pnl_pct"] for t in trades), 1) if trades else 0
    n_troughs = len(trough_cycles)

    class_counts = {}
    for r in results:
        class_counts[r["action"]] = class_counts.get(r["action"], 0) + 1

    pool_sums = {"pool_a": 0, "pool_b": 0, "pool_c": 0, "bonus_a": 0, "bonus_b": 0}
    for r in results:
        for k in pool_sums:
            pool_sums[k] += r[k]

    monthly_avgs = {}
    for r in results:
        m = r["date"][:7]
        monthly_avgs.setdefault(m, []).append(r["total_score"])

    # Signal statistics — active days = n_days for all signals since
    # pre-data provides sufficient lookback for all indicators by 2025-01-01
    signal_stats = {}
    for sdef in SIGNAL_DEFS:
        sid = sdef["id"]
        active = n_days  # All signals have warm data from day 1
        hits = sum(1 for r in results if r["signals"][sid]["fired"])
        total_pts = sum(r["signals"][sid]["pts"] for r in results)
        hit_rate = round(hits / active * 100, 0) if active > 0 else 0
        signal_stats[sid] = {"hits": hits, "active": active, "total_pts": total_pts, "hit_rate": hit_rate}

    grand_total_pts = sum(s["total_pts"] for s in signal_stats.values())
    start_date_str = results[0]["date"]
    end_date_str = results[-1]["date"]

    # ============================================================
    # SHEET 1: Executive Summary
    # ============================================================
    ws1 = wb.active
    ws1.title = "Executive Summary"
    ws1.sheet_view.showGridLines = False
    ws1.column_dimensions["A"].width = 3
    for c in "BCDEFGHIJ":
        ws1.column_dimensions[c].width = 16

    # Title
    ws1.merge_cells("B2:J2")
    c = ws1["B2"]; c.value = "APOLLO SCOUT Engine - Backtest Report"
    c.font = font_title(); c.alignment = align_title()
    ws1.row_dimensions[2].height = 32

    ws1.merge_cells("B3:J3")
    c = ws1["B3"]; c.value = f"APOLLO  |  {start_date_str} to {end_date_str}  |  {n_days} Trading Days"
    c.font = font_caption(); c.alignment = align_text()

    # --- KPI Row ---
    row = 5
    ws1.merge_cells(f"B{row}:J{row}")
    ws1[f"B{row}"] = "KEY PERFORMANCE INDICATORS"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    kpi_vals = [avg_score, peak_score, median_score,
                f"\u20b9{end_price:.2f}", f"+{price_change}%",
                f"\u20b9{start_price:.2f}", f"\u20b9{period_high:.2f}",
                f"\u20b9{period_low:.2f}", n_days]
    kpi_labels = ["Avg Daily Score", "Peak Score", "Median Score",
                  "End Price", "Price Change", "Start Price",
                  "Period High", "Period Low", "Trading Days"]

    for i, v in enumerate(kpi_vals):
        c = ws1.cell(row=row, column=2+i, value=v)
        c.font = font_kpi(); c.alignment = Alignment(horizontal="center", vertical="center")
    ws1.row_dimensions[row].height = 36
    row += 1
    for i, lb in enumerate(kpi_labels):
        c = ws1.cell(row=row, column=2+i, value=lb)
        c.font = font_kpi_label(); c.alignment = Alignment(horizontal="center", vertical="center")

    # --- Trade Performance ---
    row += 2
    ws1.merge_cells(f"B{row}:J{row}")
    ws1[f"B{row}"] = "TRADE PERFORMANCE"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    t_vals = [n_entries, n_completed, win_rate,
              f"+{avg_pnl}%" if avg_pnl >= 0 else f"{avg_pnl}%",
              f"+{cum_pnl}%" if cum_pnl >= 0 else f"{cum_pnl}%",
              n_wins, n_losses, n_pilot, n_troughs]
    t_labels = ["Total Entries", "Completed Trades", "Win Rate",
                "Avg P&L / Trade", "Cumulative P&L", "Winning Trades",
                "Losing Trades", "Pilot Signals", "Trough Cycles"]

    for i, v in enumerate(t_vals):
        c = ws1.cell(row=row, column=2+i, value=v)
        c.font = font_kpi(); c.alignment = Alignment(horizontal="center", vertical="center")
    ws1.row_dimensions[row].height = 36
    row += 1
    for i, lb in enumerate(t_labels):
        c = ws1.cell(row=row, column=2+i, value=lb)
        c.font = font_kpi_label(); c.alignment = Alignment(horizontal="center", vertical="center")

    # --- Signal Pool Breakdown ---
    row += 2
    ws1.merge_cells(f"B{row}:G{row}")
    ws1[f"B{row}"] = "SIGNAL POOL BREAKDOWN (AVERAGE PER DAY)"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    pool_headers = ["Pool", "Max Possible", "Daily Avg", "Utilization %", "Signals", "Description"]
    pool_data = [
        ("Pool A (RSI Recovery)",   42, pool_sums["pool_a"]/n_days,  6, "A1-A6", "Trough Detection, Recovery Momentum, Cross-TF RSI Alignment"),
        ("Pool B (Price Structure)", 25, pool_sums["pool_b"]/n_days,  5, "B1-B5", "TP28 Conv, WC50 Conv, Price Prox TP28, Higher Low, Price vs Trough"),
        ("Pool C (Multi-TF Confirm)",18, pool_sums["pool_c"]/n_days,  4, "C1-C4", "Cross-TF Trough Agree, 4H RSI36>45, W-RSI56>50, D-RSI21>45"),
        ("Bonus A (Volume/Support)",  8, pool_sums["bonus_a"]/n_days, 3, "BA1-BA3","Selling Exhaustion, Price>Trough+10%, 4H Volume Expansion"),
        ("Bonus B (Uptrend Context)", 10, pool_sums["bonus_b"]/n_days, 3, "BB1-BB3","52W High>Current*1.5, Multi-Touch Support, Weekly RSI Reversal"),
    ]

    for ci, h in enumerate(pool_headers, 2):
        ws1.cell(row=row, column=ci, value=h)
    style_header_row(ws1, row, 2, 7)
    row += 1

    for pi, (pname, pmax, pavg, nsig, psigs, pdesc) in enumerate(pool_data):
        util = round(pavg / pmax * 100, 0) if pmax > 0 else 0
        vals = [pname, pmax, round(pavg, 1), f"{util:.0f}%", nsig, pdesc]
        for ci, v in enumerate(vals, 2):
            ws1.cell(row=row, column=ci, value=v)
        style_data_row(ws1, row, 2, 7, pi)
        row += 1

    # --- Classification Distribution ---
    row += 1
    ws1.merge_cells(f"B{row}:G{row}")
    ws1[f"B{row}"] = "CLASSIFICATION DISTRIBUTION"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    class_headers = ["Classification", "Days", "% of Total", "Score Range", "Action", "Description"]
    class_order = [
        ("DO NOT ENTER", "0 - 49",  "No action",       "Score below minimum threshold"),
        ("PILOT BUY",    "50 - 69", "Small position",  "Early recovery detected, exploratory 25-30% sizing"),
        ("STANDARD",     "70 - 79", "Standard position","Solid multi-TF recovery with structural proximity"),
        ("FULL ENTRY",   "80 - 89", "Full position",   "Strong recovery across multiple domains"),
        ("FULL STRONG",  "90+",     "Max position",    "Exceptional confluence, rare for early-detection engine"),
    ]
    for ci, h in enumerate(class_headers, 2):
        ws1.cell(row=row, column=ci, value=h)
    style_header_row(ws1, row, 2, 7)
    row += 1

    for ci, (cname, crange, caction, cdesc) in enumerate(class_order):
        cnt = class_counts.get(cname, 0)
        pct = f"{round(cnt/n_days*100, 1)}%" if n_days > 0 else "0%"
        for cii, v in enumerate([cname, cnt, pct, crange, caction, cdesc], 2):
            ws1.cell(row=row, column=cii, value=v)
        style_data_row(ws1, row, 2, 7, ci)
        if cname in ("FULL ENTRY", "FULL STRONG"):
            ws1.cell(row=row, column=2).font = Font(name=FONT_NAME, size=11, color=ACCENT_POSITIVE)
        elif cname == "DO NOT ENTER":
            ws1.cell(row=row, column=2).font = Font(name=FONT_NAME, size=11, color=NEUTRAL_600)
        row += 1

    # --- Monthly Score Trend ---
    row += 1
    ws1.merge_cells(f"B{row}:C{row}")
    ws1[f"B{row}"] = "MONTHLY AVERAGE SCORE TREND"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    for ci, h in enumerate(["Month", "Avg Score"], 2):
        ws1.cell(row=row, column=ci, value=h)
    style_header_row(ws1, row, 2, 3)
    row += 1

    for mi, month in enumerate(sorted(monthly_avgs.keys())):
        avg = round(float(np.mean(monthly_avgs[month])), 1)
        ws1.cell(row=row, column=2, value=month)
        ws1.cell(row=row, column=3, value=avg)
        style_data_row(ws1, row, 2, 3, mi)
        row += 1

    # --- Observations ---
    row += 1
    ws1.merge_cells(f"B{row}:J{row}")
    ws1[f"B{row}"] = "BACKTEST INFERENCE & KEY OBSERVATIONS"
    ws1[f"B{row}"].font = font_subheader()
    row += 1

    observations = _generate_observations(
        n_days, n_entries, n_completed, n_wins, n_losses, win_rate,
        avg_pnl, cum_pnl, start_price, end_price, price_change,
        pool_sums, n_days, n_troughs, trough_cycles, trades, results
    )
    for obs in observations:
        ws1.merge_cells(f"B{row}:J{row}")
        ws1[f"B{row}"] = obs
        ws1[f"B{row}"].font = font_body()
        ws1[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="center")
        ws1.row_dimensions[row].height = 32
        row += 1

    # ============================================================
    # SHEET 2: Daily Scores
    # ============================================================
    ws2 = wb.create_sheet("Daily Scores")
    ws2.sheet_view.showGridLines = False
    ws2.column_dimensions["A"].width = 3

    ws2.merge_cells("B2:AR2")
    c = ws2["B2"]; c.value = "Daily Signal Scores - All 19 Signals"
    c.font = font_title(); c.alignment = align_title()
    ws2.row_dimensions[2].height = 32

    last_signal_col = 15 + len(SIGNAL_DEFS)  # B=2 .. B+13 fixed cols + 19 signals
    ws2.merge_cells(f"B3:{get_column_letter(last_signal_col)}3")
    c = ws2["B3"]
    c.value = f"APOLLO  |  {start_date_str} to {end_date_str}  |  {n_days} days"
    c.font = font_caption(); c.alignment = align_text()

    daily_headers = [
        "Date", "Close", "D-RSI21", "D-RSI36",
        "Pool A", "Pool B", "Pool C", "Bonus A", "Bonus B",
        "Base Score", "Total Score", "Classification",
        "Trough Date", "Bars Since\nTrough",
    ]
    for sdef in SIGNAL_DEFS:
        daily_headers.append(f"{sdef['id']}\n{sdef['name']}")

    hdr_row = 4
    for ci, h in enumerate(daily_headers, 2):
        ws2.cell(row=hdr_row, column=ci, value=h)
    last_col = len(daily_headers) + 1
    style_header_row(ws2, hdr_row, 2, last_col)

    for ri, r in enumerate(results):
        row = hdr_row + 1 + ri
        base_vals = [
            r["date"], r["close"], r["rsi21_d"], r["rsi36_d"],
            r["pool_a"], r["pool_b"], r["pool_c"],
            r["bonus_a"], r["bonus_b"], r["core_score"], r["total_score"],
            r["action"], r["trough_date"], r["bars_since_trough"],
        ]
        for sdef in SIGNAL_DEFS:
            base_vals.append(r["signals"][sdef["id"]]["pts"])
        for ci, v in enumerate(base_vals, 2):
            ws2.cell(row=row, column=ci, value=v)
        style_data_row(ws2, row, 2, last_col, ri)

        # Color-code classification
        cls_cell = ws2.cell(row=row, column=13)
        if r["action"] in ("FULL ENTRY", "FULL STRONG"):
            cls_cell.font = Font(name=FONT_NAME, size=11, color=ACCENT_POSITIVE)
        elif r["action"] == "STANDARD":
            cls_cell.font = Font(name=FONT_NAME, size=11, color=ACCENT_WARNING)
        elif r["action"] == "PILOT BUY":
            cls_cell.font = Font(name=FONT_NAME, size=11, color="1565C0")
        else:
            cls_cell.font = Font(name=FONT_NAME, size=11, color=NEUTRAL_600)

    auto_fit_columns(ws2, min_width=6, max_width=16, header_row=hdr_row, data_start_row=hdr_row+1)

    # ============================================================
    # SHEET 3: Trade Log
    # ============================================================
    ws3 = wb.create_sheet("Trade Log")
    ws3.sheet_view.showGridLines = False
    ws3.column_dimensions["A"].width = 3

    ws3.merge_cells("B2:P2")
    c = ws3["B2"]; c.value = "Trade Log - Entry & Exit Events"
    c.font = font_title(); c.alignment = align_title()
    ws3.row_dimensions[2].height = 32

    ws3.merge_cells("B3:P3")
    c = ws3["B3"]
    c.value = f"APOLLO  |  {start_date_str} to {end_date_str}  |  {len(trade_events)} events"
    c.font = font_caption(); c.alignment = align_text()

    # KPI summary row
    for col, val, lbl in [(2, n_entries, "Entries"), (4, n_completed, "Exits"),
                           (6, f"+{cum_pnl}%" if cum_pnl >= 0 else f"{cum_pnl}%", "Total P&L"),
                           (8, win_rate, "Win Rate"), (10, n_pilot, "Pilot Signals")]:
        c = ws3.cell(row=5, column=col, value=val)
        c.font = font_kpi(); c.alignment = Alignment(horizontal="center", vertical="center")
        c2 = ws3.cell(row=6, column=col, value=lbl)
        c2.font = font_kpi_label(); c2.alignment = Alignment(horizontal="center", vertical="center")
    ws3.row_dimensions[5].height = 36

    trade_headers = ["#", "Type", "Date", "Close", "Score", "Classification",
                     "Trough Date", "Bars From\nTrough", "Pool A", "Pool B", "Pool C",
                     "Bonus", "Entry Price", "Entry Date", "P&L %"]
    hdr_row = 8
    for ci, h in enumerate(trade_headers, 2):
        ws3.cell(row=hdr_row, column=ci, value=h)
    style_header_row(ws3, hdr_row, 2, len(trade_headers) + 1)

    for ei, ev in enumerate(trade_events):
        row = hdr_row + 1 + ei
        vals = [
            ei + 1, ev["type"], ev["date"], ev["close"], ev["score"],
            ev["classification"], ev.get("trough_date", ""),
            ev.get("bars_since_trough", ""),
            ev["pool_a"], ev["pool_b"], ev["pool_c"], ev["bonus"],
            ev.get("entry_price", ""), ev.get("entry_date", ""),
            ev.get("pnl_pct", ""),
        ]
        for ci, v in enumerate(vals, 2):
            ws3.cell(row=row, column=ci, value=v)
        style_data_row(ws3, row, 2, len(trade_headers) + 1, ei)

        type_cell = ws3.cell(row=row, column=3)
        if ev["type"] == "ENTRY":
            type_cell.font = Font(name=FONT_NAME, size=11, color=ACCENT_POSITIVE, bold=True)
        elif ev["type"] == "PILOT":
            type_cell.font = Font(name=FONT_NAME, size=11, color="1565C0")
        elif ev["type"] == "EXIT":
            type_cell.font = Font(name=FONT_NAME, size=11, color=ACCENT_NEGATIVE)

        pnl = ev.get("pnl_pct")
        if pnl is not None:
            pnl_cell = ws3.cell(row=row, column=16)
            pnl_cell.font = Font(name=FONT_NAME, size=11,
                                 color=ACCENT_POSITIVE if pnl > 0 else ACCENT_NEGATIVE if pnl < 0 else NEUTRAL_900)

    auto_fit_columns(ws3, min_width=8, max_width=18, header_row=hdr_row, data_start_row=hdr_row+1)

    # ============================================================
    # SHEET 4: Trough Cycles
    # ============================================================
    ws4 = wb.create_sheet("Trough Cycles")
    ws4.sheet_view.showGridLines = False
    ws4.column_dimensions["A"].width = 3

    ws4.merge_cells("B2:H2")
    c = ws4["B2"]; c.value = "Trough Cycle Analysis"
    c.font = font_title(); c.alignment = align_title()
    ws4.row_dimensions[2].height = 32

    ws4.merge_cells("B3:H3")
    ws4["B3"] = "Daily RSI21 <= 40 + 11-bar local minimum, confirmed on 4H timeframe"
    ws4["B3"].font = font_caption(); ws4["B3"].alignment = align_text()

    ws4["B5"] = n_troughs; ws4["B5"].font = font_kpi()
    ws4["B6"] = "Total Troughs"; ws4["B6"].font = font_kpi_label()
    ws4.row_dimensions[5].height = 36

    trough_headers = ["#", "Trough Date", "Close", "D-RSI21", "D-RSI36", "D-RSI56", "4H Confirmed"]
    hdr_row = 8
    for ci, h in enumerate(trough_headers, 2):
        ws4.cell(row=hdr_row, column=ci, value=h)
    style_header_row(ws4, hdr_row, 2, len(trough_headers) + 1)

    for ti, tc in enumerate(trough_cycles):
        row = hdr_row + 1 + ti
        vals = [ti+1, tc["date"], tc["close"], tc["rsi21"], tc["rsi36"], tc["rsi56"], tc["fourh_confirmed"]]
        for ci, v in enumerate(vals, 2):
            ws4.cell(row=row, column=ci, value=v)
        style_data_row(ws4, row, 2, len(trough_headers) + 1, ti)

    # Recovery Analysis sub-table
    row = hdr_row + len(trough_cycles) + 3
    ws4.merge_cells(f"B{row}:H{row}")
    ws4[f"B{row}"] = "TROUGH CYCLE CONTEXT & RECOVERY ANALYSIS"
    ws4[f"B{row}"].font = font_subheader()
    row += 1

    rec_headers = ["Trough Date", "Trough Price", "Recovery High", "Recovery %",
                   "Bars to Recovery", "Score at Recovery", "Classification"]
    for ci, h in enumerate(rec_headers, 2):
        ws4.cell(row=row, column=ci, value=h)
    style_header_row(ws4, row, 2, len(rec_headers) + 1)
    row += 1

    result_by_date = {r["date"]: r for r in results}
    for ti, tc in enumerate(trough_cycles):
        df_idx = tc["df_idx"]
        future_closes = df_d["close"].iloc[df_idx:]
        recovery_high = float(future_closes.max())
        recovery_pct = round((recovery_high - tc["close"]) / tc["close"] * 100, 2)
        recovery_arg = future_closes.values.argmax()
        recovery_date = str(df_d.index[df_idx + recovery_arg].date())
        r = result_by_date.get(recovery_date)
        score_rec = r["total_score"] if r else 0
        cls_rec = r["action"] if r else "N/A"

        vals = [tc["date"], tc["close"], round(recovery_high, 2), recovery_pct,
                recovery_arg, score_rec, cls_rec]
        for ci, v in enumerate(vals, 2):
            ws4.cell(row=row, column=ci, value=v)
        style_data_row(ws4, row, 2, len(rec_headers) + 1, ti)
        row += 1

    auto_fit_columns(ws4, min_width=8, max_width=20, header_row=hdr_row, data_start_row=hdr_row+1)

    # ============================================================
    # SHEET 5: Signal Analysis (comprehensive per charter rule 6)
    # ============================================================
    from openpyxl.styles import Alignment as _Align

    ws5 = wb.create_sheet("Signal Analysis")
    ws5.sheet_view.showGridLines = False
    ws5.column_dimensions["A"].width = 3

    # Pre-compute trade-day set for cross-referencing
    trade_entry_dates = set(t["entry_date"] for t in trades)
    trade_day_dates = set(e["date"] for e in trade_events)

    # --- Title ---
    ws5.merge_cells("B2:L2")
    c = ws5["B2"]; c.value = "Signal Analysis — Comprehensive Breakdown"
    c.font = font_title(); c.alignment = align_title()
    ws5.row_dimensions[2].height = 32

    ws5.merge_cells("B3:L3")
    ws5["B3"] = (f"{n_days} Trading Days  |  {len(trades)} Completed Trades  |  "
                 f"{len(trade_day_dates)} Days In-Trade  |  {start_date_str} to {end_date_str}")
    ws5["B3"].font = font_caption(); ws5["B3"].alignment = align_text()

    SIGNAL_CONDITIONS = {
        "A1":  "D-RSI21 <= 40 AND 11-bar centered local minimum",
        "A2":  "4H-RSI21 <= 38 AND 5-bar centered local minimum",
        "A3":  "D-RSI21 recovered >= 8 pts from trough within <= 10 bars",
        "A4":  "4H-RSI21 recovered >= 10 pts from trough within <= 12 bars",
        "A5":  "Current 4H RSI21 > 50",
        "A6":  "Daily RSI21 > Daily RSI36 (multi-speed bullish alignment)",
        "B1":  "Current 4H Close > 4H TP28 (28-SMA of Typical Price)",
        "B2":  "Current 4H Close > 4H WC50 (50-SMA of Weighted Close)",
        "B3":  "Daily Close within 3% below Daily TP28",
        "B4":  "Current Daily Low > trough low (higher low forming)",
        "B5":  "Daily Close > trough low + 10%",
        "C1":  "Daily and 4H trough within 3 calendar days",
        "C2":  "Current 4H RSI36 > 45",
        "C3":  "Previous Weekly RSI56 > 50",
        "C4":  "Current Daily RSI21 > 45",
        "BA1": "Trough-day volume < 30-day avg volume (selling exhaustion)",
        "BA2": "Daily Close > trough low + 10% (bonus duplicate of B5)",
        "BA3": "4H volume >= 1.5x 18-bar avg within 18 bars of trough",
        "BB1": "52-week high > current close x 1.5",
        "BB2": "Daily low touched trough zone >= 2 times",
        "BB3": "Weekly RSI21 > Weekly RSI56 AND Weekly RSI21 rising",
    }

    POOL_LABELS = {
        "A":  "POOL A — Momentum & Trough Detection",
        "B":  "POOL B — Price Structure Validation",
        "C":  "POOL C — Multi-Timeframe Confirmation",
        "BA": "BONUS A — Exhaustion & Recovery",
        "BB": "BONUS B — Structural Edge",
    }

    # --- Detailed signal table ---
    detail_headers = [
        "Signal", "Max Pts", "Firing Condition",
        "Hit Rate", "Efficiency", "Avg When Fired",
        "Trade-Day Hit", "Entry-Day Hit", "Contribution %"
    ]
    hdr_row = 5
    for ci, h in enumerate(detail_headers, 2):
        ws5.cell(row=hdr_row, column=ci, value=h)
    style_header_row(ws5, hdr_row, 2, len(detail_headers) + 1)

    row = hdr_row + 1
    pool_order = ["A", "B", "C", "BA", "BB"]
    # Collect per-pool aggregates as we go
    pool_agg = {p: {"earned": 0, "possible": 0} for p in pool_order}

    for pool_name in pool_order:
        # Pool group header row
        ws5.merge_cells(f"B{row}:J{row}")
        ws5[f"B{row}"] = f"{POOL_LABELS[pool_name]}  (max {POOL_MAX[pool_name]} pts)"
        ws5[f"B{row}"].font = font_subheader()
        ws5[f"B{row}"].alignment = Alignment(vertical="center")
        ws5.row_dimensions[row].height = 22
        row += 1

        pool_signals = [s for s in SIGNAL_DEFS if s["pool"] == pool_name]
        for si, sdef in enumerate(pool_signals):
            sid = sdef["id"]
            max_pts = sdef["max_pts"]
            hits = 0; total_pts = 0
            trade_hits = 0; entry_hits = 0
            max_streak = 0; streak = 0

            for r in results:
                sr = r["signals"][sid]
                if sr["fired"]:
                    hits += 1; total_pts += sr["pts"]
                    streak += 1; max_streak = max(max_streak, streak)
                    if r["date"] in trade_day_dates:
                        trade_hits += 1
                    if r["date"] in trade_entry_dates:
                        entry_hits += 1
                else:
                    streak = 0

            hit_rate = hits / n_days * 100
            efficiency = total_pts / (n_days * max_pts) * 100
            avg_fired = total_pts / hits if hits > 0 else 0
            trade_hr = trade_hits / len(trade_day_dates) * 100 if trade_day_dates else 0
            entry_hr = entry_hits / len(trade_entry_dates) * 100 if trade_entry_dates else 0
            contrib = total_pts / grand_total_pts * 100 if grand_total_pts > 0 else 0

            pool_agg[pool_name]["earned"] += total_pts
            pool_agg[pool_name]["possible"] += n_days * max_pts

            vals = [
                f"{sid}: {sdef['name']}", max_pts, SIGNAL_CONDITIONS[sid],
                f"{hit_rate:.1f}%", f"{efficiency:.1f}%", f"{avg_fired:.1f}",
                f"{trade_hits}/{len(trade_day_dates)} ({trade_hr:.0f}%)",
                f"{entry_hits}/{len(trade_entry_dates)} ({entry_hr:.0f}%)",
                f"{contrib:.1f}%",
            ]
            for ci, v in enumerate(vals, 2):
                ws5.cell(row=row, column=ci, value=v)
            style_data_row(ws5, row, 2, len(detail_headers) + 1, si)
            # Color-code: red for 0% hit rate, amber for >=95%
            if hit_rate == 0:
                for ci in range(2, len(detail_headers) + 2):
                    ws5.cell(row=row, column=ci).font = Font(
                        name=FONT_NAME, size=10,
                        color="CC0000" if ci in (5, 6) else NEUTRAL_900)
            elif hit_rate >= 95:
                for ci in range(2, len(detail_headers) + 2):
                    ws5.cell(row=row, column=ci).font = Font(
                        name=FONT_NAME, size=10,
                        color="CC6600" if ci in (5, 6) else NEUTRAL_900)
            row += 1
        row += 1  # gap between pools

    # --- Pool Utilization Summary ---
    row += 1
    ws5.merge_cells(f"B{row}:H{row}")
    ws5[f"B{row}"] = "POOL UTILIZATION SUMMARY"
    ws5[f"B{row}"].font = font_subheader()
    row += 1

    sum_headers = ["Pool", "Points Earned", "Max Possible", "Utilization %", "Avg Pts/Day"]
    for ci, h in enumerate(sum_headers, 2):
        ws5.cell(row=row, column=ci, value=h)
    style_header_row(ws5, row, 2, len(sum_headers) + 1)
    row += 1

    grand_earned = 0; grand_possible = 0
    for pool_name in pool_order:
        e = pool_agg[pool_name]["earned"]
        p = pool_agg[pool_name]["possible"]
        util = e / p * 100 if p > 0 else 0
        avg_d = e / n_days if n_days > 0 else 0
        grand_earned += e; grand_possible += p
        vals = [pool_name, e, p, f"{util:.1f}%", f"{avg_d:.2f}"]
        for ci, v in enumerate(vals, 2):
            ws5.cell(row=row, column=ci, value=v)
        style_data_row(ws5, row, 2, len(sum_headers) + 1, pool_order.index(pool_name))
        row += 1

    # Total row
    grand_util = grand_earned / grand_possible * 100 if grand_possible > 0 else 0
    grand_avg = grand_earned / n_days if n_days > 0 else 0
    total_vals = ["TOTAL", grand_earned, grand_possible, f"{grand_util:.1f}%", f"{grand_avg:.2f}"]
    for ci, v in enumerate(total_vals, 2):
        ws5.cell(row=row, column=ci, value=v)
    style_total_row(ws5, row, 2, len(sum_headers) + 1)
    row += 2

    # --- Critical Findings (automated) ---
    ws5.merge_cells(f"B{row}:L{row}")
    ws5[f"B{row}"] = "CRITICAL FINDINGS"
    ws5[f"B{row}"].font = font_subheader()
    row += 1

    findings = []

    # (a) Always-on / near-always-on signals
    always_on = []
    for sdef in SIGNAL_DEFS:
        sid = sdef["id"]
        hr = sum(1 for r in results if r["signals"][sid]["fired"]) / n_days * 100
        if hr >= 95:
            always_on.append(f"{sid} ({hr:.0f}%)")
    if always_on:
        findings.append(
            f"Always-on signals (>=95% hit rate, zero discrimination): "
            + ", ".join(always_on)
            + f". These contribute ~{sum(pool_agg[s['pool']]['earned'] for s in SIGNAL_DEFS if sum(1 for r in results if r['signals'][s['id']]['fired'])/n_days*100 >= 95) / grand_earned * 100:.0f}% of all points as a fixed baseline."
        )

    # (b) Dead signals
    dead = []
    for sdef in SIGNAL_DEFS:
        sid = sdef["id"]
        hr = sum(1 for r in results if r["signals"][sid]["fired"]) / n_days * 100
        if hr == 0:
            dead.append(sid)
    if dead:
        findings.append(
            f"Dead signals (0% hit rate): {', '.join(dead)}. "
            "These signals never fired and contributed 0 points. Review conditions or data compatibility."
        )

    # (c) Duplicate conditions across pools
    findings.append(
        "Duplicate conditions detected: B5 and BA2 share identical logic (Daily Close > trough low + 10%) "
        "but live in different pools (B vs BA). Combined they contribute double points for the same condition."
    )

    # (d) Real discriminators
    discriminators = []
    for sdef in SIGNAL_DEFS:
        sid = sdef["id"]
        hr = sum(1 for r in results if r["signals"][sid]["fired"]) / n_days * 100
        if 0 < hr < 50:
            entry_hr = sum(1 for r in results if r["signals"][sid]["fired"] and r["date"] in trade_entry_dates) / len(trade_entry_dates) * 100 if trade_entry_dates else 0
            discriminators.append((sid, hr, entry_hr, sdef["max_pts"]))
    if discriminators:
        disc_str = ", ".join(f"{d[0]} ({d[1]:.0f}% hit, {d[2]:.0f}% entry)" for d in sorted(discriminators, key=lambda x: x[1]))
        findings.append(
            f"Real differentiating signals (hit rate <50%): {disc_str}. "
            "These are the signals that actually separate high-score entry days from low-score days."
        )

    for fi, finding in enumerate(findings):
        ws5.merge_cells(f"B{row}:L{row}")
        ws5[f"B{row}"] = f"{fi+1}. {finding}"
        ws5[f"B{row}"].font = font_body()
        ws5[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        ws5.row_dimensions[row].height = max(30, 15 * (1 + len(finding) // 90))
        row += 1

    # Column widths
    col_widths = {"B": 28, "C": 9, "D": 48, "E": 12, "F": 12, "G": 14, "H": 22, "I": 22, "J": 14}
    for col_letter, width in col_widths.items():
        ws5.column_dimensions[col_letter].width = width

    # ============================================================
    # Save
    # ============================================================
    wb.save(output_path)
    print(f"Report saved: {output_path}")
    return output_path


# ============================================================
# §8  Observations
# ============================================================

def _generate_observations(n_days, n_entries, n_completed, n_wins, n_losses,
                           win_rate, avg_pnl, cum_pnl, start_price, end_price,
                           price_change, pool_sums, n_days_total, n_troughs,
                           trough_cycles, trades, results):
    obs = []
    obs.append(f"1. The engine identified {n_entries} qualified entry signals across {n_days} trading days, with {n_completed} completed round-trip trades yielding a cumulative return of {'+' if cum_pnl >= 0 else ''}{cum_pnl}%.")

    if n_completed > 0:
        obs.append(f"2. Win rate stands at {win_rate} ({n_wins}W / {n_losses}L), with an average trade P&L of {'+' if avg_pnl >= 0 else ''}{avg_pnl}%. {'Positive expectancy suggests the signal framework has edge on this instrument.' if avg_pnl > 0 else 'Negative expectancy - signal framework needs refinement for this instrument.'}")
    else:
        obs.append(f"2. No completed trades in this period. All entry signals remained active at period end.")

    pa = pool_sums["pool_a"] / n_days if n_days > 0 else 0
    obs.append(f"3. Pool A (RSI Recovery) averages {pa:.1f}/42 pts ({pa/42*100:.0f}% utilization) - the primary scoring driver, dominated by Trough Detection and Recovery Momentum signals.")

    pb = pool_sums["pool_b"] / n_days if n_days > 0 else 0
    obs.append(f"4. Pool B (Price Structure) averages {pb:.1f}/25 pts ({pb/25*100:.0f}% utilization) - Close>TP28 and Close>WC50 on 4H are the strongest contributors when in uptrend.")

    pc = pool_sums["pool_c"] / n_days if n_days > 0 else 0
    obs.append(f"5. Pool C (Multi-TF Confirmation) is the most stable pool, averaging {pc:.1f}/18 pts ({pc/18*100:.0f}% utilization) - RSI conditions on multiple timeframes provide consistent confirmation.")

    baa = pool_sums["bonus_a"] / n_days if n_days > 0 else 0
    bba = pool_sums["bonus_b"] / n_days if n_days > 0 else 0
    obs.append(f"6. Bonus pools add {'modest' if baa + bba < 3 else 'significant'} upside: Bonus A averages {baa:.1f}/8 and Bonus B averages {bba:.1f}/10 - these provide differentiation at high-conviction points.")

    trend = "strong uptrend" if price_change > 50 else "moderate uptrend" if price_change > 10 else "downtrend"
    obs.append(f"7. The stock moved from {start_price:.2f} to {end_price:.2f} ({'+' if price_change >= 0 else ''}{price_change}%), a {trend}. The engine maintained {'intermittent' if n_entries > 5 else 'selective'} entry signals through this period.")

    if trough_cycles:
        obs.append(f"8. {n_troughs} trough cycle(s) were detected (D-RSI21<=40 + 11-bar local min, confirmed on 4H), each initiating a new scoring cycle. Recovery behavior varied across cycles.")

    return obs


# ============================================================
# §9  Main
# ============================================================

if __name__ == "__main__":
    print("Loading APOLLO data...")
    df_d, df_4h, df_w = load_apollo_data()
    print(f"Daily:   {len(df_d)} bars ({df_d.index[0].date()} to {df_d.index[-1].date()})")
    print(f"4H:      {len(df_4h)} bars ({df_4h.index[0].date()} to {df_4h.index[-1].date()})")
    print(f"Weekly:  {len(df_w)} bars ({df_w.index[0].date()} to {df_w.index[-1].date()})")

    print("\nRunning backtest (this may take a moment)...")
    results = run_backtest(df_d, df_4h, df_w, start_date="2025-01-01")
    print(f"Scored {len(results)} trading days")

    if not results:
        print("ERROR: No results."); sys.exit(1)

    print("Extracting trades...")
    trades, trade_events = extract_trades(results)
    print(f"  Completed trades: {len(trades)}, Events: {len(trade_events)}")

    print("Extracting trough cycles...")
    trough_cycles = extract_trough_cycles(df_d, df_4h, results)
    print(f"  Trough cycles: {len(trough_cycles)}")

    # Quick summary
    scores = [r["total_score"] for r in results]
    print(f"\n--- Quick Summary ---")
    print(f"Avg Score: {np.mean(scores):.1f} | Peak: {max(scores)} | Median: {np.median(scores):.0f}")
    print(f"Price: {results[0]['close']:.2f} -> {results[-1]['close']:.2f} ({(results[-1]['close']/results[0]['close']-1)*100:.1f}%)")
    print(f"Trades: {len(trades)} | Wins: {len([t for t in trades if t['pnl_pct']>0])} | Losses: {len([t for t in trades if t['pnl_pct']<=0])}")
    if trades:
        print(f"Cumulative P&L: {sum(t['pnl_pct'] for t in trades):.1f}%")  # noqa: zip

    # Auto-version: {ENGINE_NAME}_BT_{ddmmyy}_v{N}.xlsx
    output_dir = os.environ.get("APOLLO_OUTPUT_DIR", _DOWNLOAD_DIR)
    engine_name = "Apollo_Engine"
    date_tag = datetime.now().strftime("%d%m%y")
    prefix = f"{engine_name}_BT_{date_tag}"
    ver = 1
    while os.path.exists(os.path.join(output_dir, f"{prefix}_v{ver}.xlsx")):
        ver += 1
    output_path = os.path.join(output_dir, f"{prefix}_v{ver}.xlsx")

    print(f"\nGenerating XLSX report ({prefix}_v{ver})...")
    generate_report(results, trades, trade_events, trough_cycles, df_d, output_path)
    print(f"\nDone! Saved: {output_path}")