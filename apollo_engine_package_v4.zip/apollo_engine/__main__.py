"""Allow running the demo directly: python -m apollo_engine"""
from apollo_engine.example import main

if __name__ == "__main__":
    main()