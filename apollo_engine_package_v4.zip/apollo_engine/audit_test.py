#!/usr/bin/env python3
"""
Apollo Engine — Audit Validation Script
Tests specific edge cases and logic correctness identified during code audit.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

import numpy as np
import pandas as pd
from apollo_engine.indicators import compute_rsi, compute_tp28, compute_wc50, detect_trough_rsi
from apollo_engine.signals import *
from apollo_engine.engine import ApolloAnalysisEngine

PASS = 0
FAIL = 0
results = []

def check(name, condition, detail=""):
    global PASS, FAIL
    if condition:
        PASS += 1
        results.append(f"  PASS  {name}")
    else:
        FAIL += 1
        results.append(f"  FAIL  {name} — {detail}")


# ═══════════════════════════════════════════════════════════════════
# TEST 1: RSI Computation — Wilder's smoothing correctness
# ═══════════════════════════════════════════════════════════════════
print("=" * 65)
print("  AUDIT TEST 1: RSI Wilder's Smoothing")
print("=" * 65)

# Known case: monotonically rising prices → RSI should approach 100
n = 60
prices = pd.Series(np.arange(100.0, 100.0 + n), dtype=float)
rsi = compute_rsi(prices, 14)
check("RSI-1a", not np.isnan(rsi.iloc[30]), f"RSI at bar 30 is NaN: {rsi.iloc[30]}")
check("RSI-1b", rsi.iloc[-1] > 70, f"RSI of rising prices should be >70, got {rsi.iloc[-1]:.2f}")

# Known case: constant price → RSI undefined (should be NaN or 50)
flat = pd.Series([100.0] * 60)
rsi_flat = compute_rsi(flat, 14)
check("RSI-1c", np.isnan(rsi_flat.iloc[20]) or rsi_flat.iloc[20] == 50.0 or rsi_flat.iloc[20] == 100.0,
      f"Flat price RSI={rsi_flat.iloc[20]}")

# RSI should be bounded [0, 100] for normal data
np.random.seed(99)
rand_prices = pd.Series(100 + np.random.randn(200).cumsum())
rsi_rand = compute_rsi(rand_prices, 21)
valid_rsi = rsi_rand.dropna()
check("RSI-1d", valid_rsi.between(0, 100).all(),
      f"RSI out of bounds: min={valid_rsi.min():.2f}, max={valid_rsi.max():.2f}")


# ═══════════════════════════════════════════════════════════════════
# TEST 2: Trough Detection — centered window behavior
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 2: Trough Detection")
print("=" * 65)

# Create RSI with a known trough at position 50
n = 100
rsi_series = pd.Series(50.0 + 10 * np.sin(np.linspace(0, 4*np.pi, n)), dtype=float)
# Force a clear trough at index 50
rsi_series.iloc[50] = 25.0  # Well below 40 threshold
troughs = detect_trough_rsi(rsi_series, rsi_threshold=40.0, window=11)
check("TROUGH-2a", troughs.iloc[50] == True,
      f"Trough at index 50 not detected (RSI={rsi_series.iloc[50]})")

# Edge bars should NOT be detected as troughs (centered window can't confirm)
trough_at_start = troughs.iloc[0:5].any()
check("TROUGH-2b", not trough_at_start,
      f"Edge bars falsely detected as troughs: {troughs.iloc[0:5].values}")

# Trough at last 5 bars should also NOT be detected
trough_at_end = troughs.iloc[-5:].any()
check("TROUGH-2c", not trough_at_end,
      f"Last 5 bars falsely detected as troughs: {troughs.iloc[-5:].values}")

# Trough RSI above threshold should NOT be detected
rsi_high = rsi_series.copy()
rsi_high.iloc[50] = 55.0  # Above 40 threshold
troughs_high = detect_trough_rsi(rsi_high, rsi_threshold=40.0, window=11)
check("TROUGH-2d", not troughs_high.iloc[50],
      "RSI=55 incorrectly detected as trough with threshold=40")


# ═══════════════════════════════════════════════════════════════════
# TEST 3: Signal A3 — Recovery Momentum edge cases
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 3: Signal A3 Recovery Momentum")
print("=" * 65)

rsi_test = pd.Series([30.0] * 5 + [35.0, 40.0, 39.0, 42.0, 50.0] + [55.0] * 10)
df_dummy = pd.DataFrame({"close": [100.0] * len(rsi_test)})

# Trough at index 0 (RSI=30), check at index 7 (RSI=42, gain=12 in 7 bars)
pts, fired = signal_a3(rsi_test, idx=7, trough_loc=0)
check("A3-3a", fired and pts == 8,
      f"Gain=12 in 7 bars should fire (8pts), got pts={pts}, fired={fired}")

# Check at index 1 (RSI=35, gain=5 in 1 bar) — should NOT fire (gain < 8)
pts, fired = signal_a3(rsi_test, idx=1, trough_loc=0)
check("A3-3b", not fired and pts == 0,
      f"Gain=5 should NOT fire, got pts={pts}, fired={fired}")

# Check at trough itself (bars_since=0) — should NOT fire
pts, fired = signal_a3(rsi_test, idx=0, trough_loc=0)
check("A3-3c", not fired,
      f"At trough (bars_since=0) should NOT fire, got fired={fired}")

# Check beyond 10 bars — should NOT fire regardless of gain
pts, fired = signal_a3(rsi_test, idx=15, trough_loc=0)
check("A3-3d", not fired,
      f"15 bars since trough (>10) should NOT fire, got fired={fired}")

# None trough_loc — should NOT fire
pts, fired = signal_a3(rsi_test, idx=7, trough_loc=None)
check("A3-3e", not fired,
      f"None trough_loc should NOT fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 4: Signal B3 — Approaching TP28 proximity
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 4: Signal B3 Approaching TP28")
print("=" * 65)

# Close = 207, TP28 = 208.96 → gap = 0.95%, should fire (within 3%)
df_b3 = pd.DataFrame({"close": [207.0], "high": [210.0], "low": [205.0]})
tp28_b3 = pd.Series([208.96])
pts, fired = signal_b3(df_b3, tp28_b3, idx=0)
check("B3-4a", fired and pts == 5,
      f"0.95% below TP28 should fire, got pts={pts}, fired={fired}")

# Close = 200, TP28 = 208.96 → gap = 4.3%, should NOT fire (>3%)
df_b3b = pd.DataFrame({"close": [200.0], "high": [205.0], "low": [198.0]})
pts, fired = signal_b3(df_b3b, tp28_b3, idx=0)
check("B3-4b", not fired,
      f"4.3% below TP28 should NOT fire, got fired={fired}")

# Close = 210, TP28 = 208.96 → close ABOVE tp28, should NOT fire
df_b3c = pd.DataFrame({"close": [210.0], "high": [212.0], "low": [208.0]})
pts, fired = signal_b3(df_b3c, tp28_b3, idx=0)
check("B3-4c", not fired,
      f"Close above TP28 should NOT fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 5: Signal C1 — Cross-TF Trough Agreement (calendar vs trading days)
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 5: Signal C1 Cross-TF Trough (CALENDAR BUG CHECK)")
print("=" * 65)

# Same day — should fire
pts, fired = signal_c1(
    pd.Timestamp("2026-03-30"), pd.Timestamp("2026-03-30 13:15")
)
check("C1-5a", fired and pts == 6,
      f"Same-day troughs should fire, got pts={pts}, fired={fired}")

# 1 day apart — should fire
pts, fired = signal_c1(
    pd.Timestamp("2026-03-30"), pd.Timestamp("2026-03-31 09:00")
)
check("C1-5b", fired,
      f"1-day gap should fire, got fired={fired}")

# Thursday 20:00 to Tuesday — 5 calendar days, 3 trading days
# With df_daily provided, should count actual trading bars
df_c1test = pd.DataFrame(
    {"close": [100.0]*10},
    index=pd.bdate_range("2026-03-30", periods=10)
)
pts, fired = signal_c1(
    pd.Timestamp("2026-04-07"),   # Tuesday
    pd.Timestamp("2026-04-02 20:00"),  # Thursday
    df_daily=df_c1test,
)
check("C1-5c FIXED", fired,
      f"THU→TUE: 3 trading bars (via df_daily) should fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 6: Score Formula Verification
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 6: Score Formula & Thresholds")
print("=" * 65)

# Verify max possible scores
check("SCORE-6a", 10+8+8+6+6+4 == 42, f"Pool A max = {10+8+8+6+6+4}, expected 42")
check("SCORE-6b", 7+6+5+4+3 == 25, f"Pool B max = {7+6+5+4+3}, expected 25")
check("SCORE-6c", 6+4+4+4 == 18, f"Pool C max = {6+4+4+4}, expected 18")
check("SCORE-6d", 3+3+2 == 8, f"Bonus A max = {3+3+2}, expected 8")
check("SCORE-6e", 3+4+3 == 10, f"Bonus B max = {3+4+3}, expected 10")
check("SCORE-6f", min(100, 42+25+18) == 85, f"Core cap = {min(100, 42+25+18)}, expected 85")
check("SCORE-6g", 85 + 18 == 103, f"Absolute max = {85+18}, expected 103")


# ═══════════════════════════════════════════════════════════════════
# TEST 7: BA1 Selling Exhaustion — volume average window
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 7: BA1 Selling Exhaustion")
print("=" * 65)

# Build data where trough (idx=30) has low volume, preceding 30 bars have high volume
n = 50
vol_data = [10_000_000] * n
vol_data[30] = 4_000_000  # Trough day: below average
df_ba1 = pd.DataFrame({
    "close": [100.0] * n,
    "high": [101.0] * n,
    "low": [99.0] * n,
    "volume": vol_data,
})
pts, fired = signal_ba1(df_ba1, daily_trough_idx=30, idx=35)
check("BA1-7a", fired and pts == 3,
      f"Trough vol (4M) < 30-day avg (10M) should fire, got pts={pts}, fired={fired}")

# Trough with HIGH volume — should NOT fire
vol_data2 = [5_000_000] * n
vol_data2[30] = 15_000_000
df_ba1b = pd.DataFrame({
    "close": [100.0] * n,
    "high": [101.0] * n,
    "low": [99.0] * n,
    "volume": vol_data2,
})
pts, fired = signal_ba1(df_ba1b, daily_trough_idx=30, idx=35)
check("BA1-7b", not fired,
      f"Trough vol (15M) > 30-day avg (5M) should NOT fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 8: BA3 Volume Expansion — current bar included in check
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 8: BA3 4H Volume Expansion")
print("=" * 65)

n = 40
vol_data3 = [100.0] * n
vol_data3[38] = 200.0  # Recent bar with 2x volume (>1.5x avg)
df_ba3 = pd.DataFrame({
    "close": [100.0] * n,
    "high": [101.0] * n,
    "low": [99.0] * n,
    "volume": vol_data3,
})
pts, fired = signal_ba3(df_ba3, idx=39)
check("BA3-8a", fired and pts == 2,
      f"2x volume in last 3 days should fire, got pts={pts}, fired={fired}")

# All volumes at baseline — should NOT fire
vol_data4 = [100.0] * n
df_ba3b = pd.DataFrame({
    "close": [100.0] * n,
    "high": [101.0] * n,
    "low": [99.0] * n,
    "volume": vol_data4,
})
pts, fired = signal_ba3(df_ba3b, idx=39)
check("BA3-8b", not fired,
      f"No elevated volume should NOT fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 9: Edge case — NaN handling in signals
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 9: NaN Handling")
print("=" * 65)

nan_series = pd.Series([np.nan] * 10)
df_nan = pd.DataFrame({"close": [np.nan]*10, "high": [np.nan]*10, "low": [np.nan]*10})

pts, fired = signal_a5(nan_series, 5)
check("NaN-9a", not fired, "A5 with NaN RSI should not fire")

pts, fired = signal_a6(nan_series, nan_series, 5)
check("NaN-9b", not fired, "A6 with NaN RSI should not fire")

pts, fired = signal_c2(nan_series, 5)
check("NaN-9c", not fired, "C2 with NaN RSI should not fire")

pts, fired = signal_c4(nan_series, 5)
check("NaN-9d", not fired, "C4 with NaN RSI should not fire")


# ═══════════════════════════════════════════════════════════════════
# TEST 10: BB3 Weekly RSI Reversal — was_below check
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 10: BB3 Weekly RSI Reversal")
print("=" * 65)

# RSI21 was below RSI56 in the past, now above
rsi21_w = pd.Series([60, 55, 50, 45, 40, 42, 45, 48, 52, 55], dtype=float)
rsi56_w = pd.Series([50, 50, 50, 50, 50, 50, 50, 50, 50, 50], dtype=float)
pts, fired = signal_bb3(rsi21_w, rsi56_w, idx=9)
check("BB3-10a", fired and pts == 3,
      f"RSI21 crossed above RSI56 should fire, got pts={pts}, fired={fired}")

# RSI21 never was below RSI56 — should NOT fire
rsi21_w2 = pd.Series([55, 56, 57, 58, 59, 60, 61, 62, 63, 64], dtype=float)
rsi56_w2 = pd.Series([50, 50, 50, 50, 50, 50, 50, 50, 50, 50], dtype=float)
pts, fired = signal_bb3(rsi21_w2, rsi56_w2, idx=9)
check("BB3-10b", not fired,
      f"RSI21 never below RSI56 should NOT fire, got fired={fired}")

# RSI21 currently below RSI56 — should NOT fire even if was below before
rsi21_w3 = pd.Series([60, 55, 50, 45, 40, 42, 45, 48, 47, 46], dtype=float)
rsi56_w3 = pd.Series([50, 50, 50, 50, 50, 50, 50, 50, 50, 50], dtype=float)
pts, fired = signal_bb3(rsi21_w3, rsi56_w3, idx=9)
check("BB3-10c", not fired,
      f"RSI21 still below RSI56 should NOT fire, got fired={fired}")


# ═══════════════════════════════════════════════════════════════════
# TEST 11: B1/B2 — NaN TP28/WC50 handling
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print("  AUDIT TEST 11: B1/B2 NaN Indicator Handling")
print("=" * 65)

df_b1 = pd.DataFrame({"close": [200.0], "high": [205.0], "low": [195.0]})
tp28_nan = pd.Series([np.nan])
wc50_nan = pd.Series([np.nan])

pts, fired = signal_b1(df_b1, tp28_nan, 0)
check("B1-11a", not fired, "B1 with NaN TP28 should not fire")

pts, fired = signal_b2(df_b1, wc50_nan, 0)
check("B2-11b", not fired, "B2 with NaN WC50 should not fire")


# ═══════════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════════
print("\n" + "=" * 65)
print(f"  AUDIT RESULTS: {PASS} PASSED, {FAIL} FAILED")
print("=" * 65)
for r in results:
    print(r)

if FAIL > 0:
    print(f"\n  ⚠ {FAIL} issue(s) found — see FAIL entries above.")
else:
    print(f"\n  ✓ All tests passed.")

sys.exit(1 if FAIL > 0 else 0)