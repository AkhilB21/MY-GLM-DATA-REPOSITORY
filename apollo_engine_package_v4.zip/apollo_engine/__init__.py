"""
Apollo Analysis Engine
======================
Data-validated multi-timeframe RSI scoring engine for recovery detection.
Implements the full 19-signal scoring matrix across 5 pools (A, B, C, BA, BB)
as specified in the APOLLO Architecture document (July 2026).

Entry Score = min(100, Pool A + Pool B + Pool C) + Bonus A + Bonus B
Core Cap: 85 | Bonus Max: 18 | Absolute Max: 103

Usage:
    from apollo_engine import ApolloAnalysisEngine

    engine = ApolloAnalysisEngine()
    result = engine.score(df_4h, df_daily, df_weekly, lookback_date="2026-04-08")
    print(result)
"""

from apollo_engine.engine import ApolloAnalysisEngine
from apollo_engine.indicators import compute_rsi, compute_tp28, compute_wc50

__all__ = ["ApolloAnalysisEngine", "compute_rsi", "compute_tp28", "compute_wc50"]
__version__ = "1.0.0"