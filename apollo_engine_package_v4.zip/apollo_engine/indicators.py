"""
Core Technical Indicators for the Apollo Analysis Engine.

Indicators implemented:
  - RSI (Relative Strength Index): periods 21, 36, 56
  - TP28: 28-period Simple Moving Average of Typical Price (H+L+C)/3
  - WC50: 50-period Simple Moving Average of Weighted Close (H+L+2C)/4

All functions accept a pandas DataFrame with columns: high, low, close, volume
and return the computed series, aligned to the input index.
"""

import numpy as np
import pandas as pd


def compute_rsi(close: pd.Series, period: int) -> pd.Series:
    """
    Compute RSI using Wilder's smoothing method.

    Parameters
    ----------
    close : pd.Series
        Close price series.
    period : int
        RSI lookback period (e.g., 21, 36, 56).

    Returns
    -------
    pd.Series
        RSI values aligned to the input index. First `period` values are NaN.
    """
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)

    # Wilder's exponential moving average (alpha = 1/period)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()

    # Natural division: loss=0 → rs=inf → RSI=100 (strong uptrend).
    # Both zero → rs=NaN → RSI=NaN (flat line, RSI undefined).
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi


def compute_tp28(df: pd.DataFrame, period: int = 28) -> pd.Series:
    """
    Compute TP28: Simple Moving Average of Typical Price over `period` bars.

    Typical Price (TP) = (High + Low + Close) / 3
    TP28 = SMA(TP, 28)

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    period : int
        SMA window for TP. Default is 28.

    Returns
    -------
    pd.Series
        TP28 values aligned to the input index.
    """
    tp = (df["high"] + df["low"] + df["close"]) / 3.0
    return tp.rolling(window=period, min_periods=period).mean()


def compute_wc50(df: pd.DataFrame, period: int = 50) -> pd.Series:
    """
    Compute WC50: Simple Moving Average of Weighted Close over `period` bars.

    Weighted Close (WC) = (High + Low + 2 * Close) / 4
    WC50 = SMA(WC, 50)

    Parameters
    ----------
    df : pd.DataFrame
        OHLC data with columns: high, low, close.
    period : int
        SMA window for WC. Default is 50.

    Returns
    -------
    pd.Series
        WC50 values aligned to the input index.
    """
    wc = (df["high"] + df["low"] + 2.0 * df["close"]) / 4.0
    return wc.rolling(window=period, min_periods=period).mean()


def detect_trough_rsi(
    rsi: pd.Series, rsi_threshold: float, window: int
) -> pd.Series:
    """
    Detect bars where RSI is at a local minimum within a centered window.

    A trough is identified when:
      1. RSI <= rsi_threshold at the current bar, AND
      2. RSI at the current bar is the minimum within `window` bars
         (window//2 bars on each side).

    Parameters
    ----------
    rsi : pd.Series
        RSI series.
    rsi_threshold : float
        Maximum RSI value to qualify as a trough (e.g., 40 for Daily, 38 for 4H).
    window : int
        Total window size for local minimum check (e.g., 11 for Daily, 5 for 4H).

    Returns
    -------
    pd.Series
        Boolean series: True where a trough is detected.
    """
    half = window // 2
    rolling_min = rsi.rolling(window=window, center=True, min_periods=window).min()
    is_trough = (rsi <= rsi_threshold) & (rsi == rolling_min)
    return is_trough.fillna(False)