#!/usr/bin/env python3
"""
Apollo Analysis Engine — Demo & Validation Script

Generates synthetic multi-timeframe data and runs the full scoring engine
to demonstrate signal detection, score evolution, and entry decisions.

Usage:
    python -m apollo_engine.example
    python example.py
"""

import sys
import os

# Ensure the package is importable when running directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np

from apollo_engine.data_loader import (
    generate_synthetic_recovery_data,
    resample_to_4h,
    resample_to_weekly,
)
from apollo_engine import ApolloAnalysisEngine


def main():
    print("=" * 65)
    print("  APOLLO ANALYSIS ENGINE — Demonstration Run")
    print("=" * 65)

    # ── 1. Generate synthetic data ─────────────────────────────────────
    print("\n[1/4] Generating synthetic daily data (300 bars)...")
    df_daily = generate_synthetic_recovery_data(
        n_days=300, trough_day=200, base_price=220.0,
        decline_pct=0.18, recovery_pct=0.22, seed=42,
    )
    print(f"       Daily bars: {len(df_daily)} | "
          f"Range: {df_daily.index[0].date()} to {df_daily.index[-1].date()}")

    # ── 2. Create multi-timeframe data ─────────────────────────────────
    print("[2/4] Resampling to 4H and Weekly timeframes...")
    df_4h = resample_to_4h(df_daily)
    df_weekly = resample_to_weekly(df_daily)
    print(f"       4H bars:    {len(df_4h)}")
    print(f"       Weekly bars: {len(df_weekly)}")

    # ── 3. Initialize engine ───────────────────────────────────────────
    print("[3/4] Initializing Apollo Analysis Engine...")
    engine = ApolloAnalysisEngine()

    # ── 4. Run score series ───────────────────────────────────────────
    # Find the trough date
    trough_idx = df_daily["close"].idxmin()
    trough_date = str(trough_idx.date())
    # Score from 10 days before trough to 40 days after
    start = str((trough_idx - pd.Timedelta(days=14)).date())
    end = str((trough_idx + pd.Timedelta(days=45)).date())

    print(f"[4/4] Scoring from {start} to {end}...")
    print(f"       Trough detected at: {trough_date} "
          f"(Close: {df_daily.loc[trough_idx, 'close']:.2f})\n")

    results = engine.score_series(df_4h, df_daily, df_weekly, start, end)

    # ── Display Results ────────────────────────────────────────────────
    print("-" * 90)
    print(f"  {'Date':<12} {'Close':>8} {'A':>4} {'B':>4} {'C':>4} "
          f"{'BA':>4} {'BB':>4} {'Core':>5} {'TOTAL':>6}  {'Action':<22}")
    print("-" * 90)

    for row_pos, row in enumerate(results.itertuples()):
        action_short = row.action.replace("ENTRY", "E.").replace("BUY", "B.")
        marker = ""
        if row.total_score >= 75 and (
            row_pos == 0 or results.iloc[row_pos - 1]["total_score"] < 75
        ):
            marker = " ◄ FIRST ENTRY"
        print(
            f"  {row.date:<12} {row.close:>8.2f} "
            f"{row.pool_a:>4} {row.pool_b:>4} {row.pool_c:>4} "
            f"{row.bonus_a:>4} {row.bonus_b:>4} "
            f"{row.core_score:>5} {row.total_score:>6}  "
            f"{action_short:<22}{marker}"
        )

    # ── Detailed report at the highest-scoring bar ─────────────────────
    best_row = results.loc[results["total_score"].idxmax()]
    best_date = best_row["date"]
    print(f"\n{'=' * 65}")
    print(f"  DETAILED REPORT AT PEAK SCORE: {best_date}")
    print(f"{'=' * 65}")

    detail = engine.score(df_4h, df_daily, df_weekly, best_date)
    print(detail.summary())

    print("\n  SIGNAL-LEVEL DETAIL:")
    print(f"  {'ID':<5} {'Signal Name':<35} {'Pool':<4} {'Max':>4} {'Pts':>4} {'Fired':>6}")
    print(f"  {'─'*5} {'─'*35} {'─'*4} {'─'*4} {'─'*4} {'─'*6}")
    for s in detail.all_signals:
        status = "YES" if s.fired else "—"
        print(f"  {s.signal_id:<5} {s.signal_name:<35} {s.pool:<4} "
              f"{s.max_points:>4} {s.earned_points:>4} {status:>6}")

    # ── Export to CSV ──────────────────────────────────────────────────
    out_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "..", "apollo_score_series.csv"
    )
    results.to_csv(out_path, index=False)
    print(f"\n  Score series exported to: {out_path}")

    # ── JSON export of detailed result ─────────────────────────────────
    import json
    json_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "..", "apollo_detail_report.json"
    )
    with open(json_path, "w") as f:
        json.dump(detail.to_dict(), f, indent=2)
    print(f"  Detailed report exported to: {json_path}")

    return results


if __name__ == "__main__":
    main()