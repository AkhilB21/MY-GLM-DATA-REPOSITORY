"""
Data loading and preparation utilities for the Apollo Analysis Engine.

Provides helpers to:
  - Load CSV data into properly formatted DataFrames
  - Resample Daily data into 4H or Weekly timeframes
  - Validate required columns and data quality
"""

import pandas as pd
import numpy as np


REQUIRED_COLUMNS = {"open", "high", "low", "close", "volume"}
OPTIONAL_COLUMNS = {"date", "datetime", "timestamp"}


def load_csv(
    path: str,
    date_col: str = "date",
    date_format: str = None,
) -> pd.DataFrame:
    """
    Load OHLCV CSV data and return a DataFrame with DatetimeIndex.

    Parameters
    ----------
    path : str
        Path to the CSV file.
    date_col : str
        Column name containing the date/datetime.
    date_format : str, optional
        strptime format string for parsing dates.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and columns: open, high, low, close, volume.
    """
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]

    if date_col not in df.columns:
        raise ValueError(f"Date column '{date_col}' not found. "
                         f"Available: {list(df.columns)}")

    df[date_col] = pd.to_datetime(df[date_col], format=date_format)
    df.set_index(date_col, inplace=True)
    df.sort_index(inplace=True)

    _validate_ohlcv(df)
    return df


def _validate_ohlcv(df: pd.DataFrame):
    """Ensure DataFrame has all required OHLCV columns."""
    cols = set(df.columns.str.lower())
    missing = REQUIRED_COLUMNS - cols
    if missing:
        raise ValueError(
            f"Missing required columns: {missing}. "
            f"Required: {REQUIRED_COLUMNS}"
        )
    # Ensure numeric
    for col in REQUIRED_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df.dropna(subset=["close"], inplace=True)


def resample_to_4h(df_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Resample daily OHLCV data to 4-hour bars using synthetic intraday
    distribution. This is a simplified approximation — for production use,
    actual 4H data from a data provider is strongly recommended.

    The synthetic approach distributes daily range across 6 bars:
      - Bar 0 (open): O, H1, L1, C1
      - Bar 1-4: interpolated OHLC
      - Bar 5 (close): C5, daily High, daily Low, daily Close

    Parameters
    ----------
    df_daily : pd.DataFrame
        Daily OHLCV data with DatetimeIndex.

    Returns
    -------
    pd.DataFrame with 4H bars.
    """
    rows = []
    for date, row in df_daily.iterrows():
        o, h, l, c, v = (
            row["open"], row["high"], row["low"], row["close"], row["volume"]
        )
        # Generate 6 synthetic 4H bars
        np.random.seed(hash(str(date)) % (2**31))
        for i in range(6):
            vol_weights = [0.20, 0.12, 0.12, 0.14, 0.14, 0.28]
            bar_vol = v * vol_weights[i]

            if i == 0:
                bar_o, bar_h, bar_l, bar_c = o, o, o, o
            elif i == 5:
                bar_o, bar_h, bar_l, bar_c = c, h, l, c
            else:
                # Interpolate within the daily range
                frac = i / 5.0
                bar_o = o + (c - o) * (frac - 0.08)
                bar_c = o + (c - o) * (frac + 0.08)
                bar_h = max(bar_o, bar_c) + (h - max(o, c)) * 0.3
                bar_l = min(bar_o, bar_c) - (min(o, c) - l) * 0.3
                # Add small random noise
                noise = (h - l) * 0.05 * (np.random.random() - 0.5)
                bar_c += noise
                bar_h = max(bar_h, bar_o, bar_c)
                bar_l = min(bar_l, bar_o, bar_c)

            rows.append({
                "open": bar_o, "high": bar_h, "low": bar_l,
                "close": bar_c, "volume": bar_vol,
            })

    df_4h = pd.DataFrame(rows)
    df_4h.index = pd.DatetimeIndex(
        [r[0] + pd.Timedelta(hours=i * 4)
         for r in df_daily.iterrows() for i in range(6)]
    )
    return df_4h


def resample_to_weekly(df_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Resample daily OHLCV data to weekly bars.

    Week starts on Monday. Uses the first session's open, last session's
    close, and the extreme high/low across the week.

    Parameters
    ----------
    df_daily : pd.DataFrame
        Daily OHLCV data with DatetimeIndex.

    Returns
    -------
    pd.DataFrame with weekly bars, indexed by week-start date.
    """
    df = df_daily.copy()
    df["week"] = df.index.to_period("W").start_time

    weekly = df.groupby("week").agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
    )
    weekly.index.name = None
    return weekly


def generate_synthetic_recovery_data(
    n_days: int = 300,
    trough_day: int = 200,
    base_price: float = 200.0,
    decline_pct: float = 0.15,
    recovery_pct: float = 0.20,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate synthetic daily OHLCV data that simulates a decline and
    recovery pattern, suitable for testing the Apollo engine.

    Parameters
    ----------
    n_days : int
        Total number of daily bars to generate.
    trough_day : int
        Day index where the price trough occurs.
    base_price : float
        Starting price.
    decline_pct : float
        Maximum decline from base to trough.
    recovery_pct : float
        Recovery from trough price.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and OHLCV columns.
    """
    np.random.seed(seed)
    dates = pd.bdate_range("2025-06-01", periods=n_days)

    # Build a price path: rise → decline → trough → recovery
    prices = np.zeros(n_days)
    prices[0] = base_price

    trough_price = base_price * (1 - decline_pct)
    peak_before_decline = base_price * 1.10
    recovery_end_price = trough_price * (1 + recovery_pct)

    for i in range(1, n_days):
        if i < trough_day * 0.4:
            # Phase 1: Gradual rise
            target = peak_before_decline
            drift = (target - prices[i - 1]) * 0.02
        elif i < trough_day:
            # Phase 2: Decline to trough
            progress = (i - trough_day * 0.4) / (trough_day * 0.6)
            target = peak_before_decline + (trough_price - peak_before_decline) * progress
            drift = (target - prices[i - 1]) * 0.08
        elif i < trough_day + 30:
            # Phase 3: Sharp recovery
            progress = (i - trough_day) / 30.0
            target = trough_price + (recovery_end_price - trough_price) * progress
            drift = (target - prices[i - 1]) * 0.15
        else:
            # Phase 4: Consolidation / gentle rise
            drift = prices[i - 1] * 0.001

        volatility = prices[i - 1] * 0.015
        change = drift + np.random.normal(0, volatility)
        prices[i] = max(prices[i - 1] * 0.95, prices[i - 1] + change)

    # Generate OHLCV from close prices
    data = []
    for i, (date, close) in enumerate(zip(dates, prices)):
        intraday_range = close * 0.02
        o = close + np.random.normal(0, intraday_range * 0.3)
        h = max(o, close) + abs(np.random.normal(0, intraday_range * 0.5))
        l = min(o, close) - abs(np.random.normal(0, intraday_range * 0.5))
        # Volume: higher during decline and recovery
        base_vol = 5_000_000
        if i < trough_day:
            vol_mult = 1.0 + 0.5 * (i / trough_day)
        else:
            vol_mult = 1.5 - 0.8 * ((i - trough_day) / 50.0)
        vol = base_vol * max(0.5, vol_mult) * (0.8 + 0.4 * np.random.random())

        data.append({
            "open": round(o, 2), "high": round(h, 2),
            "low": round(l, 2), "close": round(close, 2),
            "volume": int(vol),
        })

    df = pd.DataFrame(data, index=dates)
    return df