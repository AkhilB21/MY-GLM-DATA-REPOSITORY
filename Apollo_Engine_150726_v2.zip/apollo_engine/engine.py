"""
Main Apollo Analysis Engine orchestrator.

Coordinates indicator computation, signal evaluation, and score aggregation
across three timeframes (4H, Daily, Weekly) to produce the final entry score.

Scoring Formula:
    Entry Score = min(100, Pool A + Pool B + Pool C) + Bonus A + Bonus B
    Core Cap: 90 | Bonus Max: 18 | Absolute Max: 108

Entry Decision Thresholds:
    0-49  : DO NOT ENTER
    50-69 : PILOT BUY    (25-30% position)
    70-79 : STANDARD     (60-70% position)
    80-89 : FULL ENTRY   (100% position)
    90+   : FULL STRONG  (100% position)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from scipy.signal import argrelextrema

from apollo_engine.indicators import (
    compute_rsi,
    compute_tp28,
    compute_wc50,
    detect_trough_rsi,
    compute_adx,
    compute_macd,
)
from apollo_engine.signals import (
    signal_a1, signal_a2, signal_a3, signal_a4, signal_a5, signal_a6,
    signal_b1, signal_b2, signal_b3, signal_b4, signal_b5, signal_b6,
    signal_c1, signal_c2, signal_c3, signal_c4,
    signal_ba1, signal_ba2, signal_ba3,
    signal_bb1, signal_bb2, signal_bb3,
    signal_bc1, signal_bc2,
)


@dataclass
class SignalResult:
    """Result of a single signal evaluation."""
    signal_id: str
    signal_name: str
    pool: str
    max_points: int
    earned_points: int
    fired: bool
    detail: str = ""


@dataclass
class PoolResult:
    """Aggregated result for one scoring pool."""
    pool_name: str
    max_points: int
    earned_points: int
    signals: list = field(default_factory=list)


@dataclass
class ApolloScoreResult:
    """Complete scoring result from the Apollo Analysis Engine."""
    date: str
    close_price: float
    pool_a: PoolResult
    pool_b: PoolResult
    pool_c: PoolResult
    bonus_a: PoolResult
    bonus_b: PoolResult
    bonus_c: PoolResult
    core_score: int          # min(100, A+B+C)
    bonus_score: int         # BA + BB
    total_score: int         # core + bonus
    action: str              # Entry decision action
    position_pct: str        # Suggested position size
    all_signals: list = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"{'='*60}",
            f"  APOLLO ANALYSIS ENGINE — Score Report",
            f"  Date: {self.date}  |  Close: {self.close_price:.2f}",
            f"{'='*60}",
            f"  Pool A (RSI Recovery)      : {self.pool_a.earned_points:>3} / {self.pool_a.max_points}",
            f"  Pool B (Price Structure)   : {self.pool_b.earned_points:>3} / {self.pool_b.max_points}",
            f"  Pool C (Multi-TF Confirm)  : {self.pool_c.earned_points:>3} / {self.pool_c.max_points}",
            f"  {'─'*40}",
            f"  Core Score (capped @ 100)  : {self.core_score}",
            f"  Bonus A (Volume/Support)   : {self.bonus_a.earned_points:>3} / {self.bonus_a.max_points}",
            f"  Bonus B (Uptrend Context)  : {self.bonus_b.earned_points:>3} / {self.bonus_b.max_points}",
            f"  {'─'*40}",
            f"  TOTAL SCORE                : {self.total_score} / 103",
            f"  ACTION                     : {self.action}",
            f"  POSITION SIZE              : {self.position_pct}",
            f"{'='*60}",
        ]
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Convert result to a plain dictionary."""
        return {
            "date": self.date,
            "close_price": round(self.close_price, 2),
            "pool_a": {
                "earned": self.pool_a.earned_points,
                "max": self.pool_a.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.pool_a.signals
                ],
            },
            "pool_b": {
                "earned": self.pool_b.earned_points,
                "max": self.pool_b.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.pool_b.signals
                ],
            },
            "pool_c": {
                "earned": self.pool_c.earned_points,
                "max": self.pool_c.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.pool_c.signals
                ],
            },
            "bonus_a": {
                "earned": self.bonus_a.earned_points,
                "max": self.bonus_a.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.bonus_a.signals
                ],
            },
            "bonus_b": {
                "earned": self.bonus_b.earned_points,
                "max": self.bonus_b.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.bonus_b.signals
                ],
            },
            "bonus_c": {
                "earned": self.bonus_c.earned_points,
                "max": self.bonus_c.max_points,
                "signals": [
                    {"id": s.signal_id, "name": s.signal_name,
                     "pts": s.earned_points, "fired": s.fired, "detail": s.detail}
                    for s in self.bonus_c.signals
                ],
            },
            "core_score": self.core_score,
            "bonus_score": self.bonus_score,
            "total_score": self.total_score,
            "action": self.action,
            "position_pct": self.position_pct,
        }


# ---------------------------------------------------------------------------
# Entry Decision Logic
# ---------------------------------------------------------------------------

_ENTRY_THRESHOLDS = [
    (90,  "FULL ENTRY (Strong)", "100%"),
    (80,  "FULL ENTRY",          "100%"),
    (70,  "STANDARD ENTRY",      "60-70%"),
    (50,  "PILOT BUY",           "25-30%"),
    (0,   "DO NOT ENTER",        "0%"),
]


def _classify(score: int) -> tuple:
    for threshold, action, pct in _ENTRY_THRESHOLDS:
        if score >= threshold:
            return action, pct
    return "DO NOT ENTER", "0%"


# ---------------------------------------------------------------------------
# Helper: find the integer index closest to a target date
# ---------------------------------------------------------------------------

def _find_bar_index(df: pd.DataFrame, target_date, date_col: str = None) -> int:
    """
    Find the row index of the bar closest to `target_date`.
    Works with DatetimeIndex or a named date column.
    Returns the integer positional index.
    """
    if date_col and date_col in df.columns:
        dates = pd.to_datetime(df[date_col])
    elif isinstance(df.index, pd.DatetimeIndex):
        dates = df.index
    else:
        raise ValueError(
            "DataFrame must have a DatetimeIndex or a date column specified."
        )

    target = pd.Timestamp(target_date)
    # Find the last bar on or before the target date
    mask = dates <= target
    if not mask.any():
        raise ValueError(
            f"No data on or before {target_date}. "
            f"Data range: {dates.min()} to {dates.max()}"
        )
    mask_arr = np.asarray(mask)
    valid_positions = np.where(mask_arr)[0]
    return int(valid_positions[-1])


def _find_latest_trough_pos(
    rsi: pd.Series, current_pos: int,
    rsi_threshold: float, window: int
) -> Optional[int]:
    """Find the most recent trough position on or before current_pos."""
    troughs = detect_trough_rsi(rsi, rsi_threshold, window)
    trough_iloc = np.where(troughs.iloc[: current_pos + 1].values)[0]
    if len(trough_iloc) == 0:
        return None
    return int(trough_iloc[-1])


# ---------------------------------------------------------------------------
# Main Engine
# ---------------------------------------------------------------------------

class ApolloAnalysisEngine:
    """
    Apollo Analysis Engine — Multi-timeframe RSI recovery scoring engine.

    Parameters
    ----------
    support_low, support_high : float, optional
        Manual support zone for BB2 (Multi-Touch). If None, auto-detected.
    date_col : str or None
        If DataFrames use a date column instead of DatetimeIndex, specify it.

    Example
    -------
    >>> engine = ApolloAnalysisEngine()
    >>> result = engine.score(df_4h, df_daily, df_weekly, "2026-04-08")
    >>> print(result.summary())
    """

    def __init__(
        self,
        support_low: Optional[float] = None,
        support_high: Optional[float] = None,
        date_col: Optional[str] = None,
    ):
        self.support_low = support_low
        self.support_high = support_high
        self.date_col = date_col

    # ---- internal computation cache -----------------------------------

    def _prepare_indicators(self, df: pd.DataFrame, tf: str) -> dict:
        """
        Compute all required indicators for a single timeframe.

        Returns a dict with rsi21, rsi36, rsi56, tp28, wc50 series.
        Results are cached per (id(df), tf) to avoid redundant computation
        during score_series loops.
        """
        cache_key = (id(df), tf)
        if not hasattr(self, '_indicator_cache'):
            self._indicator_cache = {}
        if cache_key in self._indicator_cache:
            return self._indicator_cache[cache_key]

        rsi21 = compute_rsi(df["close"], 21)
        rsi36 = compute_rsi(df["close"], 36)
        rsi56 = compute_rsi(df["close"], 56)
        tp28 = compute_tp28(df, period=28)
        wc50 = compute_wc50(df, period=50)
        result = {
            "rsi21": rsi21, "rsi36": rsi36, "rsi56": rsi56,
            "tp28": tp28, "wc50": wc50,
        }
        self._indicator_cache[cache_key] = result
        return result

    def clear_cache(self) -> None:
        """Clear the indicator cache. Call if input DataFrames change."""
        if hasattr(self, '_indicator_cache'):
            self._indicator_cache.clear()

    # ---- main scoring method ------------------------------------------

    def score(
        self,
        df_4h: pd.DataFrame,
        df_daily: pd.DataFrame,
        df_weekly: pd.DataFrame,
        lookback_date: str,
    ) -> ApolloScoreResult:
        """
        Compute the full Apollo score at the given date.

        Parameters
        ----------
        df_4h, df_daily, df_weekly : pd.DataFrame
            OHLCV data with columns: open, high, low, close, volume.
            Must have DatetimeIndex (or a date column if `date_col` was set).
        lookback_date : str
            The date to evaluate the score at (e.g., "2026-04-08").

        Returns
        -------
        ApolloScoreResult with full signal-level detail.
        """
        # --- Locate bar positions ---
        d_idx = _find_bar_index(df_daily, lookback_date, self.date_col)
        w_idx = _find_bar_index(df_weekly, lookback_date, self.date_col)

        # For 4H, find the last 4H bar on or before the target date
        if self.date_col and self.date_col in df_4h.columns:
            dates_4h = pd.to_datetime(df_4h[self.date_col])
        elif isinstance(df_4h.index, pd.DatetimeIndex):
            dates_4h = df_4h.index
        else:
            raise ValueError("df_4h must have DatetimeIndex or date column")

        target_ts = pd.Timestamp(lookback_date).tz_localize(None) if pd.Timestamp(lookback_date).tz else pd.Timestamp(lookback_date)
        mask_4h = dates_4h <= target_ts
        if not mask_4h.any():
            raise ValueError(f"No 4H data on or before {lookback_date}")
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])

        # --- Compute indicators ---
        ind_d = self._prepare_indicators(df_daily, "D")
        ind_4h = self._prepare_indicators(df_4h, "4H")
        ind_w = self._prepare_indicators(df_weekly, "W")

        # --- Find troughs ---
        d_trough_pos = _find_latest_trough_pos(
            ind_d["rsi21"], d_idx, 40.0, 11
        )
        h_trough_pos = _find_latest_trough_pos(
            ind_4h["rsi21"], h_idx, 38.0, 5
        )

        # Trough metadata
        d_trough_low = (
            df_daily["low"].iloc[d_trough_pos]
            if d_trough_pos is not None else None
        )
        d_trough_date = (
            df_daily.index[d_trough_pos]
            if d_trough_pos is not None else None
        )
        h_trough_date = (
            df_4h.index[h_trough_pos]
            if h_trough_pos is not None else None
        )
        trough_low = d_trough_low  # Use daily trough low for B4/B5/BA2

        # --- Compute ADX/MACD for Bonus C ---
        ind_d_adx = self._prepare_indicators(df_daily, "D")
        if "plus_di" not in ind_d_adx:
            pdi_d, mdi_d, adx_d = compute_adx(df_daily, 14)
            macd_d, macd_sig_d, macd_hist_d = compute_macd(df_daily["close"], 12, 26, 9)
            ind_d_adx["plus_di"] = pdi_d
            ind_d_adx["minus_di"] = mdi_d
            ind_d_adx["macd"] = macd_d

        # --- Evaluate all signals ---
        signals: list[SignalResult] = []

        # Pool A — RSI Recovery (42 pts)
        def _add(signal_id, name, pool, max_pts, earned, fired, detail=""):
            signals.append(SignalResult(
                signal_id, name, pool, max_pts, earned, fired, detail
            ))

        pts, fired = signal_a1(df_daily, ind_d["rsi21"], d_idx)
        _add("A1", "Trough Detected (D)", "A", 10, pts, fired)

        pts, fired = signal_a2(df_4h, ind_4h["rsi21"], h_idx)
        _add("A2", "Trough Detected (4H)", "A", 8, pts, fired)

        pts, fired = signal_a3(ind_d["rsi21"], d_idx, d_trough_pos)
        _add("A3", "Recovery Momentum (D)", "A", 8, pts, fired)

        pts, fired = signal_a4(ind_4h["rsi21"], df_4h, h_idx, h_trough_pos)
        _add("A4", "Recovery Momentum (4H)", "A", 6, pts, fired)

        pts, fired = signal_a5(ind_4h["rsi21"], h_idx)
        _add("A5", "RSI21 > 50 (4H)", "A", 6, pts, fired)

        pts, fired = signal_a6(ind_d["rsi21"], ind_d["rsi36"], d_idx)
        _add("A6", "Multi-Speed Alignment (D)", "A", 4, pts, fired)

        # Pool B — Price Structure (30 pts)
        pts, fired = signal_b1(df_4h, ind_4h["tp28"], h_idx)
        _add("B1", "Close > TP28 (4H)", "B", 7, pts, fired)

        pts, fired = signal_b2(df_4h, ind_4h["wc50"], h_idx)
        _add("B2", "Close > WC50 (4H)", "B", 6, pts, fired)

        pts, fired = signal_b3(df_daily, ind_d["tp28"], d_idx)
        _add("B3", "Approaching D-TP28 (D)", "B", 5, pts, fired)

        pts, fired = signal_b4(df_daily, d_idx, d_trough_low)
        _add("B4", "Higher Low Forming (D)", "B", 4, pts, fired)

        pts, fired = signal_b5(df_daily, d_idx, trough_low)
        _add("B5", "Price Above Trough +10% (D)", "B", 3, pts, fired)

        # B6 needs WC21 crossover price — compute on the fly for this bar
        wc21_4h = df_4h["wc21"] if "wc21" in df_4h.columns else None
        b6_xover = None
        if wc21_4h is not None and h_idx >= 1:
            prev_above = False
            for k in range(h_idx + 1):
                c_k = df_4h["close"].iloc[k]
                w_k = wc21_4h.iloc[k]
                if np.isnan(c_k) or np.isnan(w_k):
                    prev_above = False
                    continue
                cur_above = c_k > w_k
                if cur_above and not prev_above:
                    b6_xover = c_k
                elif not cur_above:
                    b6_xover = None
                prev_above = cur_above
        if wc21_4h is not None:
            pts, fired = signal_b6(df_4h, wc21_4h, h_idx, b6_xover)
        else:
            pts, fired = (0.0, False)
        _add("B6", "WC21 Proximity (4H)", "B", 5, pts, fired)

        # Pool C — Multi-TF Confirmation (18 pts)
        pts, fired = signal_c1(d_trough_date, h_trough_date, df_daily=df_daily)
        _add("C1", "Cross-TF Trough Agreement", "C", 6, pts, fired)

        pts, fired = signal_c2(ind_4h["rsi36"], h_idx)
        _add("C2", "4H RSI36 > 45", "C", 4, pts, fired)

        pts, fired = signal_c3(ind_w["rsi56"], w_idx)
        _add("C3", "W-RSI56 > 50 (prev W)", "C", 4, pts, fired)

        pts, fired = signal_c4(ind_d["rsi21"], d_idx)
        _add("C4", "D-RSI21 > 45", "C", 4, pts, fired)

        # Bonus A — Volume & Support (8 pts)
        pts, fired = signal_ba1(df_daily, d_trough_pos, d_idx)
        _add("BA1", "Selling Exhaustion", "BA", 3, pts, fired)

        pts, fired = signal_ba2(df_daily, d_idx, trough_low)
        _add("BA2", "Price > Trough +10%", "BA", 3, pts, fired)

        pts, fired = signal_ba3(df_4h, h_idx)
        _add("BA3", "4H Volume Expansion", "BA", 2, pts, fired)

        # Bonus B — Uptrend Context (10 pts)
        pts, fired = signal_bb1(df_daily, d_idx)
        _add("BB1", "52W High > Current*1.5", "BB", 3, pts, fired)

        pts, fired = signal_bb2(
            df_daily, d_idx, self.support_low, self.support_high
        )
        _add("BB2", "Multi-Touch Support Zone", "BB", 4, pts, fired)

        pts, fired = signal_bb3(ind_w["rsi21"], ind_w["rsi56"], w_idx)
        _add("BB3", "Weekly RSI Reversal Setup", "BB", 3, pts, fired)

        # Bonus C — Trend Momentum (5 pts)
        pts, fired = signal_bc1(ind_d_adx["plus_di"], ind_d_adx["minus_di"], d_idx)
        _add("BC1", "ADX > -DI (D)", "BC", 2.5, pts, fired)

        pts, fired = signal_bc2(ind_d_adx["macd"], d_idx)
        _add("BC2", "MACD > 0 (D)", "BC", 2.5, pts, fired)

        # --- Aggregate pools ---
        def _pool_result(pool_name, max_pts, pool_signals):
            earned = sum(s.earned_points for s in pool_signals)
            return PoolResult(pool_name, max_pts, earned, pool_signals)

        pa = _pool_result("Pool A — RSI Recovery", 42,
                          [s for s in signals if s.pool == "A"])
        pb = _pool_result("Pool B — Price Structure", 30,
                          [s for s in signals if s.pool == "B"])
        pc = _pool_result("Pool C — Multi-TF Confirm", 18,
                          [s for s in signals if s.pool == "C"])
        ba = _pool_result("Bonus A — Volume/Support", 8,
                          [s for s in signals if s.pool == "BA"])
        bb = _pool_result("Bonus B — Uptrend Context", 10,
                          [s for s in signals if s.pool == "BB"])
        bc = _pool_result("Bonus C — Trend Momentum", 5,
                          [s for s in signals if s.pool == "BC"])

        core = min(100, pa.earned_points + pb.earned_points + pc.earned_points)
        bonus = ba.earned_points + bb.earned_points + bc.earned_points
        total = core + bonus
        action, pos = _classify(total)

        return ApolloScoreResult(
            date=str(lookback_date),
            close_price=float(df_daily["close"].iloc[d_idx]),
            pool_a=pa, pool_b=pb, pool_c=pc,
            bonus_a=ba, bonus_b=bb, bonus_c=bc,
            core_score=core,
            bonus_score=bonus,
            total_score=total,
            action=action,
            position_pct=pos,
            all_signals=signals,
        )

    # ---- rolling score over a date range ------------------------------

    def score_series(
        self,
        df_4h: pd.DataFrame,
        df_daily: pd.DataFrame,
        df_weekly: pd.DataFrame,
        start_date: str,
        end_date: str,
    ) -> pd.DataFrame:
        """
        Compute Apollo scores for every daily bar in [start_date, end_date].

        Returns a DataFrame with one row per trading day and columns for
        each pool score, total score, action, and position size.
        """
        start_pos = _find_bar_index(df_daily, start_date, self.date_col)
        end_pos = _find_bar_index(df_daily, end_date, self.date_col)

        self.clear_cache()  # Ensure fresh indicators for this dataset

        rows = []
        for pos in range(start_pos, end_pos + 1):
            bar_date = str(df_daily.index[pos])[:10]
            try:
                result = self.score(df_4h, df_daily, df_weekly, bar_date)
                rows.append({
                    "date": bar_date,
                    "close": result.close_price,
                    "pool_a": result.pool_a.earned_points,
                    "pool_b": result.pool_b.earned_points,
                    "pool_c": result.pool_c.earned_points,
                    "core_score": result.core_score,
                    "bonus_a": result.bonus_a.earned_points,
                    "bonus_b": result.bonus_b.earned_points,
                    "total_score": result.total_score,
                    "action": result.action,
                    "position_pct": result.position_pct,
                })
            except (ValueError, IndexError):
                continue

        return pd.DataFrame(rows)

    # ---- bearish RSI divergence detection ----------------------------

    @staticmethod
    def detect_bearish_divergence(
        df_daily: pd.DataFrame,
        rsi_series: pd.Series,
        order: int = 5,
        lookback_bars: int = 60,
        min_rsi: float = 60.0,
    ) -> dict:
        """
        Detect bearish RSI divergences: price makes a new swing high while
        RSI makes a lower swing high.

        Uses argrelextrema on RSI21 (order=5 ≈ 2-week window) to find
        swing-high peaks, then identifies consecutive pairs where:
          1. The two peaks are within `lookback_bars` of each other
          2. The second peak's price HIGH > first peak's price HIGH
          3. The second peak's RSI < first peak's RSI
          4. The first peak's RSI > `min_rsi` (elevated zone)

        Returns a dict keyed by date string (YYYY-MM-DD) of the divergence
        bar, with divergence metadata (type, RSI drop, prices, etc.).

        Parameters
        ----------
        df_daily : pd.DataFrame
            Daily OHLCV data with a 'high' column.
        rsi_series : pd.Series
            RSI21 series aligned to df_daily's index.
        order : int
            argrelextrema order for swing-high detection (default 5).
        lookback_bars : int
            Maximum bar distance between consecutive peaks (default 60).
        min_rsi : float
            Minimum RSI at the first peak to qualify (default 60.0).

        Returns
        -------
        dict[str, dict]  —  date_str -> divergence_info
        """
        swing_idx = argrelextrema(rsi_series.values, np.greater, order=order)[0]
        peaks = []
        for idx in swing_idx:
            peaks.append({
                "idx": int(idx),
                "date": df_daily.index[idx],
                "high": float(df_daily["high"].iloc[idx]),
                "rsi21": float(rsi_series.iloc[idx]),
            })

        divergences: dict[str, dict] = {}
        for i in range(1, len(peaks)):
            p1, p2 = peaks[i - 1], peaks[i]
            if p2["idx"] - p1["idx"] > lookback_bars:
                continue
            if p2["high"] <= p1["high"]:        # price must make NEW high
                continue
            if p2["rsi21"] >= p1["rsi21"]:       # RSI must make LOWER high
                continue
            if p1["rsi21"] < min_rsi:            # previous RSI must be elevated
                continue

            rsi_drop = p1["rsi21"] - p2["rsi21"]
            if rsi_drop > 8:
                dtype = "STRONG"
            elif rsi_drop > 3:
                dtype = "MODERATE"
            else:
                dtype = "WEAK"

            divergences[str(p2["date"].date())] = {
                "type": dtype,
                "prev_date": str(p1["date"].date()),
                "prev_high": round(p1["high"], 2),
                "prev_rsi": round(p1["rsi21"], 2),
                "curr_high": round(p2["high"], 2),
                "curr_rsi": round(p2["rsi21"], 2),
                "rsi_drop": round(rsi_drop, 2),
            }

        return divergences