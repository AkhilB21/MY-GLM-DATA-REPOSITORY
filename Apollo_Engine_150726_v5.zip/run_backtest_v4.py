"""
Apollo Engine v4 — Multi-stock backtest with hard stop-loss.

Changes from v3:
  - Adds 5% hard stop-loss (from entry price, not peak)
  - SL checked daily on close, takes PRECEDENCE over score-based and divergence exits
  - SL exits trigger the same 5-day cooldown as divergence exits
  - Period-end open trades are still marked PERIOD_END (NOT SL, even if underwater)
  - Backward compatible: --sl-percent 0 disables SL (v3 behavior)

Stock selection:
  - Picks N random stocks from smallcap250.json
  - EXCLUDES any stock whose first available yfinance bar is on/after 2024-01-01
    (ensures full data history before backtest start)

Usage:
  python run_backtest_v4.py
  python run_backtest_v4.py --sl-percent 5.0 --seed 123 --n 5
  python run_backtest_v4.py --tickers SYM1.NS,SYM2.NS
"""
import sys
import os
import re
import math
import json
import random
import time
import argparse
import types
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import yfinance as yf
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

_SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPT_DIR))

from apollo_engine.data_loader import (
    synthesize_4h_from_daily, resample_weekly,
)
from apollo_engine.indicators import compute_all_indicators

# Import v3 module (which itself imports v2 engine logic)
import importlib.util
_spec_v3 = importlib.util.spec_from_file_location("run_backtest_v3", _SCRIPT_DIR / "run_backtest_v3.py")
v3 = importlib.util.module_from_spec(_spec_v3)
_spec_v3.loader.exec_module(v3)

# Re-export v3 helpers we need
pick_random_stocks = v3.pick_random_stocks
fetch_yfinance_daily = v3.fetch_yfinance_daily
generate_consolidated_report = v3.generate_consolidated_report
SIGNAL_DEFS = v3.SIGNAL_DEFS
POOL_MAX = v3.POOL_MAX
POOL_ORDER = v3.POOL_ORDER
POOL_NAMES = v3.POOL_NAMES
POOL_DESC = v3.POOL_DESC
eval_signals = v3.eval_signals
detect_troughs = v3.detect_troughs
get_latest_trough_pos = v3.get_latest_trough_pos
compute_weekly_rsi = v3.compute_weekly_rsi
classify_score = v3.classify_score
v2_module = v3.v2_module

_DOWNLOAD_DIR = Path("/home/z/my-project/download")
_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
_SMALLCAP_PATH = _SCRIPT_DIR.parent / "MY-GLM-DATA-REPOSITORY" / "smallcap250.json"
if not _SMALLCAP_PATH.exists():
    _SMALLCAP_PATH = Path("/home/z/my-project/repo/MY-GLM-DATA-REPOSITORY/smallcap250.json")


# ---------------------------------------------------------------------------
# v4 trade extractor with hard stop-loss
# ---------------------------------------------------------------------------

def extract_trades_with_sl(daily_results, df_d, sl_percent: float = 5.0):
    """Extract trades with hard stop-loss (v4).

    SL rule:
      - When in a trade and close <= entry_price * (1 - sl_percent/100), exit immediately
      - Exit reason: "SL_HIT (-X.X% stop-loss)"
      - SL takes PRECEDENCE over divergence exit and score-based exit
      - SL exits trigger the same 5-day cooldown as divergence exits
      - Period-end open trades are marked PERIOD_END (NOT SL, even if underwater)
      - If sl_percent <= 0, SL is disabled (v3 behavior)
    """
    events = []
    in_trade = False
    entry_price = None
    entry_date = None
    entry_idx = None
    last_div_date = None
    cooldown_until = None

    peak_rsi = None
    peak_rsi_price = None
    peak_rsi_date = None

    sl_threshold = 1.0 - sl_percent / 100.0 if sl_percent > 0 else 0.0

    for i, r in enumerate(daily_results):
        date = r['date']
        score = r['total']
        close = r['close']
        rsi = r['rsi21']
        action = r['action']

        # --- In-trade checks (SL > divergence > score-hold) ---
        if in_trade:
            # 1. Check HARD STOP-LOSS first (highest precedence)
            if sl_percent > 0 and close <= entry_price * sl_threshold:
                pnl = (close - entry_price) / entry_price * 100.0
                actual_sl_pct = round(-sl_percent, 2)  # actual realized loss (close to sl_percent)
                events.append({
                    'type': 'EXIT',
                    'date': date,
                    'close': close,
                    'score': round(score, 2),
                    'classification': 'SL EXIT',
                    'entry_price': entry_price,
                    'entry_date': entry_date,
                    'pnl': round(pnl, 2),
                    'exit_reason': f"SL_HIT ({actual_sl_pct}% stop-loss from entry {entry_price:.2f})",
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })
                in_trade = False
                last_div_date = date
                cooldown_until = i + v3.DIVERGENCE_COOLDOWN  # reuse 5-day cooldown
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                continue

            # 2. Track peak RSI for divergence check
            if peak_rsi is not None and rsi > peak_rsi:
                peak_rsi = rsi
                peak_rsi_price = df_d['high'].iloc[
                    df_d.index.get_loc(date)] if date in df_d.index else close
                peak_rsi_date = date

            # 3. Check divergence exit
            if (peak_rsi is not None and peak_rsi_price is not None and
                close > peak_rsi_price and
                rsi < (peak_rsi - v3.DIVERGENCE_RSI_DROP)):

                pnl = (close - entry_price) / entry_price * 100.0
                rsi_drop = round(peak_rsi - rsi, 2)
                strength = "STRONG" if rsi_drop > 5 else "MODERATE"

                events.append({
                    'type': 'EXIT',
                    'date': date,
                    'close': close,
                    'score': round(score, 2),
                    'classification': 'DIVERGENCE EXIT',
                    'entry_price': entry_price,
                    'entry_date': entry_date,
                    'pnl': round(pnl, 2),
                    'exit_reason': f"DIVERGENCE ({strength}, RSI {peak_rsi:.2f}->{rsi:.2f}, drop={rsi_drop}pts)",
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })

                in_trade = False
                last_div_date = date
                cooldown_until = i + v3.DIVERGENCE_COOLDOWN
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                continue

            # 4. Check score-based exit
            if score < v3.EXIT_THRESHOLD:
                pnl = (close - entry_price) / entry_price * 100.0
                events.append({
                    'type': 'EXIT',
                    'date': date,
                    'close': close,
                    'score': round(score, 2),
                    'classification': 'EXIT',
                    'entry_price': entry_price,
                    'entry_date': entry_date,
                    'pnl': round(pnl, 2),
                    'exit_reason': 'SCORE<50',
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })
                in_trade = False
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                continue

            # 5. Hold
            if score >= 90:
                hold_type = 'HOLD-FULL STRONG'
            elif score >= 80:
                hold_type = 'HOLD-FULL'
            elif score >= 70:
                hold_type = 'HOLD-STD'
            else:
                hold_type = 'WATCHLIST'
            events.append({
                'type': hold_type,
                'date': date,
                'close': close,
                'score': round(score, 2),
                'classification': action,
                'entry_price': entry_price,
                'entry_date': entry_date,
                'bars_from_trough': r['bars_from_trough'],
                'pool_a': round(r['pool_a'], 2),
                'pool_b': round(r['pool_b'], 2),
                'pool_c': round(r['pool_c'], 2),
                'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
            })
            continue

        # --- Not in trade: check for new entry ---
        if not in_trade and score >= v3.ENTRY_THRESHOLD:
            if cooldown_until is not None and i < cooldown_until:
                continue
            in_trade = True
            entry_price = close
            entry_date = date
            entry_idx = i
            peak_rsi = rsi
            peak_rsi_price = df_d['high'].iloc[
                df_d.index.get_loc(date)] if date in df_d.index else close
            peak_rsi_date = date

            events.append({
                'type': 'ENTRY',
                'date': date,
                'close': close,
                'score': round(score, 2),
                'classification': action,
                'entry_price': close,
                'entry_date': date,
                'bars_from_trough': r['bars_from_trough'],
                'pool_a': round(r['pool_a'], 2),
                'pool_b': round(r['pool_b'], 2),
                'pool_c': round(r['pool_c'], 2),
                'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
            })

    # Period-end exit for open trade (NOT SL, even if underwater)
    if in_trade:
        last = daily_results[-1]
        pnl = (last['close'] - entry_price) / entry_price * 100.0
        events.append({
            'type': 'EXIT',
            'date': last['date'],
            'close': last['close'],
            'score': round(last['total'], 2),
            'classification': 'EXIT',
            'entry_price': entry_price,
            'entry_date': entry_date,
            'pnl': round(pnl, 2),
            'exit_reason': 'PERIOD_END',
            'bars_from_trough': last['bars_from_trough'],
            'pool_a': round(last['pool_a'], 2),
            'pool_b': round(last['pool_b'], 2),
            'pool_c': round(last['pool_c'], 2),
            'bonus': round(last['bonus_a'] + last['bonus_b'] + last['bonus_c'], 2),
        })

    return events


# ---------------------------------------------------------------------------
# Override v2's run_backtest to use the SL-aware trade extractor
# ---------------------------------------------------------------------------

def run_backtest_with_sl(df_d, df_4h, df_w, start_date, end_date, sl_percent: float = 5.0):
    """Same as v2 run_backtest, but uses extract_trades_with_sl instead of extract_trades."""
    d_rsi21 = df_d['rsi21']
    d_rsi36 = df_d['rsi36']
    d_rsi56 = df_d['rsi56']
    h_rsi21 = df_4h['rsi21']
    h_rsi36 = df_4h['rsi36']
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)

    plus_di = df_d['plus_di']
    minus_di = df_d['minus_di']
    macd_line = df_d['macd']

    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    crossover_prices = []
    prev_above = False
    xover_price = None
    for i in range(len(df_4h)):
        c = df_4h['close'].iloc[i]
        w = df_4h['wc21'].iloc[i] if 'wc21' in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    daily_indices = np.where(np.asarray(mask))[0]

    if len(daily_indices) == 0:
        return pd.DataFrame(), []

    daily_results = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])
        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line, b6_xover
        )
        pool_pts = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id)
        core = min(100, pool_pts['A'] + pool_pts['B'] + pool_pts['C'])
        bonus = pool_pts['BA'] + pool_pts['BB'] + pool_pts['BC']
        total = core + bonus
        action, pos_pct = classify_score(total)
        daily_results.append({
            'date': bt_date,
            'close': df_d['close'].iloc[pos],
            'pool_a': pool_pts['A'],
            'pool_b': pool_pts['B'],
            'pool_c': pool_pts['C'],
            'bonus_a': pool_pts['BA'],
            'bonus_b': pool_pts['BB'],
            'bonus_c': pool_pts['BC'],
            'core': core,
            'bonus': bonus,
            'total': total,
            'action': action,
            'pos_pct': pos_pct,
            'signals': sigs,
            'd_trough_pos': d_trough_pos,
            'bars_from_trough': pos - d_trough_pos if d_trough_pos is not None else None,
            'rsi21': d_rsi21.iloc[pos],
        })

    daily_df = pd.DataFrame([{k: v for k, v in r.items() if k != 'signals'} for r in daily_results])
    if daily_df.empty:
        return daily_df, []

    # v4: use SL-aware trade extractor
    trades = extract_trades_with_sl(daily_results, df_d, sl_percent=sl_percent)
    return daily_df, trades


# ---------------------------------------------------------------------------
# Stock selection with listing-date filter
# ---------------------------------------------------------------------------

def pick_random_stocks_filtered(n: int, seed: int, min_listing_date: str = "2024-01-01") -> list[dict]:
    """Pick n random stocks that were listed BEFORE min_listing_date.

    Strategy:
      1. Shuffle universe with given seed
      2. For each candidate, fetch a small sample of yfinance data from 2022-01-01
         (a safe pre-2024 date) to verify the stock traded back then
      3. Reject if no data OR first bar >= min_listing_date
      4. Continue until n valid stocks found
    """
    with open(_SMALLCAP_PATH) as f:
        universe = json.load(f)
    rng = random.Random(seed)
    candidates = list(universe)
    rng.shuffle(candidates)

    min_ts = pd.Timestamp(min_listing_date)
    selected = []
    tested = 0

    print(f"Filtering for stocks listed BEFORE {min_listing_date}...")
    for cand in candidates:
        if len(selected) >= n:
            break
        tested += 1
        sym = cand['sym']
        try:
            # Fetch a tiny probe — just 1 month in 2022 to check listing
            probe = yf.download(sym, start="2022-11-01", end="2022-12-01",
                                progress=False, auto_adjust=True)
            if probe is None or probe.empty:
                print(f"  [{tested}] {sym}: NO 2022 data → SKIP (likely listed after 2022)")
                continue
            first_date = probe.index[0]
            if pd.Timestamp(first_date) >= min_ts:
                print(f"  [{tested}] {sym}: first bar {first_date.date()} → SKIP")
                continue
            # Also verify there's data covering the backtest period
            full_check = yf.download(sym, start="2023-12-25", end="2024-01-05",
                                     progress=False, auto_adjust=True)
            if full_check is None or len(full_check) < 2:
                print(f"  [{tested}] {sym}: missing data around 2024-01-01 → SKIP")
                continue
            print(f"  [{tested}] {sym}: first bar {first_date.date()} → OK")
            selected.append(cand)
        except Exception as e:
            print(f"  [{tested}] {sym}: ERROR {e}")
        time.sleep(0.6)  # yfinance rate limit

    print(f"\nSelected {len(selected)}/{n} valid stocks (tested {tested} candidates)")
    return selected


# ---------------------------------------------------------------------------
# Run one stock (reuses v3 logic but with v4 backtest)
# ---------------------------------------------------------------------------

def run_one_stock(symbol: str, name: str, sector: str,
                  start_date: str, end_date: str,
                  sl_percent: float = 5.0) -> dict:
    """Run v4 backtest for one stock."""
    print(f"\n[{symbol}] Fetching yfinance data...")
    warmup_start = (pd.Timestamp(start_date) - pd.DateOffset(years=1)).strftime('%Y-%m-%d')
    df_d_raw = fetch_yfinance_daily(symbol, warmup_start, end_date)
    if df_d_raw.empty:
        print(f"  [FAIL] No data fetched for {symbol}")
        return None

    print(f"  Daily bars: {len(df_d_raw)} | range: {df_d_raw.index[0].date()} → {df_d_raw.index[-1].date()}")

    df_4h = synthesize_4h_from_daily(df_d_raw[['open', 'high', 'low', 'close', 'volume']])
    print(f"  4H bars (synthesized): {len(df_4h)}")
    df_w = resample_weekly(df_d_raw[['open', 'high', 'low', 'close', 'volume']])
    print(f"  Weekly bars: {len(df_w)}")

    df_d = df_d_raw
    df_4h['rsi21']     = df_4h['RSI rsi (21,C)']
    df_4h['rsi36']     = df_4h['RSI rsi (36)']
    df_4h['tp28']      = df_4h['Result Typical Price (28,n)']
    df_4h['wc50']      = df_4h['Result Weighted Close (50,y)']
    df_4h['wc21']      = df_4h['Result Weighted Close (21)']
    df_4h.columns = [c.lower() for c in df_4h.columns]

    print(f"  Running v4 backtest (SL={sl_percent}%) {start_date} → {end_date}...")
    daily_df, trades = run_backtest_with_sl(df_d, df_4h, df_w, start_date, end_date, sl_percent=sl_percent)

    if daily_df.empty:
        print(f"  [FAIL] No backtest days in range")
        return None

    print(f"  Trading days: {len(daily_df)} | Avg score: {daily_df['total'].mean():.1f} | Peak: {daily_df['total'].max():.2f}")

    # Re-compute daily_results_full for Signal Analysis sheet (same as v3)
    d_rsi21 = df_d['rsi21']; d_rsi36 = df_d['rsi36']
    h_rsi21 = df_4h['rsi21']; h_rsi36 = df_4h['rsi36']
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di = df_d['plus_di']; minus_di = df_d['minus_di']
    macd_line = df_d['macd']
    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    crossover_prices = []
    prev_above = False
    xover_price = None
    for i in range(len(df_4h)):
        c = df_4h['close'].iloc[i]
        w = df_4h['wc21'].iloc[i] if 'wc21' in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask2 = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    daily_indices2 = np.where(np.asarray(mask2))[0]
    daily_results_full = []
    for pos in daily_indices2:
        bt_date = df_d.index[pos]
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])
        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line, b6_xover
        )
        pool_pts = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id)
        core = min(100, pool_pts['A'] + pool_pts['B'] + pool_pts['C'])
        bonus = pool_pts['BA'] + pool_pts['BB'] + pool_pts['BC']
        total = core + bonus
        action, pos_pct = classify_score(total)
        daily_results_full.append({
            'date': bt_date, 'close': df_d['close'].iloc[pos],
            'pool_a': pool_pts['A'], 'pool_b': pool_pts['B'], 'pool_c': pool_pts['C'],
            'bonus_a': pool_pts['BA'], 'bonus_b': pool_pts['BB'], 'bonus_c': pool_pts['BC'],
            'core': core, 'bonus': bonus, 'total': total,
            'action': action, 'pos_pct': pos_pct,
            'signals': sigs,
            'bars_from_trough': pos - d_trough_pos if d_trough_pos is not None else None,
            'rsi21': d_rsi21.iloc[pos],
        })

    provenance = {
        'daily_source': 'yfinance (auto-adjusted)',
        '4h_source': 'synthesized from daily (v3)',
        'indicators': 'computed in Python (Wilder RSI, SMA TP/WC, Wilder ADX, EMA MACD)',
        'warmup_start': warmup_start,
        'stop_loss': f'{sl_percent}% hard SL from entry (v4)',
        'sl_cooldown': f'{v3.DIVERGENCE_COOLDOWN} days (same as divergence exit)',
        'sl_precedence': 'SL > divergence > score-based exit',
        'period_end_policy': 'PERIOD_END (NOT SL, even if underwater)',
    }

    entries = [e for e in trades if e['type'] == 'ENTRY']
    exits = [e for e in trades if e['type'] == 'EXIT']
    completed = [e for e in exits if 'pnl' in e and e.get('exit_reason') != '']
    cum_pnl = sum(e['pnl'] for e in completed) if completed else 0
    winning = [e for e in completed if e['pnl'] > 0]
    win_rate = round(len(winning) / len(completed) * 100, 0) if completed else 0
    sl_exits = [e for e in exits if 'SL_HIT' in e.get('exit_reason', '')]
    div_exits = [e for e in exits if 'DIVERGENCE' in e.get('exit_reason', '')]
    score_exits = [e for e in exits if e.get('exit_reason') == 'SCORE<50']
    period_end_exits = [e for e in exits if e.get('exit_reason') == 'PERIOD_END']

    return {
        'symbol': symbol, 'name': name, 'sector': sector,
        'daily_df': daily_df, 'trades': trades,
        'daily_results_full': daily_results_full,
        'df_d': df_d, 'df_4h': df_4h, 'df_w': df_w,
        'provenance': provenance,
        'entries': entries, 'completed': completed,
        'cum_pnl': cum_pnl, 'win_rate': win_rate,
        'avg_score': round(daily_df['total'].mean(), 1),
        'peak_score': round(daily_df['total'].max(), 2),
        'n_days': len(daily_df),
        'sl_exits': sl_exits, 'div_exits': div_exits,
        'score_exits': score_exits, 'period_end_exits': period_end_exits,
    }


# ---------------------------------------------------------------------------
# Extended report generator (adds SL stats to Summary)
# ---------------------------------------------------------------------------

def generate_consolidated_report_v4(results: list[dict], start_date: str, end_date: str,
                                     output_path: Path, sl_percent: float = 5.0):
    """Generate consolidated XLSX with v4 SL stats in Summary."""
    wb = Workbook()

    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    title_font = Font(bold=True, size=16, color="1F4E79")
    subtitle_font = Font(bold=True, size=11, color="4472C4")
    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    orange_fill = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
    sl_fill = PatternFill(start_color="FFD6D6", end_color="FFD6D6", fill_type="solid")  # pink for SL
    amber_font = Font(color="BF8F00", italic=True)
    red_font = Font(color="C00000", italic=True)
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )

    def style_header(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', wrap_text=True)
            cell.border = thin_border

    def style_data(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center')

    # ===================== SHEET 1: Summary =====================
    ws1 = wb.active
    ws1.title = "Summary"

    ws1['B2'] = "Apollo Engine v4 - Consolidated Backtest Report (with Stop-Loss)"
    ws1['B2'].font = title_font
    ws1.merge_cells('B2:N2')

    ws1['B3'] = (f"{len(results)} Smallcap250 stocks (random seed) | "
                 f"{start_date} to {end_date} | "
                 f"SL: {sl_percent}% hard from entry | "
                 f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    ws1['B3'].font = Font(size=10, color="666666")
    ws1.merge_cells('B3:N3')

    ws1['B5'] = "DATA PROVENANCE (Charter Rule 7)"
    ws1['B5'].font = subtitle_font
    provenance_lines = [
        "Daily OHLCV: yfinance (auto-adjusted splits/dividends)",
        "Stock filter: only stocks listed BEFORE 2024-01-01 (verified via 2022-11 probe)",
        "4H bars: SYNTHESIZED from daily using v3 deterministic model (2 bars/NSE day, 09:15 & 13:15)",
        "Indicators: computed in Python — Wilder RSI(21/36/56), SMA TP(28), SMA WC(21/50), Wilder ADX(14,14), EMA MACD(12,26,9)",
        "Warmup: 1 year before backtest start to ensure indicator stability",
        f"Stop-loss (v4): {sl_percent}% hard SL from entry price, checked daily on close",
        "SL precedence: SL > divergence > score-based exit. SL exits trigger 5-day cooldown (same as divergence).",
        "Period-end open trades are marked PERIOD_END (NOT SL, even if underwater by >5%).",
        "WARNING: Synthetic 4H bars are APPROXIMATE. For production, swap in real Kite Connect 4H data.",
    ]
    for i, line in enumerate(provenance_lines):
        ws1.cell(6 + i, 2, line).font = Font(size=10, color="333333")
        ws1.merge_cells(start_row=6+i, start_column=2, end_row=6+i, end_column=14)

    # Stock ranking table (with SL column)
    r = 16
    ws1.cell(r, 2, "STOCK RANKING (by Cumulative P&L)").font = subtitle_font
    r += 1
    headers = ["Rank", "Symbol", "Name", "Sector", "Days", "Entries",
               "Completed", "Win Rate", "SL Hits", "Cum P&L %",
               "Avg Score", "Peak Score"]
    for i, h in enumerate(headers):
        ws1.cell(r, 2+i, h)
    style_header(ws1, r, len(headers) + 1)

    sorted_results = sorted(results, key=lambda x: x['cum_pnl'], reverse=True)
    for rank, res in enumerate(sorted_results, 1):
        row = r + rank
        ws1.cell(row, 2, rank)
        ws1.cell(row, 3, res['symbol'])
        ws1.cell(row, 4, res['name'])
        ws1.cell(row, 5, res['sector'])
        ws1.cell(row, 6, res['n_days'])
        ws1.cell(row, 7, len(res['entries']))
        ws1.cell(row, 8, len(res['completed']))
        ws1.cell(row, 9, f"{res['win_rate']:.0f}%")
        ws1.cell(row, 10, len(res.get('sl_exits', [])))
        pnl_cell = ws1.cell(row, 11, f"{res['cum_pnl']:+.1f}%")
        if res['cum_pnl'] > 0:
            pnl_cell.font = Font(bold=True, color="006100")
        else:
            pnl_cell.font = Font(bold=True, color="C00000")
        ws1.cell(row, 12, res['avg_score'])
        ws1.cell(row, 13, res['peak_score'])
        style_data(ws1, row, len(headers) + 1)

    # Aggregate stats
    r = r + len(sorted_results) + 3
    ws1.cell(r, 2, "PORTFOLIO AGGREGATE").font = subtitle_font
    r += 1
    agg_headers = ["Metric", "Value"]
    for i, h in enumerate(agg_headers):
        ws1.cell(r, 2+i, h)
    style_header(ws1, r, len(agg_headers) + 1)
    total_sl = sum(len(x.get('sl_exits', [])) for x in results)
    total_div = sum(len(x.get('div_exits', [])) for x in results)
    total_score = sum(len(x.get('score_exits', [])) for x in results)
    total_pe = sum(len(x.get('period_end_exits', [])) for x in results)
    total_completed = sum(len(x['completed']) for x in results)
    sl_pct_of_exits = round(total_sl / total_completed * 100, 1) if total_completed else 0

    agg_data = [
        ("Stocks backtested", len(results)),
        ("Total entries", sum(len(x['entries']) for x in results)),
        ("Total completed trades", total_completed),
        ("Avg cumulative P&L", f"{np.mean([x['cum_pnl'] for x in results]):+.1f}%"),
        ("Best P&L", f"{max(x['cum_pnl'] for x in results):+.1f}% ({max(results, key=lambda x: x['cum_pnl'])['symbol']})"),
        ("Worst P&L", f"{min(x['cum_pnl'] for x in results):+.1f}% ({min(results, key=lambda x: x['cum_pnl'])['symbol']})"),
        ("Avg win rate", f"{np.mean([x['win_rate'] for x in results]):.0f}%"),
        ("Avg daily score", f"{np.mean([x['avg_score'] for x in results]):.1f}"),
        ("", ""),
        ("EXIT TYPE BREAKDOWN", ""),
        ("SL hits", f"{total_sl} ({sl_pct_of_exits}% of all exits)"),
        ("Divergence exits", total_div),
        ("Score<50 exits", total_score),
        ("Period-end exits", total_pe),
        ("Avg P&L per SL trade", f"{np.mean([e['pnl'] for x in results for e in x.get('sl_exits', [])]):.1f}%" if total_sl else "N/A"),
    ]
    for i, (m, v) in enumerate(agg_data):
        rr = r + 1 + i
        ws1.cell(rr, 2, m).font = Font(bold=True, size=10)
        ws1.cell(rr, 3, v)
        style_data(ws1, rr, 3)
        if m == "EXIT TYPE BREAKDOWN":
            ws1.cell(rr, 2).font = subtitle_font

    for col_letter in ['B','C','D','E','F','G','H','I','J','K','L','M','N']:
        ws1.column_dimensions[col_letter].width = 18
    ws1.column_dimensions['D'].width = 30

    # ===================== Per-stock sheets =====================
    for idx, res in enumerate(sorted_results):
        sym_safe = re.sub(r'[^A-Za-z0-9]', '_', res['symbol'])[:28]
        ws = wb.create_sheet(f"{sym_safe}")

        ws['B2'] = f"{res['symbol']} - {res['name']}"
        ws['B2'].font = title_font
        ws.merge_cells('B2:N2')
        ws['B3'] = (f"Sector: {res['sector']} | {start_date} to {end_date} | "
                    f"{res['n_days']} trading days | SL: {sl_percent}%")
        ws['B3'].font = Font(size=10, color="666666")
        ws.merge_cells('B3:N3')

        r = 5
        ws.cell(r, 2, "KEY METRICS").font = subtitle_font
        r += 1
        kpi_headers = ["Days", "Entries", "Completed", "Win Rate", "Cum P&L",
                       "SL Hits", "Div Exits", "Avg Score", "Peak Score",
                       "Start Price", "End Price", "Price Change"]
        daily_df = res['daily_df']
        start_price = daily_df['close'].iloc[0]
        end_price = daily_df['close'].iloc[-1]
        price_change = round((end_price - start_price) / start_price * 100, 1) if start_price else 0
        kpi_values = [res['n_days'], len(res['entries']), len(res['completed']),
                      f"{res['win_rate']:.0f}%", f"{res['cum_pnl']:+.1f}%",
                      len(res.get('sl_exits', [])),
                      len(res.get('div_exits', [])),
                      res['avg_score'], res['peak_score'],
                      round(start_price, 2), round(end_price, 2), f"{price_change:+.1f}%"]
        for i, (lbl, val) in enumerate(zip(kpi_headers, kpi_values)):
            ws.cell(r, 2+i, lbl).font = Font(bold=True, size=9, color="666666")
            cell = ws.cell(r+1, 2+i, val)
            cell.font = Font(size=11)
            cell.alignment = Alignment(horizontal='center')

        # Trade log
        r = 9
        ws.cell(r, 2, "TRADE LOG").font = subtitle_font
        r += 1
        tl_headers = ["#", "Type", "Date", "Close", "Score", "Classification",
                      "Entry Price", "Entry Date", "P&L %", "Exit Reason"]
        for i, h in enumerate(tl_headers):
            ws.cell(r, 2+i, h)
        style_header(ws, r, len(tl_headers) + 1)

        for ti, evt in enumerate(res['trades']):
            rr = r + 1 + ti
            ws.cell(rr, 2, ti + 1)
            ws.cell(rr, 3, evt['type'])
            ws.cell(rr, 4, evt['date'].strftime('%Y-%m-%d') if hasattr(evt['date'], 'strftime') else str(evt['date']))
            ws.cell(rr, 5, round(evt['close'], 2) if evt['close'] else '')
            ws.cell(rr, 6, evt['score'])
            ws.cell(rr, 7, evt['classification'])
            if 'entry_price' in evt:
                ws.cell(rr, 8, round(evt['entry_price'], 2))
            if 'entry_date' in evt:
                ws.cell(rr, 9, evt['entry_date'].strftime('%Y-%m-%d') if hasattr(evt['entry_date'], 'strftime') else str(evt['entry_date']))
            if 'pnl' in evt:
                ws.cell(rr, 10, evt['pnl'])
            if 'exit_reason' in evt:
                ws.cell(rr, 11, evt['exit_reason'])
            style_data(ws, rr, len(tl_headers) + 1)

            if evt['type'] == 'ENTRY':
                for c in range(2, len(tl_headers) + 2):
                    ws.cell(rr, c).fill = green_fill
                    ws.cell(rr, c).font = Font(bold=True)
            elif evt['type'] == 'EXIT':
                reason = evt.get('exit_reason', '')
                if 'SL_HIT' in reason:
                    fill = sl_fill
                elif 'DIVERGENCE' in reason:
                    fill = orange_fill
                elif 'PERIOD_END' in reason:
                    fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")
                else:
                    fill = red_fill
                for c in range(2, len(tl_headers) + 2):
                    ws.cell(rr, c).fill = fill

        # Signal Analysis
        r = r + len(res['trades']) + 3
        ws.cell(r, 2, "SIGNAL ANALYSIS").font = subtitle_font
        r += 1
        sa_headers = ["Signal", "Pool", "Max Pts", "Hit Rate %", "Hits", "Total Pts", "Contribution %"]
        for i, h in enumerate(sa_headers):
            ws.cell(r, 2+i, h)
        style_header(ws, r, len(sa_headers) + 1)

        total_days = res['n_days']
        total_pts_all = 0
        sig_stats = []
        for sid, sname, pool, maxp in SIGNAL_DEFS:
            hits = 0; total_pts = 0
            for dr in res['daily_results_full']:
                pts, fired = dr['signals'][sid]
                if fired: hits += 1
                total_pts += pts
            hit_rate = round(hits / total_days * 100, 1) if total_days else 0
            sig_stats.append((sid, sname, pool, maxp, hit_rate, hits, round(total_pts, 2)))
            total_pts_all += total_pts

        for i, (sid, sname, pool, maxp, hr, h, tp) in enumerate(sig_stats):
            rr = r + 1 + i
            ws.cell(rr, 2, f"{sid} - {sname}")
            ws.cell(rr, 3, pool)
            ws.cell(rr, 4, maxp)
            ws.cell(rr, 5, f"{hr}%")
            ws.cell(rr, 6, h)
            ws.cell(rr, 7, tp)
            contrib = round(tp / total_pts_all * 100, 1) if total_pts_all else 0
            ws.cell(rr, 8, f"{contrib}%")
            style_data(ws, rr, len(sa_headers) + 1)
            if hr == 0:
                for c in range(2, len(sa_headers) + 2):
                    ws.cell(rr, c).font = red_font
            elif hr >= 95:
                for c in range(2, len(sa_headers) + 2):
                    ws.cell(rr, c).font = amber_font

        # Critical findings
        r = r + 1 + len(sig_stats) + 2
        ws.cell(r, 2, "CRITICAL FINDINGS").font = subtitle_font
        r += 1
        always_on = [f"{sid} ({hr}%)" for sid, _, _, _, hr, _, _ in sig_stats if hr >= 95]
        dead = [f"{sid} (0%)" for sid, _, _, _, hr, _, _ in sig_stats if hr == 0]
        if always_on:
            ws.cell(r, 2, f"Always-on (≥95%): {', '.join(always_on)}").font = amber_font
            r += 1
        if dead:
            ws.cell(r, 2, f"Dead (0%): {', '.join(dead)}").font = red_font
            r += 1
        diffs = [s for s in sig_stats if s[4] < 50 and s[4] > 0]
        diffs.sort(key=lambda x: x[6], reverse=True)
        if diffs:
            top_diffs = ', '.join(f"{s[0]} ({s[4]}%, {s[6]} pts)" for s in diffs[:5])
            ws.cell(r, 2, f"Top differentiators: {top_diffs}").font = Font(italic=True, color="333333")

        # SL analysis sub-section
        r += 2
        ws.cell(r, 2, f"STOP-LOSS ANALYSIS ({sl_percent}% from entry)").font = subtitle_font
        r += 1
        sl_exits = res.get('sl_exits', [])
        if sl_exits:
            sl_pnls = [e['pnl'] for e in sl_exits]
            sl_avg = np.mean(sl_pnls)
            sl_worst = min(sl_pnls)
            sl_best = max(sl_pnls)
            sl_lines = [
                f"SL exits: {len(sl_exits)}",
                f"Avg P&L on SL exit: {sl_avg:+.2f}%",
                f"Worst SL P&L: {sl_worst:+.2f}%",
                f"Best SL P&L: {sl_best:+.2f}%",
                f"SL as % of completed trades: {len(sl_exits) / len(res['completed']) * 100:.1f}%",
            ]
        else:
            sl_lines = [
                "SL exits: 0",
                "No trades hit the stop-loss during the backtest period.",
                "This may indicate: (1) entries are well-timed, (2) SL is too wide, or (3) sample size too small.",
            ]
        for i, line in enumerate(sl_lines):
            ws.cell(r + i, 2, line).font = Font(size=10)
            ws.merge_cells(start_row=r+i, start_column=2, end_row=r+i, end_column=11)

        for col_letter in ['B','C','D','E','F','G','H','I','J','K','L','M','N']:
            ws.column_dimensions[col_letter].width = 16
        ws.column_dimensions['K'].width = 45
        ws.column_dimensions['B'].width = 22

    wb.save(output_path)
    print(f"\nReport saved: {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=5, help='Number of random stocks')
    parser.add_argument('--seed', type=int, default=123, help='Random seed (default 123, different from v3)')
    parser.add_argument('--start', type=str, default='2024-01-01')
    parser.add_argument('--end', type=str, default='2025-07-14')
    parser.add_argument('--tickers', type=str, default=None,
                        help='Comma-separated tickers (overrides random pick)')
    parser.add_argument('--sl-percent', type=float, default=5.0,
                        help='Stop-loss percent from entry (default 5.0, 0 to disable)')
    args = parser.parse_args()

    print("=" * 70)
    print(f"Apollo Engine v4 — Multi-Stock Backtest with Stop-Loss")
    print(f"Period: {args.start} → {args.end}  |  Stocks: {args.n}  |  Seed: {args.seed}")
    print(f"Stop-loss: {args.sl_percent}% from entry (hard, daily close check)")
    print("=" * 70)

    # Pick stocks (filter for pre-2024 listing)
    if args.tickers:
        picks = [{'sym': t.strip(), 'name': t.strip().replace('.NS',''), 'sector': 'N/A'}
                 for t in args.tickers.split(',')]
    else:
        picks = pick_random_stocks_filtered(args.n, args.seed, min_listing_date="2024-01-01")
    if not picks:
        print("[FAIL] No valid stocks found. Try a different seed.")
        return

    print(f"\nFinal picks ({len(picks)}):")
    for p in picks:
        print(f"  - {p['sym']} | {p['name']} | {p['sector']}")

    # Run backtest for each
    results = []
    failed_tickers = []
    for i, p in enumerate(picks, 1):
        print(f"\n[{i}/{len(picks)}] === {p['sym']} ===", flush=True)
        success = False
        for attempt in range(2):
            try:
                res = run_one_stock(p['sym'], p['name'], p['sector'],
                                    args.start, args.end, sl_percent=args.sl_percent)
                if res:
                    results.append(res)
                    success = True
                    break
                else:
                    wait = 5 * (attempt + 1)
                    print(f"  [retry {attempt+1}/2] No data, waiting {wait}s...", flush=True)
                    time.sleep(wait)
            except Exception as e:
                print(f"  [ERROR] {e}", flush=True)
                import traceback; traceback.print_exc()
                time.sleep(5)
        if not success:
            failed_tickers.append(p['sym'])
        time.sleep(1.5)

    if failed_tickers:
        print(f"\n[WARN] Failed tickers: {failed_tickers}")
        # Try replacement picks from a different seed
        with open(_SMALLCAP_PATH) as f:
            universe = json.load(f)
        used_syms = {p['sym'] for p in picks}
        rng = random.Random(args.seed + 999)
        replacements = [s for s in universe if s['sym'] not in used_syms]
        rng.shuffle(replacements)

        for p in replacements[:len(failed_tickers) * 3]:
            if len(results) >= args.n:
                break
            print(f"\n[replacement] === {p['sym']} ===", flush=True)
            # Filter for pre-2024 listing
            try:
                probe = yf.download(p['sym'], start="2022-11-01", end="2022-12-01",
                                    progress=False, auto_adjust=True)
                if probe is None or probe.empty:
                    print(f"  SKIP: no 2022 data (likely listed after 2022)")
                    continue
                if pd.Timestamp(probe.index[0]) >= pd.Timestamp("2024-01-01"):
                    print(f"  SKIP: first bar {probe.index[0].date()} >= 2024-01-01")
                    continue
                print(f"  OK: first bar {probe.index[0].date()}")
            except Exception:
                continue
            time.sleep(0.8)
            try:
                res = run_one_stock(p['sym'], p['name'], p['sector'],
                                    args.start, args.end, sl_percent=args.sl_percent)
                if res:
                    results.append(res)
            except Exception as e:
                print(f"  [ERROR] {e}")
            time.sleep(2.5)

    if not results:
        print("\n[FAIL] No successful backtests. Aborting.")
        return

    # Generate consolidated report
    today_str = datetime.now().strftime('%d%m%y')
    version = 1
    while True:
        out_name = f"Apollo_Engine_BT_{today_str}_v{version}_N{len(results)}_SL{int(args.sl_percent)}.xlsx"
        out_path = _DOWNLOAD_DIR / out_name
        if not out_path.exists():
            break
        version += 1

    print(f"\n{'='*70}")
    print(f"Generating consolidated v4 report: {out_name}")
    print(f"{'='*70}")
    generate_consolidated_report_v4(results, args.start, args.end, out_path,
                                     sl_percent=args.sl_percent)

    print(f"\n{'='*70}")
    print(f"  BACKTEST COMPLETE (v4 with SL)")
    print(f"  Stocks: {len(results)}")
    print(f"  Avg P&L: {np.mean([r['cum_pnl'] for r in results]):+.1f}%")
    print(f"  Best:    {max(r['cum_pnl'] for r in results):+.1f}%")
    print(f"  Worst:   {min(r['cum_pnl'] for r in results):+.1f}%")
    total_sl = sum(len(r.get('sl_exits', [])) for r in results)
    total_completed = sum(len(r['completed']) for r in results)
    print(f"  SL hits: {total_sl}/{total_completed} trades ({total_sl/total_completed*100:.1f}%)")
    print(f"  Report:  {out_path}")
    print(f"{'='*70}")

    return out_path


if __name__ == "__main__":
    main()
