# Apollo Engine — Stock Bucketing Framework (v5 addendum)

## Why bucket stocks?

The v4/v5 backtests on 5 stocks revealed that Apollo's recovery-detection thesis
works very well on some stocks (KAYNES +120%) and disastrously on others
(CENTRALBK -55%). A single set of signals + thresholds cannot be optimal across
all stocks. **Bucketing** lets us tune the engine per regime.

The proposed framework is:
1. **Classify** each stock into a bucket based on observable behavior
2. **Tune** signal weights, entry/exit thresholds, and stop-loss per bucket
3. **Validate** on out-of-sample data per bucket

---

## The 5 proposed buckets

| # | Bucket | Trend Bias | Volatility | ADX Profile | Beta to Nifty | Apollo fit |
|---|--------|-----------|------------|-------------|---------------|-----------|
| **1** | **Strong Uptrend** | Strongly bullish | Moderate | ADX > 25, +DI > -DI persistently | > 1.2 | Excellent |
| **2** | **Cyclical / Range-Bound** | Neutral | Moderate | ADX < 20, +DI/-DI flip often | 0.7 – 1.2 | Good (with adjustments) |
| **3** | **High Volatility / News-Driven** | Either | Very high | ADX spikes > 40 on events | Variable | Poor (SL too tight) |
| **4** | **Downtrend / Distressed** | Strongly bearish | High | ADX > 25, -DI > +DI persistently | < 0.5 (negative often) | Bad (avoid) |
| **5** | **Low Liquidity / Microcap** | Either | High (illiquid) | Unreliable | N/A | Bad (signal noise) |

---

## Bucket characteristics (detailed)

### Bucket 1 — Strong Uptrend
**Identification (all must be true over trailing 6 months):**
- Price > 200-DMA AND 200-DMA rising (slope > 0)
- ADX(14) > 25 on > 70% of days
- +DI > -DI on > 65% of days
- 52-week price range: current price in top 30%
- Annualized volatility < 40%

**Typical NSE examples:** Large-cap leaders like RELIANCE (in bull phases), TITAN,
ASIANPAINT, ITC. Among smallcaps: KAYNES, FINCABLES (from our backtests).

**Behavior:** Recovery-detection signals fire correctly. RSI troughs mark genuine
buying opportunities. WC21/WC50 crossovers confirm trend continuation.

**Recommended tuning for Apollo:**
- Entry threshold: 70 (default) ✓
- Exit threshold: 50 (default) ✓
- SL: **Trailing 7-8% from peak** (wider than default — give trend room to breathe)
- Position size: 60-70% on STANDARD, 100% on FULL
- Prefer divergence exit over score-based exit

### Bucket 2 — Cyclical / Range-Bound
**Identification:**
- Price oscillates around 200-DMA (within ±10%)
- ADX(14) < 20 on > 60% of days
- +DI/-DI crossover happens > 6 times in 6 months
- 52-week price range: current price in middle 40%
- Annualized volatility 20-35%

**Typical NSE examples:** FMCG (HINDUNILVR, NESTLEIND), IT large-caps in consolidation
(INFY, WIPRO), pharma (SUNPHARMA, CIPLA). Among our backtests: ZYDUSWELL, RAINBOW.

**Behavior:** RSI troughs mark swing-trading bottoms. Recovery momentum works
but exits must be quick — gains revert. Divergence exits fire too late.

**Recommended tuning for Apollo:**
- Entry threshold: **75** (higher — demand stronger confirmation in choppy tape)
- Exit threshold: **55** (earlier exit — take profits faster)
- SL: **Fixed 5% from entry** (tight — range-bound stocks shouldn't gap much)
- Position size: 40-50% on STANDARD (smaller — lower conviction)
- **Disable divergence exit** (it's a trend-following exit; doesn't work in ranges)
- Add mean-reversion exit: if RSI > 70 AND price > TP28 × 1.05, exit

### Bucket 3 — High Volatility / News-Driven
**Identification:**
- Annualized volatility > 60%
- Average true range (ATR-14) / price > 5%
- ADX(14) > 40 on > 20% of days (spiky, not persistent)
- > 5 days with |return| > 7% in trailing 6 months
- Often: small floats, sector momentum stocks, recent IPOs

**Typical NSE examples:** ADANIENT, ADANIPORTS, IRFC, rail PSUs in 2024. Among our
backtests: OLAELEC, parts of CENTRALBK's behavior.

**Behavior:** Signals are noisy. RSI troughs often mark deeper declines to come.
Stop-losses fire too frequently. The engine is fundamentally not designed for
this regime.

**Recommended tuning for Apollo:**
- **Skip this bucket entirely** — Apollo is a recovery-detection engine, not a
  momentum-chasing engine
- If forced to trade: Entry threshold 85 (very high), SL 10-12% (very wide),
  position size 25% max
- Add VIX filter: skip entry if India VIX > 20

### Bucket 4 — Downtrend / Distressed
**Identification:**
- Price < 200-DMA AND 200-DMA falling
- ADX(14) > 25 with **-DI > +DI persistently** (mirror of Bucket 1)
- 52-week price range: current price in bottom 30%
- Often: fundamental deterioration (earnings decline, debt issues, regulatory action)

**Typical NSE examples:** Yes Bank (2019-2020), Vodafone Idea, PC Jeweller.
Among our backtests: **CENTRALBK fits here** — persistent -DI dominance, 7 SL hits.

**Behavior:** RSI troughs mark **false bottoms** — the stock keeps falling. The
engine's recovery thesis is exactly wrong for these stocks.

**Recommended tuning for Apollo:**
- **Skip this bucket entirely**
- If a long position is forced: SL 3% (very tight), no divergence exit (it'll fire
  on noise), exit on first +DI/-DI bearish crossover
- Add fundamental filter: skip if revenue declined > 15% YoY in latest quarter

### Bucket 5 — Low Liquidity / Microcap
**Identification:**
- Average daily volume < ₹5 crore (₹50 million) over trailing 3 months
- Bid-ask spread > 0.5% on typical day
- Often: market cap < ₹1,500 crore

**Typical NSE examples:** Many Smallcap250 names at the bottom of the liquidity
spectrum. Hard to identify without volume data.

**Behavior:** Indicators work but execution doesn't. Backtest P&L is illusory —
real fills will be 2-5% worse than assumed. Stop-losses can't be honored (no
liquidity at the SL price).

**Recommended tuning for Apollo:**
- **Skip this bucket for live trading**; backtest only
- If traded: assume 2% slippage on every entry/exit, position size < ₹5 lakh

---

## How to assign a stock to a bucket (operational procedure)

Run this script quarterly (or monthly for volatile portfolios):

```python
import sys
sys.path.insert(0, "/home/z/my-project/repo/Apollo_extracted")
from apollo_engine.indicators import compute_adx
from data_cache import get_stock_data

def classify_bucket(symbol, lookback_days=126):
    """Classify a stock into one of 5 buckets based on trailing 6 months."""
    df_d, _, _ = get_stock_data(symbol, "2023-01-01", "2025-07-14")
    if df_d is None: return "UNKNOWN"
    df = df_d.tail(lookback_days).copy()

    # 200-DMA (use 200 daily bars ≈ 9 months — adjust if lookback shorter)
    dma_200 = df['close'].rolling(200).mean().iloc[-1] if len(df_d) >= 200 else df['close'].mean()
    current = df['close'].iloc[-1]
    price_above_dma = current > dma_200
    dma_slope = (dma_200 - df['close'].rolling(200).mean().iloc[-22]) / 22 if len(df_d) >= 222 else 0  # 1-month slope

    # ADX profile
    plus_di, minus_di, adx = compute_adx(df[['high', 'low', 'close']].rename(
        columns={'high': 'High', 'low': 'Low', 'close': 'Close'}), 14)
    adx_clean = adx.dropna()
    pct_adx_above_25 = (adx_clean > 25).sum() / len(adx_clean) if len(adx_clean) > 0 else 0
    pct_plus_di_above = (plus_di.dropna() > minus_di.dropna()).sum() / max(len(plus_di.dropna()), 1)

    # Volatility (annualized)
    rets = df['close'].pct_change().dropna()
    vol_annual = rets.std() * (252 ** 0.5) * 100

    # 52-week range
    high_52w = df['high'].max()
    low_52w = df['low'].min()
    pct_of_range = (current - low_52w) / (high_52w - low_52w) if high_52w > low_52w else 0.5

    # Volume (last 63 days)
    avg_vol_value = (df['volume'] * df['close']).tail(63).mean()

    # --- Classification ---
    # Bucket 5: low liquidity
    if avg_vol_value < 5e7:  # ₹5 crore/day
        return "5_LOW_LIQUIDITY"

    # Bucket 3: high volatility
    if vol_annual > 60:
        return "3_HIGH_VOLATILITY"

    # Bucket 4: downtrend
    if not price_above_dma and dma_slope < 0 and pct_plus_di_above < 0.40:
        return "4_DOWNTREND"

    # Bucket 1: strong uptrend
    if price_above_dma and dma_slope > 0 and pct_adx_above_25 > 0.60 and pct_plus_di_above > 0.60:
        return "1_STRONG_UPTREND"

    # Bucket 2: cyclical / range-bound (default for moderate-vol stocks)
    return "2_CYCLICAL_RANGE_BOUND"


# Apply to our 5 backtested stocks
for sym in ["KAYNES.NS", "VTL.NS", "ZYDUSWELL.NS", "RAINBOW.NS", "CENTRALBK.NS"]:
    bucket = classify_bucket(sym)
    print(f"  {sym}: {bucket}")
```

### Expected bucket assignments for our 5 backtested stocks

| Stock | Expected Bucket | Reasoning |
|-------|-----------------|-----------|
| KAYNES.NS | 1_STRONG_UPTREND | +120% in 18 months, persistent +DI dominance |
| VTL.NS | 2_CYCLICAL_RANGE_BOUND | Textile cyclicality, +27% with moderate vol |
| ZYDUSWELL.NS | 2_CYCLICAL_RANGE_BOUND | FMCG consolidation, +27% range-bound |
| RAINBOW.NS | 2_CYCLICAL_RANGE_BOUND | Healthcare, +30% with periodic drawdowns |
| CENTRALBK.NS | 4_DOWNTREND | -55% with persistent -DI dominance → Apollo should have SKIPPED this stock |

---

## How bucketing changes Apollo's workflow

**v5 (current):** Single config → backtest all stocks → produce one report
**v6 (proposed):**

```
1. Universe selection (e.g., Smallcap250)
2. Bucket classification (run classify_bucket on each stock)
3. Filter: drop Bucket 4 (downtrend) and Bucket 5 (low liquidity) entirely
4. Per-bucket backtest:
   - Bucket 1: run with trailing SL 7%, divergence exit enabled
   - Bucket 2: run with fixed SL 5%, divergence exit disabled, mean-reversion exit enabled
   - Bucket 3: skip (or run with very conservative config)
5. Consolidated report with per-bucket sections + cross-bucket ranking
```

**Expected impact:** Avoid the CENTRALBK-style disasters (would have been filtered
out as Bucket 4) while letting Bucket 1 stocks (KAYNES) run with wider trailing
stops that don't choke the trend.

---

## Open questions for user

1. **Bucket 3 (high volatility):** Should we skip entirely, or attempt to trade
   with conservative config? My recommendation: skip.
2. **Bucket 4 (downtrend):** Should we allow short-side strategies in a future
   version? Apollo is long-only today.
3. **Reclassification frequency:** Monthly or quarterly? My recommendation:
   quarterly for most stocks, monthly for Bucket 3 candidates.
4. **Should bucketing be a charter rule?** Proposed Rule 10:

> **Rule 10 (new) — Stock Bucketing**
> Every backtest MUST classify each stock into one of 5 buckets
> (Strong Uptrend, Cyclical, High Volatility, Downtrend, Low Liquidity)
> using documented criteria. The report MUST include a Bucket Assignment
> sheet showing each stock's bucket + the metrics that drove the assignment.
> Stocks in Bucket 4 (Downtrend) and Bucket 5 (Low Liquidity) MUST be
> flagged as "skip" with rationale; their backtest results (if any) MUST
> be quarantined to a separate sheet, not included in the main ranking.
