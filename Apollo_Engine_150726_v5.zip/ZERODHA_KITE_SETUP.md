# Zerodha Kite Connect — Setup Guide for Apollo Engine

This guide walks you through registering for Kite Connect, authenticating, and
fetching **real 4H historical data** for NSE stocks to replace the synthetic 4H
bars that Apollo v3 generates by default.

---

## 1. Subscription Tiers (read this first)

| Tier | Cost | What you get | Apollo use case |
|------|------|--------------|-----------------|
| **Free** | ₹0 | Daily historical (last 10+ years) + 60 days of intraday (1m/5m/15m/60m) + live quotes | Daily-only backtests. **Not enough** for 4H from 2024-01-01. |
| **Connect** | ₹2,000/month (₹1,000 additional historical data add-on) | All free + intraday historical up to 2,000 days | **Required** for real 4H backtests going back to 2024. |
| **Commercial** | ₹6,000/month | Higher rate limits, commercial usage rights | Only if distributing to clients. |

**For your use case (backtesting Smallcap250 from 2024-01-01 onward):**
- The free tier gets you **daily** data for free — but Apollo v3 already uses
  yfinance for that, so no benefit.
- For **real 4H bars**, you need the **Connect subscription** (₹2,000/month).
  A 7-day free trial is available — sufficient to run a one-off backtest.

---

## 2. Registration (5 minutes)

1. **Go to** `https://developers.kite.trade/`
2. **Sign in** with your Zerodha Kite credentials (the same login you use for trading).
3. **Create an app**:
   - Click "My Apps" → "New App"
   - App name: `apollo-backtest` (anything)
   - Description: `Backtesting engine`
   - Redirect URL: `http://127.0.0.1:8000/callback` (placeholder; we use manual flow)
   - Category: `Personal`
4. **Save** the app. You'll see:
   - `api_key` (public, looks like `abc123xyz`)
   - `api_secret` (private, looks like `def456uvw` — keep this safe)
5. **Subscribe** to "Connect" plan if you need intraday >60 days.

---

## 3. Authentication (every trading day)

Kite access tokens are **valid for one trading day** (until 6 AM IST next day).
You must regenerate the token each day you want to fetch fresh data.

### Step 3a: Get the request token (manual login)

Construct this URL in your browser (replace `YOUR_API_KEY`):

```
https://kite.trade/connect/login?api_key=YOUR_API_KEY&v=3
```

1. You'll be redirected to the Zerodha login page.
2. Log in with your Zerodha credentials + 2FA.
3. After successful login, you'll be redirected to your redirect URL with a
   `request_token` query parameter:
   ```
   http://127.0.0.1:8000/callback?status=success&request_token=abc123def456...
   ```
4. Copy the `request_token` value.

### Step 3b: Exchange for access token

```python
from kiteconnect import KiteConnect

kite = KiteConnect(api_key="YOUR_API_KEY")
data = kite.generate_session(
    request_token="YOUR_REQUEST_TOKEN",
    api_secret="YOUR_API_SECRET"
)
access_token = data["access_token"]
kite.set_access_token(access_token)
print(f"Access token valid until 6 AM IST tomorrow: {access_token}")
```

**Tip:** Save the access token to a file (e.g. `~/.kite_token`) and load it
in your scripts. You only need to re-run the manual login flow once per day.

---

## 4. Fetch historical data

### 4a. Get instrument tokens (run once, cache forever)

Kite uses numeric `instrument_token` (not the ticker symbol) for historical
queries. Download the instruments list and look up tokens:

```python
import pandas as pd

# Download instruments dump (refresh daily)
instruments = pd.read_csv("https://api.kite.trade/instruments")
# Filter NSE stocks
nse_eq = instruments[(instruments.exchange == "NSE") & (instruments.instrument_type == "EQ")]
# Save for offline lookup
nse_eq.to_csv("nse_instruments.csv", index=False)

# Look up a token
def get_token(symbol: str) -> int:
    return int(nse_eq[nse_eq.tradingsymbol == symbol].instrument_token.iloc[0])

print(get_token("RELIANCE"))  # e.g. 779521
```

### 4b. Fetch daily candles (free tier)

```python
from datetime import datetime
from kiteconnect import KiteConnect

kite = KiteConnect(api_key="YOUR_API_KEY")
kite.set_access_token("YOUR_ACCESS_TOKEN")

daily = kite.historical_data(
    instrument_token=779521,  # RELIANCE
    from_date=datetime(2023, 1, 1),
    to_date=datetime(2025, 7, 14),
    interval="day",
)
df_daily = pd.DataFrame(daily)
print(df_daily.head())
# Columns: date, open, high, low, close, volume
```

### 4c. Fetch 1H candles and aggregate to 4H (paid tier required for >60 days)

```python
intraday = kite.historical_data(
    instrument_token=779521,
    from_date=datetime(2024, 1, 1),
    to_date=datetime(2025, 7, 14),
    interval="60minute",  # 1H
)
df_1h = pd.DataFrame(intraday)
df_1h['date'] = pd.to_datetime(df_1h['date'])
df_1h = df_1h.set_index('date').sort_index()

# Aggregate to 4H using Apollo's built-in aggregator
import sys
sys.path.insert(0, "/path/to/Apollo_extracted")
from apollo_engine.data_loader import aggregate_intraday_to_4h

df_4h = aggregate_intraday_to_4h(df_1h)
print(f"4H bars: {len(df_4h)}")  # ~2 bars per trading day, ~750 bars total
```

---

## 5. Integrating real 4H data into Apollo v3

Once you have real 4H bars, replace the synthetic synthesizer call in
`run_backtest_v3.py`:

```python
# BEFORE (synthetic)
df_4h = synthesize_4h_from_daily(df_d_raw[['open', 'high', 'low', 'close', 'volume']])

# AFTER (real Kite data)
df_4h = fetch_kite_4h(symbol, start, end)  # your function
df_4h = compute_all_indicators(df_4h)       # add Apollo indicator columns
df_4h['rsi21'] = df_4h['RSI rsi (21,C)']
df_4h['rsi36'] = df_4h['RSI rsi (36)']
df_4h['tp28']  = df_4h['Result Typical Price (28,n)']
df_4h['wc50']  = df_4h['Result Weighted Close (50,y)']
df_4h['wc21']  = df_4h['Result Weighted Close (21)']
df_4h.columns = [c.lower() for c in df_4h.columns]
```

The engine code itself needs **no changes** — the auto-compute feature detects
existing indicator columns and uses them as-is.

---

## 6. Rate limits

| Endpoint | Free | Connect |
|----------|------|---------|
| `historical_data` | 3 calls / sec | 10 calls / sec |
| `instruments` | 1 call / day | 1 call / day |
| `quote` (live) | 1 call / 3 sec | 1 call / sec |

For a 5-stock backtest fetching 18 months of 1H data: 5 calls × ~2 sec each
(per call returns ~2,000 candles). **Total: ~10 seconds.** Well within free-tier
rate limits — except the 60-day cap on intraday history.

---

## 7. Common pitfalls

1. **`TokenException: Token is invalid or has expired.`**
   Access tokens expire at 6 AM IST. Re-run the manual login flow.

2. **`KiteException: Too many requests.`**
   Add `time.sleep(0.5)` between calls or use a rate-limiter.

3. **`HistoricalException: from_date cannot be more than 60 days back for interval minute.`**
   You're on the free tier. Either subscribe to Connect, or fetch in 60-day
   chunks (still won't help for 18 months — you need the subscription).

4. **Wrong instrument token.**
   Tokens are unique per exchange. NSE RELIANCE ≠ BSE RELIANCE. Always filter
   `instruments.csv` by `exchange == "NSE"` first.

5. **Adjusted vs unadjusted prices.**
   Kite returns **unadjusted** historical data (raw prices including splits/
   bonuses). For backtests, you typically want **adjusted** data. Apollo v3's
   yfinance path uses `auto_adjust=True` for consistency. If you use Kite,
   either apply corporate action adjustments yourself, or stick with yfinance
   for daily data.

---

## 8. Cost-benefit summary

| Source | Daily | 4H (real) | Cost | Setup effort |
|--------|-------|-----------|------|--------------|
| **yfinance** (current v3 default) | ✅ Free | ❌ Synthetic only | ₹0 | None |
| **Kite Free** | ✅ Free | ⚠️ Only last 60 days | ₹0 | 5 min |
| **Kite Connect** | ✅ Free | ✅ 2,000 days back | ₹2,000/month | 10 min |
| **Kite + Historical add-on** | ✅ Free | ✅ Full history | ₹3,000/month | 10 min |
| **GlobalDatafeeds / Truedata** | ✅ | ✅ Tick-level | ₹5,000+/month | 30+ min |

**Recommendation**: Start with yfinance + synthetic 4H (free, what v3 does now).
If the backtest shows promise, subscribe to Kite Connect for one month (~₹2,000),
re-run with real 4H data, and compare results. If synthetic vs real 4H produce
materially different signals, you have a clear case for ongoing Kite subscription.
