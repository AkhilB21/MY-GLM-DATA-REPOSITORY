"""
Apollo Engine v5 — Exit Mode Comparison.

Three exit modes (in addition to baseline score<50 + divergence exits):

  1. FIXED_SL    — 5% hard stop from entry, exit at min(open, SL_price)
                   (realistic gap-down handling, fixes v4's close-only bug)
  2. TRAILING_SL — 5% stop from peak close (trails upward as price rises)
                   exit at min(open, SL_price)
  3. DI_CROSSOVER — exit when +DI crosses below -DI (bearish directional crossover)
                    checked on daily bars; if +DI[t-1] > -DI[t-1] and +DI[t] < -DI[t], exit

All three modes share the same ENTRY logic (score >= 70) and the same
5-day cooldown after any non-score exit.

Backward compatible: v4's --sl-percent flag still works (maps to FIXED_SL).
Use --exit-mode to pick a specific mode; --compare-all runs all three.

Usage:
  python run_backtest_v5.py --tickers KAYNES.NS,VTL.NS,ZYDUSWELL.NS,RAINBOW.NS,CENTRALBK.NS --compare-all
  python run_backtest_v5.py --exit-mode TRAILING_SL --sl-percent 5
  python run_backtest_v5.py --exit-mode DI_CROSSOVER
"""
import sys
import os
import re
import json
import random
import time
import argparse
import types
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import yfinance as yf
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

_SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPT_DIR))

from apollo_engine.data_loader import synthesize_4h_from_daily, resample_weekly
from apollo_engine.indicators import compute_all_indicators

# Import v4
import importlib.util
_spec_v4 = importlib.util.spec_from_file_location("run_backtest_v4", _SCRIPT_DIR / "run_backtest_v4.py")
v4 = importlib.util.module_from_spec(_spec_v4)
_spec_v4.loader.exec_module(v4)

# Re-use v4 helpers
pick_random_stocks_filtered = v4.pick_random_stocks_filtered
fetch_yfinance_daily = v4.fetch_yfinance_daily
SIGNAL_DEFS = v4.SIGNAL_DEFS
POOL_MAX = v4.POOL_MAX
POOL_ORDER = v4.POOL_ORDER
POOL_NAMES = v4.POOL_NAMES
POOL_DESC = v4.POOL_DESC
eval_signals = v4.eval_signals
detect_troughs = v4.detect_troughs
get_latest_trough_pos = v4.get_latest_trough_pos
compute_weekly_rsi = v4.compute_weekly_rsi
classify_score = v4.classify_score

# Constants (v4 imports these from v3, which imports from v2 — access via v4.v3 chain)
ENTRY_THRESHOLD = v4.v3.ENTRY_THRESHOLD    # 70
EXIT_THRESHOLD = v4.v3.EXIT_THRESHOLD      # 50
DIVERGENCE_RSI_DROP = v4.v3.DIVERGENCE_RSI_DROP  # 3.0
DIVERGENCE_COOLDOWN = v4.v3.DIVERGENCE_COOLDOWN  # 5

_DOWNLOAD_DIR = Path("/home/z/my-project/download")
_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

EXIT_MODES = ["NONE", "FIXED_SL", "TRAILING_SL", "DI_CROSSOVER"]


# ---------------------------------------------------------------------------
# Unified trade extractor with selectable exit mode
# ---------------------------------------------------------------------------

def extract_trades_v5(daily_results, df_d, exit_mode: str = "FIXED_SL",
                      sl_percent: float = 5.0):
    """Extract trades with selectable exit mode (v5).

    exit_mode:
      - "NONE":        Only score<50 and divergence exits (v3 behavior)
      - "FIXED_SL":    5% hard stop from entry price (v4, but with realistic fill)
      - "TRAILING_SL": 5% stop from peak close (trails upward)
      - "DI_CROSSOVER": Exit when +DI crosses below -DI (bearish directional)

    All exit modes use min(open, SL_price) for fill price (fixes v4 gap-down bug).
    Period-end open trades always marked PERIOD_END.
    """
    events = []
    in_trade = False
    entry_price = None
    entry_date = None
    cooldown_until = None

    peak_rsi = None
    peak_rsi_price = None
    peak_rsi_date = None

    # For trailing SL
    peak_close = None

    # For DI crossover (need previous bar's +DI / -DI)
    prev_plus_di = None
    prev_minus_di = None

    sl_threshold_mult = 1.0 - sl_percent / 100.0 if sl_percent > 0 else 0.0

    for i, r in enumerate(daily_results):
        date = r['date']
        score = r['total']
        close = r['close']
        open_price = df_d['open'].iloc[df_d.index.get_loc(date)] if date in df_d.index else close
        rsi = r['rsi21']
        action = r['action']

        # Current +DI/-DI from df_d (already pre-computed)
        try:
            cur_plus_di = df_d['plus_di'].iloc[df_d.index.get_loc(date)]
            cur_minus_di = df_d['minus_di'].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_plus_di = np.nan
            cur_minus_di = np.nan

        # --- In-trade checks ---
        if in_trade:
            exit_event = None

            # Update peak close for trailing SL
            if exit_mode == "TRAILING_SL" and close > peak_close:
                peak_close = close

            # 1. Determine exit triggered (precedence: SL/crossover > divergence > score)
            trigger = None
            fill_price = None

            if exit_mode == "FIXED_SL" and sl_percent > 0:
                sl_price = entry_price * sl_threshold_mult
                if close <= sl_price or open_price <= sl_price:
                    # Realistic fill: min(open, sl_price) — handles gap-down
                    fill_price = min(open_price, sl_price)
                    trigger = "FIXED_SL"

            elif exit_mode == "TRAILING_SL" and sl_percent > 0 and peak_close is not None:
                sl_price = peak_close * sl_threshold_mult
                if close <= sl_price or open_price <= sl_price:
                    fill_price = min(open_price, sl_price)
                    trigger = "TRAILING_SL"

            elif exit_mode == "DI_CROSSOVER":
                # Bearish crossover: prev +DI > -DI, current +DI < -DI
                if (prev_plus_di is not None and prev_minus_di is not None and
                    not np.isnan(cur_plus_di) and not np.isnan(cur_minus_di) and
                    prev_plus_di > prev_minus_di and cur_plus_di < cur_minus_di):
                    fill_price = close  # no SL price; exit at close
                    trigger = "DI_CROSSOVER"

            if trigger is not None:
                pnl = (fill_price - entry_price) / entry_price * 100.0
                if trigger == "FIXED_SL":
                    reason = f"SL_HIT (-{sl_percent}% fixed from entry {entry_price:.2f}, fill ₹{fill_price:.2f})"
                    classification = "SL EXIT"
                elif trigger == "TRAILING_SL":
                    reason = (f"TRAILING_SL (-{sl_percent}% from peak {peak_close:.2f}, "
                              f"fill ₹{fill_price:.2f})")
                    classification = "TRAILING SL EXIT"
                elif trigger == "DI_CROSSOVER":
                    reason = (f"DI_CROSSOVER (+DI {prev_plus_di:.1f}→{cur_plus_di:.1f}, "
                              f"-DI {prev_minus_di:.1f}→{cur_minus_di:.1f})")
                    classification = "DI CROSSOVER EXIT"

                events.append({
                    'type': 'EXIT', 'date': date, 'close': fill_price,
                    'score': round(score, 2), 'classification': classification,
                    'entry_price': entry_price, 'entry_date': entry_date,
                    'pnl': round(pnl, 2), 'exit_reason': reason,
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })
                in_trade = False
                cooldown_until = i + DIVERGENCE_COOLDOWN
                peak_rsi = None; peak_rsi_price = None; peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di; prev_minus_di = cur_minus_di
                continue

            # 2. Check divergence exit
            if peak_rsi is not None and rsi > peak_rsi:
                peak_rsi = rsi
                peak_rsi_price = df_d['high'].iloc[
                    df_d.index.get_loc(date)] if date in df_d.index else close
                peak_rsi_date = date

            if (peak_rsi is not None and peak_rsi_price is not None and
                close > peak_rsi_price and rsi < (peak_rsi - DIVERGENCE_RSI_DROP)):
                pnl = (close - entry_price) / entry_price * 100.0
                rsi_drop = round(peak_rsi - rsi, 2)
                strength = "STRONG" if rsi_drop > 5 else "MODERATE"
                events.append({
                    'type': 'EXIT', 'date': date, 'close': close,
                    'score': round(score, 2), 'classification': 'DIVERGENCE EXIT',
                    'entry_price': entry_price, 'entry_date': entry_date,
                    'pnl': round(pnl, 2),
                    'exit_reason': f"DIVERGENCE ({strength}, RSI {peak_rsi:.2f}->{rsi:.2f}, drop={rsi_drop}pts)",
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })
                in_trade = False
                cooldown_until = i + DIVERGENCE_COOLDOWN
                peak_rsi = None; peak_rsi_price = None; peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di; prev_minus_di = cur_minus_di
                continue

            # 3. Score-based exit
            if score < EXIT_THRESHOLD:
                pnl = (close - entry_price) / entry_price * 100.0
                events.append({
                    'type': 'EXIT', 'date': date, 'close': close,
                    'score': round(score, 2), 'classification': 'EXIT',
                    'entry_price': entry_price, 'entry_date': entry_date,
                    'pnl': round(pnl, 2), 'exit_reason': 'SCORE<50',
                    'bars_from_trough': r['bars_from_trough'],
                    'pool_a': round(r['pool_a'], 2),
                    'pool_b': round(r['pool_b'], 2),
                    'pool_c': round(r['pool_c'], 2),
                    'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
                })
                in_trade = False
                peak_rsi = None; peak_rsi_price = None; peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di; prev_minus_di = cur_minus_di
                continue

            # 4. Hold
            if score >= 90: hold_type = 'HOLD-FULL STRONG'
            elif score >= 80: hold_type = 'HOLD-FULL'
            elif score >= 70: hold_type = 'HOLD-STD'
            else: hold_type = 'WATCHLIST'
            events.append({
                'type': hold_type, 'date': date, 'close': close,
                'score': round(score, 2), 'classification': action,
                'entry_price': entry_price, 'entry_date': entry_date,
                'bars_from_trough': r['bars_from_trough'],
                'pool_a': round(r['pool_a'], 2),
                'pool_b': round(r['pool_b'], 2),
                'pool_c': round(r['pool_c'], 2),
                'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
            })
            prev_plus_di = cur_plus_di; prev_minus_di = cur_minus_di
            continue

        # --- Not in trade: check entry ---
        if not in_trade and score >= ENTRY_THRESHOLD:
            if cooldown_until is not None and i < cooldown_until:
                prev_plus_di = cur_plus_di; prev_minus_di = cur_minus_di
                continue
            in_trade = True
            entry_price = close
            entry_date = date
            peak_rsi = rsi
            peak_rsi_price = df_d['high'].iloc[
                df_d.index.get_loc(date)] if date in df_d.index else close
            peak_rsi_date = date
            peak_close = close  # initialize trailing-SL peak
            events.append({
                'type': 'ENTRY', 'date': date, 'close': close,
                'score': round(score, 2), 'classification': action,
                'entry_price': close, 'entry_date': date,
                'bars_from_trough': r['bars_from_trough'],
                'pool_a': round(r['pool_a'], 2),
                'pool_b': round(r['pool_b'], 2),
                'pool_c': round(r['pool_c'], 2),
                'bonus': round(r['bonus_a'] + r['bonus_b'] + r['bonus_c'], 2),
            })

        prev_plus_di = cur_plus_di
        prev_minus_di = cur_minus_di

    # Period-end exit
    if in_trade:
        last = daily_results[-1]
        pnl = (last['close'] - entry_price) / entry_price * 100.0
        events.append({
            'type': 'EXIT', 'date': last['date'], 'close': last['close'],
            'score': round(last['total'], 2), 'classification': 'EXIT',
            'entry_price': entry_price, 'entry_date': entry_date,
            'pnl': round(pnl, 2), 'exit_reason': 'PERIOD_END',
            'bars_from_trough': last['bars_from_trough'],
            'pool_a': round(last['pool_a'], 2),
            'pool_b': round(last['pool_b'], 2),
            'pool_c': round(last['pool_c'], 2),
            'bonus': round(last['bonus_a'] + last['bonus_b'] + last['bonus_c'], 2),
        })

    return events


def run_backtest_v5(df_d, df_4h, df_w, start_date, end_date,
                    exit_mode: str = "FIXED_SL", sl_percent: float = 5.0):
    """Run backtest with selectable exit mode."""
    d_rsi21 = df_d['rsi21']; d_rsi36 = df_d['rsi36']; d_rsi56 = df_d['rsi56']
    h_rsi21 = df_4h['rsi21']; h_rsi36 = df_4h['rsi36']
    w_rsi21 = compute_weekly_rsi(df_w, 21); w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di = df_d['plus_di']; minus_di = df_d['minus_di']; macd_line = df_d['macd']
    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    crossover_prices = []
    prev_above = False; xover_price = None
    for i in range(len(df_4h)):
        c = df_4h['close'].iloc[i]
        w = df_4h['wc21'].iloc[i] if 'wc21' in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False; crossover_prices.append(None); continue
        cur_above = c > w
        if cur_above and not prev_above: xover_price = c
        elif not cur_above: xover_price = None
        prev_above = cur_above; crossover_prices.append(xover_price)

    start_ts = pd.Timestamp(start_date); end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    daily_indices = np.where(np.asarray(mask))[0]
    if len(daily_indices) == 0:
        return pd.DataFrame(), []

    daily_results = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any(): continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])
        mask_w = df_w.index <= bt_date
        if not mask_w.any(): continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line, b6_xover
        )
        pool_pts = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id)
        core = min(100, pool_pts['A'] + pool_pts['B'] + pool_pts['C'])
        bonus = pool_pts['BA'] + pool_pts['BB'] + pool_pts['BC']
        total = core + bonus
        action, pos_pct = classify_score(total)
        daily_results.append({
            'date': bt_date, 'close': df_d['close'].iloc[pos],
            'pool_a': pool_pts['A'], 'pool_b': pool_pts['B'], 'pool_c': pool_pts['C'],
            'bonus_a': pool_pts['BA'], 'bonus_b': pool_pts['BB'], 'bonus_c': pool_pts['BC'],
            'core': core, 'bonus': bonus, 'total': total,
            'action': action, 'pos_pct': pos_pct,
            'signals': sigs,
            'd_trough_pos': d_trough_pos,
            'bars_from_trough': pos - d_trough_pos if d_trough_pos is not None else None,
            'rsi21': d_rsi21.iloc[pos],
        })

    daily_df = pd.DataFrame([{k: v for k, v in r.items() if k != 'signals'} for r in daily_results])
    if daily_df.empty:
        return daily_df, []

    trades = extract_trades_v5(daily_results, df_d, exit_mode=exit_mode, sl_percent=sl_percent)
    return daily_df, trades


# ---------------------------------------------------------------------------
# Per-stock data: disk cache (avoids re-fetching yfinance every session)
# ---------------------------------------------------------------------------

# Add scripts/ dir to path for data_cache import
sys.path.insert(0, "/home/z/my-project/scripts")
from data_cache import get_stock_data as _get_cached_data

# In-memory cache for current session (prevents re-reading pickle within same run)
_STOCK_CACHE = {}

def get_stock_data(symbol, start_date, end_date, refresh=False):
    """Load from disk cache; fall back to fetch+cache if missing."""
    if symbol in _STOCK_CACHE and not refresh:
        return _STOCK_CACHE[symbol]
    # Use disk cache — fetches only if missing or stale
    df_d, df_4h, df_w = _get_cached_data(symbol, start_date, end_date, refresh=refresh)
    if df_d is None:
        _STOCK_CACHE[symbol] = None
        return None
    _STOCK_CACHE[symbol] = (df_d, df_4h, df_w)
    return _STOCK_CACHE[symbol]


# ---------------------------------------------------------------------------
# Run one stock with one exit mode
# ---------------------------------------------------------------------------

def run_one_stock_mode(symbol, name, sector, start_date, end_date,
                       exit_mode, sl_percent, refresh=False):
    cached = get_stock_data(symbol, start_date, end_date, refresh=refresh)
    if cached is None: return None
    df_d, df_4h, df_w = cached

    daily_df, trades = run_backtest_v5(df_d, df_4h, df_w, start_date, end_date,
                                       exit_mode=exit_mode, sl_percent=sl_percent)
    if daily_df.empty: return None

    entries = [e for e in trades if e['type'] == 'ENTRY']
    exits = [e for e in trades if e['type'] == 'EXIT']
    completed = [e for e in exits if 'pnl' in e and e.get('exit_reason') != '']
    cum_pnl = sum(e['pnl'] for e in completed) if completed else 0
    winning = [e for e in completed if e['pnl'] > 0]
    win_rate = round(len(winning) / len(completed) * 100, 0) if completed else 0
    sl_exits = [e for e in exits if 'SL_HIT' in e.get('exit_reason', '') or 'TRAILING_SL' in e.get('exit_reason', '')]
    div_exits = [e for e in exits if 'DIVERGENCE' in e.get('exit_reason', '')]
    di_exits = [e for e in exits if 'DI_CROSSOVER' in e.get('exit_reason', '')]
    score_exits = [e for e in exits if e.get('exit_reason') == 'SCORE<50']
    period_end_exits = [e for e in exits if e.get('exit_reason') == 'PERIOD_END']

    # Max drawdown (from peak cumulative P&L)
    pnl_series = [e['pnl'] for e in completed]
    if pnl_series:
        cum = np.cumsum(pnl_series)
        running_max = np.maximum.accumulate(cum)
        drawdowns = cum - running_max
        max_dd = round(float(min(drawdowns)) if len(drawdowns) > 0 else 0, 2)
    else:
        max_dd = 0.0

    return {
        'symbol': symbol, 'name': name, 'sector': sector,
        'exit_mode': exit_mode, 'sl_percent': sl_percent,
        'daily_df': daily_df, 'trades': trades,
        'entries': entries, 'completed': completed,
        'cum_pnl': cum_pnl, 'win_rate': win_rate,
        'avg_score': round(daily_df['total'].mean(), 1),
        'peak_score': round(daily_df['total'].max(), 2),
        'n_days': len(daily_df),
        'sl_exits': sl_exits, 'div_exits': div_exits,
        'di_exits': di_exits,
        'score_exits': score_exits, 'period_end_exits': period_end_exits,
        'max_drawdown': max_dd,
        'avg_pnl_per_trade': round(cum_pnl / len(completed), 2) if completed else 0,
    }


# ---------------------------------------------------------------------------
# Comparison report
# ---------------------------------------------------------------------------

def generate_comparison_report(all_results: list[dict], start_date: str, end_date: str,
                                output_path: Path, sl_percent: float = 5.0):
    """Generate comparison XLSX: one Summary sheet + per-stock per-mode sheets."""
    wb = Workbook()

    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    title_font = Font(bold=True, size=16, color="1F4E79")
    subtitle_font = Font(bold=True, size=11, color="4472C4")
    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    orange_fill = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
    sl_fill = PatternFill(start_color="FFD6D6", end_color="FFD6D6", fill_type="solid")
    di_fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
    thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                          top=Side(style='thin'), bottom=Side(style='thin'))

    def style_header(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.font = header_font; cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', wrap_text=True)
            cell.border = thin_border

    def style_data(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center')

    # Group results by stock
    stocks = sorted({r['symbol'] for r in all_results})
    modes = sorted({r['exit_mode'] for r in all_results})

    # ============ SHEET 1: Comparison Summary ============
    ws = wb.active
    ws.title = "Comparison"

    ws['B2'] = "Apollo Engine v5 — Exit Mode Comparison"
    ws['B2'].font = title_font
    ws.merge_cells('B2:K2')

    ws['B3'] = (f"{len(stocks)} stocks × {len(modes)} exit modes | "
                f"{start_date} to {end_date} | "
                f"SL: {sl_percent}% | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    ws['B3'].font = Font(size=10, color="666666")
    ws.merge_cells('B3:K3')

    ws['B5'] = "EXIT MODES TESTED"
    ws['B5'].font = subtitle_font
    mode_desc = {
        "NONE": "Baseline (no SL/crossover exit; only score<50 and divergence exits)",
        "FIXED_SL": f"5% hard stop from entry price; fill at min(open, SL_price) — fixes v4 gap-down bug",
        "TRAILING_SL": f"5% trailing stop from peak close; fill at min(open, SL_price)",
        "DI_CROSSOVER": "Exit when +DI crosses below -DI (bearish directional crossover); fill at close",
    }
    for i, m in enumerate(modes):
        ws.cell(6 + i, 2, m).font = Font(bold=True, size=10)
        ws.cell(6 + i, 3, mode_desc.get(m, "")).font = Font(size=10)
        ws.merge_cells(start_row=6+i, start_column=3, end_row=6+i, end_column=10)

    # Stock × Mode matrix
    r = 6 + len(modes) + 2
    ws.cell(r, 2, "STOCK × EXIT MODE — CUMULATIVE P&L %").font = subtitle_font
    r += 1
    headers = ["Symbol"] + modes + ["Best Mode", "Spread (best-worst)"]
    for i, h in enumerate(headers):
        ws.cell(r, 2+i, h)
    style_header(ws, r, len(headers) + 1)

    for si, sym in enumerate(stocks):
        row = r + 1 + si
        ws.cell(row, 2, sym).font = Font(bold=True)
        pnls = {}
        for mi, mode in enumerate(modes):
            matching = [x for x in all_results if x['symbol'] == sym and x['exit_mode'] == mode]
            if matching:
                pnl = matching[0]['cum_pnl']
                pnls[mode] = pnl
                cell = ws.cell(row, 3 + mi, f"{pnl:+.1f}%")
                if pnl > 0: cell.font = Font(color="006100", bold=True)
                else: cell.font = Font(color="C00000", bold=True)
            else:
                ws.cell(row, 3 + mi, "—")
        if pnls:
            best_mode = max(pnls, key=pnls.get)
            worst_mode = min(pnls, key=pnls.get)
            ws.cell(row, 3 + len(modes), best_mode)
            spread = pnls[best_mode] - pnls[worst_mode]
            ws.cell(row, 4 + len(modes), f"{spread:+.1f} pp")
        style_data(ws, row, len(headers) + 1)

    # Per-mode aggregate
    r = r + len(stocks) + 3
    ws.cell(r, 2, "PER-MODE AGGREGATE").font = subtitle_font
    r += 1
    agg_headers = ["Mode", "Avg P&L", "Total Trades", "Avg Win Rate",
                   "Avg Max DD", "SL/Crossover Exits", "Divergence Exits", "Score<50 Exits"]
    for i, h in enumerate(agg_headers):
        ws.cell(r, 2+i, h)
    style_header(ws, r, len(agg_headers) + 1)

    mode_summary = []
    for mi, mode in enumerate(modes):
        mode_results = [x for x in all_results if x['exit_mode'] == mode]
        if not mode_results: continue
        avg_pnl = np.mean([x['cum_pnl'] for x in mode_results])
        total_trades = sum(len(x['completed']) for x in mode_results)
        avg_wr = np.mean([x['win_rate'] for x in mode_results])
        avg_dd = np.mean([x['max_drawdown'] for x in mode_results])
        sl_total = sum(len(x.get('sl_exits', [])) for x in mode_results)
        div_total = sum(len(x.get('div_exits', [])) for x in mode_results)
        score_total = sum(len(x.get('score_exits', [])) for x in mode_results)
        row = r + 1 + mi
        ws.cell(row, 2, mode).font = Font(bold=True)
        cell = ws.cell(row, 3, f"{avg_pnl:+.1f}%")
        cell.font = Font(bold=True, color="006100" if avg_pnl > 0 else "C00000")
        ws.cell(row, 4, total_trades)
        ws.cell(row, 5, f"{avg_wr:.0f}%")
        ws.cell(row, 6, f"{avg_dd:+.1f}%")
        ws.cell(row, 7, sl_total)
        ws.cell(row, 8, div_total)
        ws.cell(row, 9, score_total)
        style_data(ws, row, len(agg_headers) + 1)
        mode_summary.append({
            'mode': mode, 'avg_pnl': avg_pnl, 'total_trades': total_trades,
            'avg_wr': avg_wr, 'avg_dd': avg_dd, 'sl_total': sl_total,
        })

    # Recommendation
    r = r + len(modes) + 3
    ws.cell(r, 2, "RECOMMENDATION").font = subtitle_font
    r += 1
    if mode_summary:
        # Best by avg P&L
        best_pnl = max(mode_summary, key=lambda x: x['avg_pnl'])
        # Best by risk-adjusted (P&L / |max DD|)
        best_ra = max(mode_summary, key=lambda x: x['avg_pnl'] / abs(x['avg_dd']) if x['avg_dd'] != 0 else x['avg_pnl'])
        rec_lines = [
            f"Best by Avg P&L:      {best_pnl['mode']} ({best_pnl['avg_pnl']:+.1f}%, WR {best_pnl['avg_wr']:.0f}%, DD {best_pnl['avg_dd']:+.1f}%)",
            f"Best Risk-Adjusted:   {best_ra['mode']} (P&L/|DD| = {best_ra['avg_pnl']/abs(best_ra['avg_dd']):.2f})",
            "",
            "NOTE: Risk-adjusted = avg P&L / |avg max drawdown|. Higher = better.",
            "Recommendation is heuristic; verify on out-of-sample data before deploying.",
        ]
        for i, line in enumerate(rec_lines):
            ws.cell(r + i, 2, line).font = Font(size=10)
            ws.merge_cells(start_row=r+i, start_column=2, end_row=r+i, end_column=10)

    for col in ['B','C','D','E','F','G','H','I','J','K']:
        ws.column_dimensions[col].width = 18
    ws.column_dimensions['B'].width = 22

    # ============ Per-stock per-mode sheets ============
    for sym in stocks:
        sym_safe = re.sub(r'[^A-Za-z0-9]', '_', sym)[:28]
        ws = wb.create_sheet(f"{sym_safe}")
        ws['B2'] = f"{sym} — Exit Mode Comparison"
        ws['B2'].font = title_font
        ws.merge_cells('B2:K2')
        ws['B3'] = f"{start_date} to {end_date} | {len(modes)} exit modes"
        ws['B3'].font = Font(size=10, color="666666")
        ws.merge_cells('B3:K3')

        r = 5
        ws.cell(r, 2, "PER-MODE SUMMARY").font = subtitle_font
        r += 1
        headers = ["Mode", "Cum P&L", "Trades", "Win Rate", "Avg P&L/Trade",
                   "Max DD", "SL/Trail Hits", "DI Cross Hits", "Div Exits", "Score<50"]
        for i, h in enumerate(headers):
            ws.cell(r, 2+i, h)
        style_header(ws, r, len(headers) + 1)

        for mi, mode in enumerate(modes):
            matching = [x for x in all_results if x['symbol'] == sym and x['exit_mode'] == mode]
            if not matching: continue
            x = matching[0]
            row = r + 1 + mi
            ws.cell(row, 2, mode).font = Font(bold=True)
            cell = ws.cell(row, 3, f"{x['cum_pnl']:+.1f}%")
            cell.font = Font(bold=True, color="006100" if x['cum_pnl'] > 0 else "C00000")
            ws.cell(row, 4, len(x['completed']))
            ws.cell(row, 5, f"{x['win_rate']:.0f}%")
            ws.cell(row, 6, f"{x['avg_pnl_per_trade']:+.2f}%")
            ws.cell(row, 7, f"{x['max_drawdown']:+.1f}%")
            ws.cell(row, 8, len(x.get('sl_exits', [])))
            ws.cell(row, 9, len(x.get('di_exits', [])))
            ws.cell(row, 10, len(x.get('div_exits', [])))
            ws.cell(row, 11, len(x.get('score_exits', [])))
            style_data(ws, row, len(headers) + 1)

        # Trade logs per mode (compact)
        r = r + len(modes) + 3
        ws.cell(r, 2, "TRADE LOGS BY MODE").font = subtitle_font
        r += 1
        for mi, mode in enumerate(modes):
            matching = [x for x in all_results if x['symbol'] == sym and x['exit_mode'] == mode]
            if not matching: continue
            x = matching[0]
            ws.cell(r, 2, f"--- {mode} ({len(x['trades'])} events) ---").font = Font(bold=True, color="4472C4")
            r += 1
            tl_headers = ["Type", "Date", "Close", "Score", "Entry Price", "Entry Date", "P&L %", "Exit Reason"]
            for i, h in enumerate(tl_headers):
                ws.cell(r, 2+i, h)
            style_header(ws, r, len(tl_headers) + 1)
            r += 1
            for evt in x['trades']:
                ws.cell(r, 2, evt['type'])
                ws.cell(r, 3, evt['date'].strftime('%Y-%m-%d') if hasattr(evt['date'], 'strftime') else str(evt['date']))
                ws.cell(r, 4, round(evt['close'], 2) if evt['close'] else '')
                ws.cell(r, 5, evt['score'])
                if 'entry_price' in evt:
                    ws.cell(r, 6, round(evt['entry_price'], 2))
                if 'entry_date' in evt:
                    ws.cell(r, 7, evt['entry_date'].strftime('%Y-%m-%d') if hasattr(evt['entry_date'], 'strftime') else str(evt['entry_date']))
                if 'pnl' in evt:
                    ws.cell(r, 8, evt['pnl'])
                if 'exit_reason' in evt:
                    ws.cell(r, 9, evt['exit_reason'])
                style_data(ws, r, len(tl_headers) + 1)
                # Color
                if evt['type'] == 'ENTRY':
                    for c in range(2, len(tl_headers) + 2):
                        ws.cell(r, c).fill = green_fill
                elif evt['type'] == 'EXIT':
                    reason = evt.get('exit_reason', '')
                    if 'SL_HIT' in reason or 'TRAILING_SL' in reason:
                        fill = sl_fill
                    elif 'DI_CROSSOVER' in reason:
                        fill = di_fill
                    elif 'DIVERGENCE' in reason:
                        fill = orange_fill
                    elif 'PERIOD_END' in reason:
                        fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")
                    else:
                        fill = red_fill
                    for c in range(2, len(tl_headers) + 2):
                        ws.cell(r, c).fill = fill
                r += 1
            r += 1  # blank line between modes

        for col in ['B','C','D','E','F','G','H','I','J','K']:
            ws.column_dimensions[col].width = 16
        ws.column_dimensions['I'].width = 50  # exit reason
        ws.column_dimensions['B'].width = 18

    wb.save(output_path)
    print(f"\nReport saved: {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=5)
    parser.add_argument('--seed', type=int, default=123)
    parser.add_argument('--start', type=str, default='2024-01-01')
    parser.add_argument('--end', type=str, default='2025-07-14')
    parser.add_argument('--tickers', type=str, default=None,
                        help='Comma-separated tickers (recommended for comparison)')
    parser.add_argument('--sl-percent', type=float, default=5.0)
    parser.add_argument('--exit-mode', type=str, default='FIXED_SL',
                        choices=EXIT_MODES)
    parser.add_argument('--compare-all', action='store_true',
                        help='Run all 4 exit modes on the same universe')
    parser.add_argument('--refresh', action='store_true',
                        help='Force re-fetch from yfinance (ignore disk cache)')
    args = parser.parse_args()

    print("=" * 70)
    print(f"Apollo Engine v5 — Exit Mode Comparison")
    print(f"Period: {args.start} → {args.end} | SL: {args.sl_percent}% | Seed: {args.seed}")
    print("=" * 70)

    # Pick stocks
    if args.tickers:
        picks = [{'sym': t.strip(), 'name': t.strip().replace('.NS',''), 'sector': 'N/A'}
                 for t in args.tickers.split(',')]
    else:
        picks = pick_random_stocks_filtered(args.n, args.seed, min_listing_date="2024-01-01")
    if not picks:
        print("[FAIL] No valid stocks."); return

    print(f"\nStocks ({len(picks)}):")
    for p in picks:
        print(f"  - {p['sym']} | {p['name']}")

    # Determine modes to run
    if args.compare_all:
        modes_to_run = EXIT_MODES
    else:
        modes_to_run = [args.exit_mode]

    print(f"\nExit modes to run: {modes_to_run}")

    # Run all combinations (data is cached — no network calls, no retries needed)
    all_results = []
    for mi, mode in enumerate(modes_to_run):
        print(f"\n{'='*70}")
        print(f"MODE {mi+1}/{len(modes_to_run)}: {mode}")
        print(f"{'='*70}")
        for si, p in enumerate(picks, 1):
            print(f"\n  [{si}/{len(picks)}] {p['sym']} — {mode}", flush=True)
            try:
                res = run_one_stock_mode(p['sym'], p['name'], p['sector'],
                                         args.start, args.end, mode, args.sl_percent,
                                         refresh=args.refresh)
                if res:
                    print(f"    P&L: {res['cum_pnl']:+.1f}% | Trades: {len(res['completed'])} | WR: {res['win_rate']:.0f}% | MaxDD: {res['max_drawdown']:+.1f}%")
                    all_results.append(res)
                else:
                    print(f"    [FAIL] no data")
            except Exception as e:
                print(f"    [ERROR] {e}", flush=True)
                import traceback; traceback.print_exc()

    if not all_results:
        print("\n[FAIL] No successful backtests."); return

    # Generate report
    today_str = datetime.now().strftime('%d%m%y')
    version = 1
    while True:
        if args.compare_all:
            out_name = f"Apollo_Engine_BT_{today_str}_v{version}_N{len(picks)}_COMPARE.xlsx"
        else:
            out_name = f"Apollo_Engine_BT_{today_str}_v{version}_N{len(picks)}_{args.exit_mode}.xlsx"
        out_path = _DOWNLOAD_DIR / out_name
        if not out_path.exists(): break
        version += 1

    print(f"\n{'='*70}")
    print(f"Generating comparison report: {out_name}")
    print(f"{'='*70}")
    generate_comparison_report(all_results, args.start, args.end, out_path,
                                sl_percent=args.sl_percent)

    # Summary
    print(f"\n{'='*70}")
    print(f"  v5 EXIT MODE COMPARISON COMPLETE")
    print(f"  Stocks: {len(picks)} | Modes: {len(modes_to_run)} | Total runs: {len(all_results)}")
    print()
    # Print per-mode aggregate
    by_mode = {}
    for r in all_results:
        by_mode.setdefault(r['exit_mode'], []).append(r)
    for mode, rs in by_mode.items():
        avg_pnl = np.mean([x['cum_pnl'] for x in rs])
        avg_dd = np.mean([x['max_drawdown'] for x in rs])
        avg_wr = np.mean([x['win_rate'] for x in rs])
        print(f"  {mode:<14} | Avg P&L: {avg_pnl:+7.1f}% | Avg WR: {avg_wr:.0f}% | Avg MaxDD: {avg_dd:+7.1f}%")
    print()
    print(f"  Report:  {out_path}")
    print(f"{'='*70}")

    return out_path


if __name__ == "__main__":
    main()
