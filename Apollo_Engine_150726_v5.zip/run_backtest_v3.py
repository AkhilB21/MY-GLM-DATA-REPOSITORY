"""
Multi-stock Apollo backtest runner (v3).

Changes from v2 (run_backtest.py):
  - Picks 5 random stocks from smallcap250.json (seeded for reproducibility)
  - Fetches yfinance data (daily, with 1y warmup before backtest start)
  - Auto-computes Apollo indicators via apollo_engine.indicators
  - Synthesizes 4H bars from daily (with provenance flag)
  - Produces a single CONSOLIDATED XLSX with summary + per-stock sheets
  - Adds Data Provenance row to Executive Summary (charter rule 7)

Usage:
  python run_backtest_v3.py
  python run_backtest_v3.py --tickers SYM1.NS,SYM2.NS
  python run_backtest_v3.py --start 2024-01-01 --end 2025-07-14
  python run_backtest_v3.py --n 10   # 10 random stocks instead of 5
"""
import sys
import os
import re
import math
import json
import random
import time
import argparse
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import yfinance as yf
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# Ensure local imports work
_SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPT_DIR))

from apollo_engine.data_loader import (
    load_daily_csv_auto, synthesize_4h_from_daily, resample_weekly,
    compute_all_indicators,  # re-exported via __init__ chain
)
from apollo_engine.indicators import compute_all_indicators

# Import the v2 engine functions for backtest logic (signal eval, trade extraction)
# We reuse these UNCHANGED so the strategy itself is identical to v6 reproduction.
ENTRY_THRESHOLD = 70
EXIT_THRESHOLD = 50
DIVERGENCE_RSI_DROP = 3.0
DIVERGENCE_COOLDOWN = 5

# Re-import everything from v2 by reading and exec'ing the module (without main())
import types
v2_module = types.ModuleType("v2_engine")
v2_module.__file__ = str(_SCRIPT_DIR / "run_backtest.py")  # shim for Path(__file__) inside v2
with open(_SCRIPT_DIR / "run_backtest.py", "r") as f:
    v2_code = f.read()
# Strip the `if __name__ == "__main__": main()` block to avoid auto-run
v2_code = re.sub(r'\nif __name__ == ["\']__main__["\']:\s*\n.*$', '\n', v2_code, flags=re.DOTALL)
exec(v2_code, v2_module.__dict__)

SIGNAL_DEFS = v2_module.SIGNAL_DEFS
POOL_MAX    = v2_module.POOL_MAX
POOL_ORDER  = v2_module.POOL_ORDER
POOL_NAMES  = v2_module.POOL_NAMES
POOL_DESC   = v2_module.POOL_DESC
eval_signals = v2_module.eval_signals
detect_troughs = v2_module.detect_troughs
get_latest_trough_pos = v2_module.get_latest_trough_pos
compute_weekly_rsi = v2_module.compute_weekly_rsi
extract_trades = v2_module.extract_trades
classify_score = v2_module.classify_score

_DOWNLOAD_DIR = Path("/home/z/my-project/download")
_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
_SMALLCAP_PATH = _SCRIPT_DIR.parent / "MY-GLM-DATA-REPOSITORY" / "smallcap250.json"
if not _SMALLCAP_PATH.exists():
    _SMALLCAP_PATH = Path("/home/z/my-project/repo/MY-GLM-DATA-REPOSITORY/smallcap250.json")


# ---------------------------------------------------------------------------
# Stock selection
# ---------------------------------------------------------------------------

def pick_random_stocks(n: int = 5, seed: int = 42) -> list[dict]:
    """Pick n random stocks from smallcap250.json (seeded)."""
    with open(_SMALLCAP_PATH) as f:
        universe = json.load(f)
    rng = random.Random(seed)
    picks = rng.sample(universe, n)
    return picks


# ---------------------------------------------------------------------------
# Data fetching
# ---------------------------------------------------------------------------

def fetch_yfinance_daily(ticker: str, start: str, end: str) -> pd.DataFrame:
    """Fetch daily OHLCV from yfinance, return DataFrame ready for engine.

    Returns DataFrame with DatetimeIndex + lowercase columns:
        open, high, low, close, volume
        + engine-friendly aliases: rsi21, rsi56, rsi36, tp28, wc21, wc50,
          plus_di, minus_di, adx, macd, macd_sig, macd_hist
    """
    df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
    if df is None or df.empty:
        return pd.DataFrame()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.reset_index().set_index('Date').sort_index()
    df.columns = [c.lower() for c in df.columns]
    df = df[['open', 'high', 'low', 'close', 'volume']].copy()

    # Compute Apollo indicators and add engine-friendly aliases directly
    computed = compute_all_indicators(df)
    df['rsi21']     = computed['RSI rsi (21,C)']
    df['rsi56']     = computed['RSI rsi (56)']
    df['rsi36']     = computed['RSI rsi (36)']
    df['tp28']      = computed['Result Typical Price (28,n)']
    df['wc50']      = computed['Result Weighted Close (50,y)']
    df['wc21']      = computed['Result Weighted Close (21)']
    df['plus_di']   = computed['+DI ADX (14,14,y,n)']
    df['minus_di']  = computed['-DI ADX (14,14,y,n)']
    df['adx']       = computed['ADX ADX (14,14,y,n)']
    df['macd']      = computed['MACD macd (12,26,9)']
    df['macd_sig']  = computed['Signal macd (12,26,9)']
    df['macd_hist'] = computed['macd (12,26,9)_hist']
    return df


# ---------------------------------------------------------------------------
# Run backtest for one stock
# ---------------------------------------------------------------------------

def run_one_stock(symbol: str, name: str, sector: str,
                  start_date: str, end_date: str) -> dict:
    """Run backtest for one stock. Returns dict with results + provenance."""
    print(f"\n[{symbol}] Fetching yfinance data...")
    # Add 1y warmup so indicators (RSI56, WC50) are fully populated by start_date
    warmup_start = (pd.Timestamp(start_date) - pd.DateOffset(years=1)).strftime('%Y-%m-%d')
    df_d_raw = fetch_yfinance_daily(symbol, warmup_start, end_date)
    if df_d_raw.empty:
        print(f"  [FAIL] No data fetched for {symbol}")
        return None

    print(f"  Daily bars: {len(df_d_raw)} | range: {df_d_raw.index[0].date()} → {df_d_raw.index[-1].date()}")

    # Synthesize 4H from daily (v3 feature)
    df_4h = synthesize_4h_from_daily(df_d_raw[['open', 'high', 'low', 'close', 'volume']])
    print(f"  4H bars (synthesized): {len(df_4h)}")

    # Weekly
    df_w = resample_weekly(df_d_raw[['open', 'high', 'low', 'close', 'volume']])
    print(f"  Weekly bars: {len(df_w)}")

    # df_d_raw already has lowercase + engine aliases from fetch_yfinance_daily
    df_d = df_d_raw

    # 4H already has lowercase + aliases from synthesize_4h_from_daily
    # (synthesizer calls compute_all_indicators which produces Apollo-named columns;
    # we need to add lowercase aliases too)
    df_4h['rsi21']     = df_4h['RSI rsi (21,C)']
    df_4h['rsi36']     = df_4h['RSI rsi (36)']
    df_4h['tp28']      = df_4h['Result Typical Price (28,n)']
    df_4h['wc50']      = df_4h['Result Weighted Close (50,y)']
    df_4h['wc21']      = df_4h['Result Weighted Close (21)']
    df_4h.columns = [c.lower() for c in df_4h.columns]

    # Run the backtest (uses v2 engine logic unchanged)
    print(f"  Running backtest {start_date} → {end_date}...")
    daily_df, trades = v2_module.run_backtest(df_d, df_4h, df_w, start_date, end_date)

    if daily_df.empty:
        print(f"  [FAIL] No backtest days in range")
        return None

    print(f"  Trading days: {len(daily_df)} | Avg score: {daily_df['total'].mean():.1f} | Peak: {daily_df['total'].max():.2f}")

    # Re-compute full daily_results (with signals) for Signal Analysis sheet
    # Reuse the pre-computation logic from v2 main()
    d_rsi21 = df_d['rsi21']; d_rsi36 = df_d['rsi36']
    h_rsi21 = df_4h['rsi21']; h_rsi36 = df_4h['rsi36']
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di = df_d['plus_di']; minus_di = df_d['minus_di']
    macd_line = df_d['macd']
    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    crossover_prices = []
    prev_above = False
    xover_price = None
    for i in range(len(df_4h)):
        c = df_4h['close'].iloc[i]
        w = df_4h['wc21'].iloc[i] if 'wc21' in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask2 = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    daily_indices2 = np.where(np.asarray(mask2))[0]
    daily_results_full = []
    for pos in daily_indices2:
        bt_date = df_d.index[pos]
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])
        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line, b6_xover
        )
        pool_pts = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id)
        core = min(100, pool_pts['A'] + pool_pts['B'] + pool_pts['C'])
        bonus = pool_pts['BA'] + pool_pts['BB'] + pool_pts['BC']
        total = core + bonus
        action, pos_pct = classify_score(total)
        daily_results_full.append({
            'date': bt_date, 'close': df_d['close'].iloc[pos],
            'pool_a': pool_pts['A'], 'pool_b': pool_pts['B'], 'pool_c': pool_pts['C'],
            'bonus_a': pool_pts['BA'], 'bonus_b': pool_pts['BB'], 'bonus_c': pool_pts['BC'],
            'core': core, 'bonus': bonus, 'total': total,
            'action': action, 'pos_pct': pos_pct,
            'signals': sigs,
            'bars_from_trough': pos - d_trough_pos if d_trough_pos is not None else None,
            'rsi21': d_rsi21.iloc[pos],
        })

    # Provenance
    provenance = {
        'daily_source': 'yfinance (auto-adjusted)',
        '4h_source': 'synthesized from daily (v3)',
        'indicators': 'computed in Python (Wilder RSI, SMA TP/WC, Wilder ADX, EMA MACD)',
        'warmup_start': warmup_start,
    }

    entries = [e for e in trades if e['type'] == 'ENTRY']
    exits = [e for e in trades if e['type'] == 'EXIT']
    completed = [e for e in exits if 'pnl' in e and e.get('exit_reason') != '']
    cum_pnl = sum(e['pnl'] for e in completed) if completed else 0
    winning = [e for e in completed if e['pnl'] > 0]
    win_rate = round(len(winning) / len(completed) * 100, 0) if completed else 0

    return {
        'symbol': symbol, 'name': name, 'sector': sector,
        'daily_df': daily_df, 'trades': trades,
        'daily_results_full': daily_results_full,
        'df_d': df_d, 'df_4h': df_4h, 'df_w': df_w,
        'provenance': provenance,
        'entries': entries, 'completed': completed,
        'cum_pnl': cum_pnl, 'win_rate': win_rate,
        'avg_score': round(daily_df['total'].mean(), 1),
        'peak_score': round(daily_df['total'].max(), 2),
        'n_days': len(daily_df),
    }


# ---------------------------------------------------------------------------
# Consolidated report
# ---------------------------------------------------------------------------

def generate_consolidated_report(results: list[dict], start_date: str, end_date: str,
                                  output_path: Path):
    """Generate consolidated multi-stock XLSX."""
    wb = Workbook()

    # Styles
    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    title_font = Font(bold=True, size=16, color="1F4E79")
    subtitle_font = Font(bold=True, size=11, color="4472C4")
    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    orange_fill = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
    amber_font = Font(color="BF8F00", italic=True)
    red_font = Font(color="C00000", italic=True)
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )

    def style_header(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', wrap_text=True)
            cell.border = thin_border

    def style_data(ws, row, cols):
        for c in range(1, cols + 1):
            cell = ws.cell(row=row, column=c)
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center')

    # ===================== SHEET 1: Summary =====================
    ws1 = wb.active
    ws1.title = "Summary"

    ws1['B2'] = "Apollo Engine v3 - Consolidated Backtest Report"
    ws1['B2'].font = title_font
    ws1.merge_cells('B2:L2')

    ws1['B3'] = (f"5 Smallcap250 stocks (random seed=42) | "
                 f"{start_date} to {end_date} | "
                 f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    ws1['B3'].font = Font(size=10, color="666666")
    ws1.merge_cells('B3:L3')

    ws1['B5'] = "DATA PROVENANCE (Charter Rule 7)"
    ws1['B5'].font = subtitle_font
    provenance_lines = [
        "Daily OHLCV: yfinance (auto-adjusted splits/dividends)",
        "4H bars: SYNTHESIZED from daily using v3 deterministic model (2 bars/NSE day, 09:15 & 13:15)",
        "Indicators: computed in Python — Wilder RSI(21/36/56), SMA TP(28), SMA WC(21/50), Wilder ADX(14,14), EMA MACD(12,26,9)",
        "Warmup: 1 year before backtest start to ensure indicator stability",
        "WARNING: Synthetic 4H bars are APPROXIMATE. For production, swap in real Kite Connect 4H data (see ZERODHA_KITE_SETUP.md).",
    ]
    for i, line in enumerate(provenance_lines):
        ws1.cell(6 + i, 2, line).font = Font(size=10, color="333333")
        ws1.merge_cells(start_row=6+i, start_column=2, end_row=6+i, end_column=12)

    # Stock ranking table
    r = 12
    ws1.cell(r, 2, "STOCK RANKING (by Cumulative P&L)").font = subtitle_font
    r += 1
    headers = ["Rank", "Symbol", "Name", "Sector", "Days", "Entries",
               "Completed", "Win Rate", "Cum P&L %", "Avg Score", "Peak Score"]
    for i, h in enumerate(headers):
        ws1.cell(r, 2+i, h)
    style_header(ws1, r, len(headers) + 1)

    sorted_results = sorted(results, key=lambda x: x['cum_pnl'], reverse=True)
    for rank, res in enumerate(sorted_results, 1):
        row = r + rank
        ws1.cell(row, 2, rank)
        ws1.cell(row, 3, res['symbol'])
        ws1.cell(row, 4, res['name'])
        ws1.cell(row, 5, res['sector'])
        ws1.cell(row, 6, res['n_days'])
        ws1.cell(row, 7, len(res['entries']))
        ws1.cell(row, 8, len(res['completed']))
        ws1.cell(row, 9, f"{res['win_rate']:.0f}%")
        pnl_cell = ws1.cell(row, 10, f"{res['cum_pnl']:+.1f}%")
        if res['cum_pnl'] > 0:
            pnl_cell.font = Font(bold=True, color="006100")
        else:
            pnl_cell.font = Font(bold=True, color="C00000")
        ws1.cell(row, 11, res['avg_score'])
        ws1.cell(row, 12, res['peak_score'])
        style_data(ws1, row, len(headers) + 1)

    # Aggregate stats
    r = r + len(sorted_results) + 3
    ws1.cell(r, 2, "PORTFOLIO AGGREGATE").font = subtitle_font
    r += 1
    agg_headers = ["Metric", "Value"]
    for i, h in enumerate(agg_headers):
        ws1.cell(r, 2+i, h)
    style_header(ws1, r, len(agg_headers) + 1)
    agg_data = [
        ("Stocks backtested", len(results)),
        ("Total entries", sum(len(x['entries']) for x in results)),
        ("Total completed trades", sum(len(x['completed']) for x in results)),
        ("Avg cumulative P&L", f"{np.mean([x['cum_pnl'] for x in results]):+.1f}%"),
        ("Best P&L", f"{max(x['cum_pnl'] for x in results):+.1f}% ({max(results, key=lambda x: x['cum_pnl'])['symbol']})"),
        ("Worst P&L", f"{min(x['cum_pnl'] for x in results):+.1f}% ({min(results, key=lambda x: x['cum_pnl'])['symbol']})"),
        ("Avg win rate", f"{np.mean([x['win_rate'] for x in results]):.0f}%"),
        ("Avg daily score", f"{np.mean([x['avg_score'] for x in results]):.1f}"),
    ]
    for i, (m, v) in enumerate(agg_data):
        rr = r + 1 + i
        ws1.cell(rr, 2, m).font = Font(bold=True, size=10)
        ws1.cell(rr, 3, v)
        style_data(ws1, rr, 3)

    # Column widths
    for col_letter in ['B','C','D','E','F','G','H','I','J','K','L']:
        ws1.column_dimensions[col_letter].width = 18
    ws1.column_dimensions['D'].width = 30

    # ===================== Per-stock sheets =====================
    for idx, res in enumerate(sorted_results):
        sym_safe = re.sub(r'[^A-Za-z0-9]', '_', res['symbol'])[:28]
        ws = wb.create_sheet(f"{sym_safe}")

        ws['B2'] = f"{res['symbol']} - {res['name']}"
        ws['B2'].font = title_font
        ws.merge_cells('B2:N2')
        ws['B3'] = (f"Sector: {res['sector']} | {start_date} to {end_date} | "
                    f"{res['n_days']} trading days")
        ws['B3'].font = Font(size=10, color="666666")
        ws.merge_cells('B3:N3')

        # KPIs
        r = 5
        ws.cell(r, 2, "KEY METRICS").font = subtitle_font
        r += 1
        kpi_headers = ["Days", "Entries", "Completed", "Win Rate", "Cum P&L",
                       "Avg Score", "Peak Score", "Start Price", "End Price", "Price Change"]
        daily_df = res['daily_df']
        start_price = daily_df['close'].iloc[0]
        end_price = daily_df['close'].iloc[-1]
        price_change = round((end_price - start_price) / start_price * 100, 1) if start_price else 0
        kpi_values = [res['n_days'], len(res['entries']), len(res['completed']),
                      f"{res['win_rate']:.0f}%", f"{res['cum_pnl']:+.1f}%",
                      res['avg_score'], res['peak_score'],
                      round(start_price, 2), round(end_price, 2), f"{price_change:+.1f}%"]
        for i, (lbl, val) in enumerate(zip(kpi_headers, kpi_values)):
            ws.cell(r, 2+i, lbl).font = Font(bold=True, size=9, color="666666")
            cell = ws.cell(r+1, 2+i, val)
            cell.font = Font(size=11)
            cell.alignment = Alignment(horizontal='center')

        # Trade log
        r = 9
        ws.cell(r, 2, "TRADE LOG").font = subtitle_font
        r += 1
        tl_headers = ["#", "Type", "Date", "Close", "Score", "Classification",
                      "Entry Price", "Entry Date", "P&L %", "Exit Reason"]
        for i, h in enumerate(tl_headers):
            ws.cell(r, 2+i, h)
        style_header(ws, r, len(tl_headers) + 1)

        for ti, evt in enumerate(res['trades']):
            rr = r + 1 + ti
            ws.cell(rr, 2, ti + 1)
            ws.cell(rr, 3, evt['type'])
            ws.cell(rr, 4, evt['date'].strftime('%Y-%m-%d') if hasattr(evt['date'], 'strftime') else str(evt['date']))
            ws.cell(rr, 5, round(evt['close'], 2) if evt['close'] else '')
            ws.cell(rr, 6, evt['score'])
            ws.cell(rr, 7, evt['classification'])
            if 'entry_price' in evt:
                ws.cell(rr, 8, round(evt['entry_price'], 2))
            if 'entry_date' in evt:
                ws.cell(rr, 9, evt['entry_date'].strftime('%Y-%m-%d') if hasattr(evt['entry_date'], 'strftime') else str(evt['entry_date']))
            if 'pnl' in evt:
                ws.cell(rr, 10, evt['pnl'])
            if 'exit_reason' in evt:
                ws.cell(rr, 11, evt['exit_reason'])
            style_data(ws, rr, len(tl_headers) + 1)

            # Row coloring
            if evt['type'] == 'ENTRY':
                for c in range(2, len(tl_headers) + 2):
                    ws.cell(rr, c).fill = green_fill
                    ws.cell(rr, c).font = Font(bold=True)
            elif evt['type'] == 'EXIT':
                reason = evt.get('exit_reason', '')
                if 'DIVERGENCE' in reason:
                    fill = orange_fill
                else:
                    fill = red_fill
                for c in range(2, len(tl_headers) + 2):
                    ws.cell(rr, c).fill = fill

        # Signal Analysis
        r = r + len(res['trades']) + 3
        ws.cell(r, 2, "SIGNAL ANALYSIS").font = subtitle_font
        r += 1
        sa_headers = ["Signal", "Pool", "Max Pts", "Hit Rate %", "Hits", "Total Pts", "Contribution %"]
        for i, h in enumerate(sa_headers):
            ws.cell(r, 2+i, h)
        style_header(ws, r, len(sa_headers) + 1)

        total_days = res['n_days']
        total_pts_all = 0
        sig_stats = []
        for sid, sname, pool, maxp in SIGNAL_DEFS:
            hits = 0; total_pts = 0
            for dr in res['daily_results_full']:
                pts, fired = dr['signals'][sid]
                if fired: hits += 1
                total_pts += pts
            hit_rate = round(hits / total_days * 100, 1) if total_days else 0
            sig_stats.append((sid, sname, pool, maxp, hit_rate, hits, round(total_pts, 2)))
            total_pts_all += total_pts

        for i, (sid, sname, pool, maxp, hr, h, tp) in enumerate(sig_stats):
            rr = r + 1 + i
            ws.cell(rr, 2, f"{sid} - {sname}")
            ws.cell(rr, 3, pool)
            ws.cell(rr, 4, maxp)
            ws.cell(rr, 5, f"{hr}%")
            ws.cell(rr, 6, h)
            ws.cell(rr, 7, tp)
            contrib = round(tp / total_pts_all * 100, 1) if total_pts_all else 0
            ws.cell(rr, 8, f"{contrib}%")
            style_data(ws, rr, len(sa_headers) + 1)
            if hr == 0:
                for c in range(2, len(sa_headers) + 2):
                    ws.cell(rr, c).font = red_font
            elif hr >= 95:
                for c in range(2, len(sa_headers) + 2):
                    ws.cell(rr, c).font = amber_font

        # Critical findings
        r = r + 1 + len(sig_stats) + 2
        ws.cell(r, 2, "CRITICAL FINDINGS").font = subtitle_font
        r += 1
        always_on = [f"{sid} ({hr}%)" for sid, _, _, _, hr, _, _ in sig_stats if hr >= 95]
        dead = [f"{sid} (0%)" for sid, _, _, _, hr, _, _ in sig_stats if hr == 0]
        if always_on:
            ws.cell(r, 2, f"Always-on (≥95%): {', '.join(always_on)}").font = amber_font
            r += 1
        if dead:
            ws.cell(r, 2, f"Dead (0%): {', '.join(dead)}").font = red_font
            r += 1
        # Top differentiators: hit rate <50%, sorted by total_pts desc
        diffs = [s for s in sig_stats if s[4] < 50 and s[4] > 0]
        diffs.sort(key=lambda x: x[6], reverse=True)
        if diffs:
            top_diffs = ', '.join(f"{s[0]} ({s[4]}%, {s[6]} pts)" for s in diffs[:5])
            ws.cell(r, 2, f"Top differentiators: {top_diffs}").font = Font(italic=True, color="333333")

        # Column widths
        for col_letter in ['B','C','D','E','F','G','H','I','J','K','L','M','N']:
            ws.column_dimensions[col_letter].width = 16
        ws.column_dimensions['K'].width = 45  # exit reason
        ws.column_dimensions['B'].width = 22  # signal name

    # Save
    wb.save(output_path)
    print(f"\nReport saved: {output_path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=5, help='Number of random stocks')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--start', type=str, default='2024-01-01')
    parser.add_argument('--end', type=str, default='2025-07-14')
    parser.add_argument('--tickers', type=str, default=None,
                        help='Comma-separated tickers (overrides random pick)')
    args = parser.parse_args()

    print("=" * 70)
    print(f"Apollo Engine v3 — Multi-Stock Backtest")
    print(f"Period: {args.start} → {args.end}  |  Stocks: {args.n}  |  Seed: {args.seed}")
    print("=" * 70)

    # Pick stocks
    if args.tickers:
        picks = [{'sym': t.strip(), 'name': t.strip().replace('.NS',''), 'sector': 'N/A'}
                 for t in args.tickers.split(',')]
    else:
        picks = pick_random_stocks(args.n, args.seed)
    print(f"\nPicked {len(picks)} stocks:")
    for p in picks:
        print(f"  - {p['sym']} | {p['name']} | {p['sector']}")

    # Run backtest for each, with ONE fast retry on rate-limit failures
    results = []
    failed_tickers = []
    for i, p in enumerate(picks, 1):
        print(f"\n[{i}/{len(picks)}] === {p['sym']} ===", flush=True)
        success = False
        for attempt in range(2):  # max 2 attempts
            try:
                res = run_one_stock(p['sym'], p['name'], p['sector'], args.start, args.end)
                if res:
                    results.append(res)
                    success = True
                    break
                else:
                    # No data — likely rate-limited
                    wait = 5 * (attempt + 1)
                    print(f"  [retry {attempt+1}/2] No data, waiting {wait}s...", flush=True)
                    time.sleep(wait)
            except Exception as e:
                print(f"  [ERROR] {e}", flush=True)
                import traceback; traceback.print_exc()
                time.sleep(5)
        if not success:
            failed_tickers.append(p['sym'])
        time.sleep(1.5)

    if failed_tickers:
        print(f"\n[WARN] Failed tickers (rate-limited): {failed_tickers}")
        print(f"       Replacing with next random picks to fill {args.n - len(results)} slots...")

        # Pick replacements from a different seed offset
        with open(_SMALLCAP_PATH) as f:
            universe = json.load(f)
        used_syms = {p['sym'] for p in picks}
        rng = random.Random(args.seed + 99)
        replacements = [s for s in universe if s['sym'] not in used_syms]
        rng.shuffle(replacements)

        for p in replacements[:len(failed_tickers) * 2]:
            if len(results) >= args.n:
                break
            print(f"\n[replacement] === {p['sym']} ===")
            try:
                res = run_one_stock(p['sym'], p['name'], p['sector'], args.start, args.end)
                if res:
                    results.append(res)
            except Exception as e:
                print(f"  [ERROR] {e}")
            time.sleep(2.5)

    if not results:
        print("\n[FAIL] No successful backtests. Aborting.")
        return

    # Generate consolidated report
    today_str = datetime.now().strftime('%d%m%y')
    version = 1
    while True:
        out_name = f"Apollo_Engine_BT_{today_str}_v{version}_N{len(results)}.xlsx"
        out_path = _DOWNLOAD_DIR / out_name
        if not out_path.exists():
            break
        version += 1

    print(f"\n{'='*70}")
    print(f"Generating consolidated report: {out_name}")
    print(f"{'='*70}")
    generate_consolidated_report(results, args.start, args.end, out_path)

    # Summary
    print(f"\n{'='*70}")
    print(f"  BACKTEST COMPLETE")
    print(f"  Stocks: {len(results)}")
    print(f"  Avg P&L: {np.mean([r['cum_pnl'] for r in results]):+.1f}%")
    print(f"  Best:    {max(r['cum_pnl'] for r in results):+.1f}%")
    print(f"  Worst:   {min(r['cum_pnl'] for r in results):+.1f}%")
    print(f"  Report:  {out_path}")
    print(f"{'='*70}")

    return out_path


if __name__ == "__main__":
    main()
