"""
Apollo Analysis Engine
======================
Data-validated multi-timeframe RSI scoring engine for recovery detection.
Implements the full 19-signal scoring matrix across 5 pools (A, B, C, BA, BB)
as specified in the APOLLO Architecture document (July 2026).

Entry Score = min(100, Pool A + Pool B + Pool C) + Bonus A + Bonus B
Core Cap: 85 | Bonus Max: 18 | Absolute Max: 103

Usage:
    from apollo_engine import ApolloAnalysisEngine

    engine = ApolloAnalysisEngine()
    result = engine.score(df_4h, df_daily, df_weekly, lookback_date="2026-04-08")
    print(result)
"""

from apollo_engine.engine import ApolloAnalysisEngine
from apollo_engine.indicators import (
    compute_rsi, compute_tp28, compute_wc50, compute_wc21,
    compute_adx, compute_macd, compute_all_indicators,
)
from apollo_engine.data_loader import (
    load_daily_csv_auto, load_4h_csv_auto,
    synthesize_4h_from_daily, aggregate_intraday_to_4h, resample_weekly,
)

__all__ = [
    "ApolloAnalysisEngine",
    "compute_rsi", "compute_tp28", "compute_wc50", "compute_wc21",
    "compute_adx", "compute_macd", "compute_all_indicators",
    "load_daily_csv_auto", "load_4h_csv_auto",
    "synthesize_4h_from_daily", "aggregate_intraday_to_4h", "resample_weekly",
]
__version__ = "3.0.0"