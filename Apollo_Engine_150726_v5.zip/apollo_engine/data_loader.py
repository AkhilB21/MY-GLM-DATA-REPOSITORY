"""
Data loading and preparation utilities for the Apollo Analysis Engine.

Provides helpers to:
  - Load CSV data into properly formatted DataFrames
  - Resample Daily data into 4H or Weekly timeframes
  - Validate required columns and data quality
  - Auto-compute Apollo indicator columns when missing (added in v3)
  - Aggregate real intraday (1h/15m) data into 4H bars (added in v3)
"""

import re
import pandas as pd
import numpy as np

from apollo_engine.indicators import compute_all_indicators, get_indicator_provenance


REQUIRED_COLUMNS = {"open", "high", "low", "close", "volume"}
OPTIONAL_COLUMNS = {"date", "datetime", "timestamp"}

# Apollo schema column names (ChartAlert / Spider ChartLink export format)
APOLLO_DATE_COL = "Date"
APOLLO_OHLCV_COLS = ["Open", "High", "Low", "Close", "Volume"]
APOLLO_INDICATOR_COLS = [
    "Result Weighted Close (50,y)",
    "RSI rsi (21,C)", "RSI rsi (56)", "RSI rsi (36)",
    "Result Typical Price (28,n)",
    "Result Weighted Close (21)",
    "+DI ADX (14,14,y,n)", "-DI ADX (14,14,y,n)", "ADX ADX (14,14,y,n)",
    "MACD macd (12,26,9)", "Signal macd (12,26,9)", "macd (12,26,9)_hist",
]


def load_csv(
    path: str,
    date_col: str = "date",
    date_format: str = None,
) -> pd.DataFrame:
    """
    Load OHLCV CSV data and return a DataFrame with DatetimeIndex.

    Parameters
    ----------
    path : str
        Path to the CSV file.
    date_col : str
        Column name containing the date/datetime.
    date_format : str, optional
        strptime format string for parsing dates.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and columns: open, high, low, close, volume.
    """
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]

    if date_col not in df.columns:
        raise ValueError(f"Date column '{date_col}' not found. "
                         f"Available: {list(df.columns)}")

    df[date_col] = pd.to_datetime(df[date_col], format=date_format)
    df.set_index(date_col, inplace=True)
    df.sort_index(inplace=True)

    _validate_ohlcv(df)
    return df


def _validate_ohlcv(df: pd.DataFrame):
    """Ensure DataFrame has all required OHLCV columns."""
    cols = set(df.columns.str.lower())
    missing = REQUIRED_COLUMNS - cols
    if missing:
        raise ValueError(
            f"Missing required columns: {missing}. "
            f"Required: {REQUIRED_COLUMNS}"
        )
    # Ensure numeric
    for col in REQUIRED_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df.dropna(subset=["close"], inplace=True)


def resample_to_4h(df_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Resample daily OHLCV data to 4-hour bars using synthetic intraday
    distribution. This is a simplified approximation — for production use,
    actual 4H data from a data provider is strongly recommended.

    The synthetic approach distributes daily range across 6 bars:
      - Bar 0 (open): O, H1, L1, C1
      - Bar 1-4: interpolated OHLC
      - Bar 5 (close): C5, daily High, daily Low, daily Close

    Parameters
    ----------
    df_daily : pd.DataFrame
        Daily OHLCV data with DatetimeIndex.

    Returns
    -------
    pd.DataFrame with 4H bars.
    """
    rows = []
    for date, row in df_daily.iterrows():
        o, h, l, c, v = (
            row["open"], row["high"], row["low"], row["close"], row["volume"]
        )
        # Generate 6 synthetic 4H bars
        np.random.seed(hash(str(date)) % (2**31))
        for i in range(6):
            vol_weights = [0.20, 0.12, 0.12, 0.14, 0.14, 0.28]
            bar_vol = v * vol_weights[i]

            if i == 0:
                bar_o, bar_h, bar_l, bar_c = o, o, o, o
            elif i == 5:
                bar_o, bar_h, bar_l, bar_c = c, h, l, c
            else:
                # Interpolate within the daily range
                frac = i / 5.0
                bar_o = o + (c - o) * (frac - 0.08)
                bar_c = o + (c - o) * (frac + 0.08)
                bar_h = max(bar_o, bar_c) + (h - max(o, c)) * 0.3
                bar_l = min(bar_o, bar_c) - (min(o, c) - l) * 0.3
                # Add small random noise
                noise = (h - l) * 0.05 * (np.random.random() - 0.5)
                bar_c += noise
                bar_h = max(bar_h, bar_o, bar_c)
                bar_l = min(bar_l, bar_o, bar_c)

            rows.append({
                "open": bar_o, "high": bar_h, "low": bar_l,
                "close": bar_c, "volume": bar_vol,
            })

    df_4h = pd.DataFrame(rows)
    df_4h.index = pd.DatetimeIndex(
        [r[0] + pd.Timedelta(hours=i * 4)
         for r in df_daily.iterrows() for i in range(6)]
    )
    return df_4h


def resample_to_weekly(df_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Resample daily OHLCV data to weekly bars.

    Week starts on Monday. Uses the first session's open, last session's
    close, and the extreme high/low across the week.

    Parameters
    ----------
    df_daily : pd.DataFrame
        Daily OHLCV data with DatetimeIndex.

    Returns
    -------
    pd.DataFrame with weekly bars, indexed by week-start date.
    """
    df = df_daily.copy()
    df["week"] = df.index.to_period("W").start_time

    weekly = df.groupby("week").agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
    )
    weekly.index.name = None
    return weekly


def generate_synthetic_recovery_data(
    n_days: int = 300,
    trough_day: int = 200,
    base_price: float = 200.0,
    decline_pct: float = 0.15,
    recovery_pct: float = 0.20,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Generate synthetic daily OHLCV data that simulates a decline and
    recovery pattern, suitable for testing the Apollo engine.

    Parameters
    ----------
    n_days : int
        Total number of daily bars to generate.
    trough_day : int
        Day index where the price trough occurs.
    base_price : float
        Starting price.
    decline_pct : float
        Maximum decline from base to trough.
    recovery_pct : float
        Recovery from trough price.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and OHLCV columns.
    """
    np.random.seed(seed)
    dates = pd.bdate_range("2025-06-01", periods=n_days)

    # Build a price path: rise → decline → trough → recovery
    prices = np.zeros(n_days)
    prices[0] = base_price

    trough_price = base_price * (1 - decline_pct)
    peak_before_decline = base_price * 1.10
    recovery_end_price = trough_price * (1 + recovery_pct)

    for i in range(1, n_days):
        if i < trough_day * 0.4:
            # Phase 1: Gradual rise
            target = peak_before_decline
            drift = (target - prices[i - 1]) * 0.02
        elif i < trough_day:
            # Phase 2: Decline to trough
            progress = (i - trough_day * 0.4) / (trough_day * 0.6)
            target = peak_before_decline + (trough_price - peak_before_decline) * progress
            drift = (target - prices[i - 1]) * 0.08
        elif i < trough_day + 30:
            # Phase 3: Sharp recovery
            progress = (i - trough_day) / 30.0
            target = trough_price + (recovery_end_price - trough_price) * progress
            drift = (target - prices[i - 1]) * 0.15
        else:
            # Phase 4: Consolidation / gentle rise
            drift = prices[i - 1] * 0.001

        volatility = prices[i - 1] * 0.015
        change = drift + np.random.normal(0, volatility)
        prices[i] = max(prices[i - 1] * 0.95, prices[i - 1] + change)

    # Generate OHLCV from close prices
    data = []
    for i, (date, close) in enumerate(zip(dates, prices)):
        intraday_range = close * 0.02
        o = close + np.random.normal(0, intraday_range * 0.3)
        h = max(o, close) + abs(np.random.normal(0, intraday_range * 0.5))
        l = min(o, close) - abs(np.random.normal(0, intraday_range * 0.5))
        # Volume: higher during decline and recovery
        base_vol = 5_000_000
        if i < trough_day:
            vol_mult = 1.0 + 0.5 * (i / trough_day)
        else:
            vol_mult = 1.5 - 0.8 * ((i - trough_day) / 50.0)
        vol = base_vol * max(0.5, vol_mult) * (0.8 + 0.4 * np.random.random())

        data.append({
            "open": round(o, 2), "high": round(h, 2),
            "low": round(l, 2), "close": round(close, 2),
            "volume": int(vol),
        })

    df = pd.DataFrame(data, index=dates)
    return df


# ===========================================================================
# v3 additions
# ===========================================================================

def parse_apollo_date(date_str):
    """Parse Apollo's non-standard date format used by ChartAlert exports.

    Examples:
      "Thu Aug 11 2022 00:00:00 GMT+0530 (India Standard Time)"
      "Wed Feb 08 2023 09:15:00 GMT+0530 (India Standard Time)"
    """
    date_str = str(date_str).strip()
    m = re.match(r'(\w{3})\s+(\w{3})\s+(\d{1,2})\s+(\d{4})', date_str)
    if m:
        return pd.Timestamp(f"{m.group(1)} {m.group(2)} {m.group(3)} {m.group(4)}")
    return pd.to_datetime(date_str, dayfirst=False, yearfirst=False)


def normalize_apollo_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize a ChartAlert-style DataFrame into Apollo engine's expected form.

    - Strips zero-width chars and 'Result ' prefixes from column names
    - Parses the Apollo date format
    - Lowercases column names for engine use
    - Pre-extracts indicator columns under short aliases (rsi21, tp28, etc.)
    """
    df = df.copy()
    df.columns = [c.strip().replace('\u200c', '').replace('Result ', '')
                  for c in df.columns]

    if APOLLO_DATE_COL in df.columns:
        df['date_parsed'] = df[APOLLO_DATE_COL].apply(parse_apollo_date)
        df = df.set_index('date_parsed').sort_index()

    for col in APOLLO_OHLCV_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # Map Apollo column names → engine-friendly aliases
    alias_map = {
        'RSI rsi (21,C)': 'rsi21',
        'RSI rsi (36)':   'rsi36',
        'RSI rsi (56)':   'rsi56',
        'Typical Price (28,n)': 'tp28',
        'Weighted Close (50,y)': 'wc50',
        'Weighted Close (21)':   'wc21',
        '+DI ADX (14,14,y,n)':   'plus_di',
        '-DI ADX (14,14,y,n)':   'minus_di',
        'ADX ADX (14,14,y,n)':   'adx',
        'MACD macd (12,26,9)':   'macd',
        'Signal macd (12,26,9)': 'macd_sig',
        'macd (12,26,9)_hist':   'macd_hist',
    }
    for orig, alias in alias_map.items():
        if orig in df.columns:
            df[alias] = pd.to_numeric(df[orig], errors='coerce')

    df.columns = [c.lower() for c in df.columns]
    return df


def load_daily_csv_auto(path: str) -> tuple[pd.DataFrame, dict]:
    """Load a daily CSV and auto-compute missing indicators.

    Backward compatible: if the CSV already has Apollo-format indicator
    columns, they are used as-is. Missing columns are computed from OHLCV.

    Returns
    -------
    (df, provenance) where `df` has DatetimeIndex + lowercase columns:
        open, high, low, close, volume, rsi21, rsi36, rsi56, tp28, wc21,
        wc50, plus_di, minus_di, adx, macd, macd_sig, macd_hist
    and `provenance` is a dict {indicator_name: 'pre_supplied'|'computed'}.
    """
    raw = pd.read_csv(path)
    df = normalize_apollo_csv(raw)
    provenance = get_indicator_provenance(raw)

    # If any indicator column is missing, compute ALL indicators from OHLCV.
    # (Mixing pre-supplied and computed would risk formula inconsistency.)
    needed_aliases = ['rsi21', 'rsi36', 'rsi56', 'tp28', 'wc21', 'wc50',
                      'plus_di', 'minus_di', 'adx', 'macd', 'macd_sig', 'macd_hist']
    if any(alias not in df.columns or df[alias].isna().all() for alias in needed_aliases):
        # Compute fresh
        ohlcv = df[['open', 'high', 'low', 'close', 'volume']].copy()
        computed = compute_all_indicators(ohlcv)
        # Re-normalize computed columns to engine aliases
        df['rsi21']     = computed['RSI rsi (21,C)']
        df['rsi56']     = computed['RSI rsi (56)']
        df['rsi36']     = computed['RSI rsi (36)']
        df['tp28']      = computed['Result Typical Price (28,n)']
        df['wc50']      = computed['Result Weighted Close (50,y)']
        df['wc21']      = computed['Result Weighted Close (21)']
        df['plus_di']   = computed['+DI ADX (14,14,y,n)']
        df['minus_di']  = computed['-DI ADX (14,14,y,n)']
        df['adx']       = computed['ADX ADX (14,14,y,n)']
        df['macd']      = computed['MACD macd (12,26,9)']
        df['macd_sig']  = computed['Signal macd (12,26,9)']
        df['macd_hist'] = computed['macd (12,26,9)_hist']
        # Update provenance: everything becomes 'computed'
        provenance = {col: 'computed' for col in provenance}

    return df, provenance


def load_4h_csv_auto(path: str) -> tuple[pd.DataFrame, dict]:
    """Load a 4H CSV with auto-compute (same logic as load_daily_csv_auto)."""
    return load_daily_csv_auto(path)


def aggregate_intraday_to_4h(df_intraday: pd.DataFrame) -> pd.DataFrame:
    """Aggregate a 1h/15m/5m DataFrame into 4H bars aligned to NSE sessions.

    NSE session: 09:15 - 15:30 IST. 4H buckets anchor at 09:15, 13:15.
    (Two 4H bars per NSE session; the last partial 2h45m bar is dropped.)

    Parameters
    ----------
    df_intraday : pd.DataFrame
        DatetimeIndex ( tz-aware or naive, assumed IST ), OHLCV columns.
    """
    df = df_intraday.copy()
    # Ensure tz-naive for resampling simplicity
    if df.index.tz is not None:
        df.index = df.index.tz_convert('Asia/Kolkata').tz_localize(None)

    # Filter to NSE session hours
    df = df.between_time('09:15', '15:30')

    # Anchor 4H buckets at 09:15 and 13:15
    def _bucket(ts):
        h, m = ts.hour, ts.minute
        mins = (h - 9) * 60 + (m - 15)
        if mins < 0:
            return None
        if mins < 240:
            return ts.normalize() + pd.Timedelta(hours=9, minutes=15)
        if mins < 405:  # 15:30 = 6h45m from 09:15
            return ts.normalize() + pd.Timedelta(hours=13, minutes=15)
        return None

    df['bucket'] = df.index.map(_bucket)
    df = df.dropna(subset=['bucket'])
    if df.empty:
        return df.drop(columns=['bucket'])

    agg = df.groupby('bucket').agg(
        open=('open', 'first'),
        high=('high', 'max'),
        low=('low', 'min'),
        close=('close', 'last'),
        volume=('volume', 'sum'),
    )
    agg.index.name = None
    return agg


def synthesize_4h_from_daily(df_daily: pd.DataFrame, seed: int = 42) -> pd.DataFrame:
    """Improved daily→4H synthesizer (v3).

    Produces 2 deterministic 4H bars per NSE session:
      - Session 1 (09:15): open = daily open, close ≈ midpoint, high/low from
        morning session
      - Session 2 (13:15): open ≈ midpoint, close = daily close, high/low from
        afternoon session

    Volume split: 55% morning / 45% afternoon (NSE empirical average).
    High/Low distribution: each session gets a fraction of the daily range
    based on a deterministic hash of the date (no random noise — reproducible).

    This is APPROXIMATE. For production use real 4H data from Kite Connect
    (see ZERODHA_KITE_SETUP.md).
    """
    rng = np.random.RandomState(seed)
    rows = []
    for ts, row in df_daily.iterrows():
        o, h, l, c, v = row['open'], row['high'], row['low'], row['close'], row['volume']
        if any(pd.isna(x) for x in [o, h, l, c, v]):
            continue

        # Midpoint estimate: VWAP-like, weighted toward open and close
        mid = (o + c) / 2.0

        # Split intraday range: morning typically larger for gap stocks
        date_hash = int(pd.Timestamp(ts).strftime('%Y%m%d'))
        morning_frac = 0.55 + 0.10 * ((date_hash % 7) / 7.0 - 0.5)  # 0.50–0.60
        afternoon_frac = 1.0 - morning_frac

        # Morning session 09:15
        m_high = max(o, mid) + (h - max(o, c)) * morning_frac
        m_low = min(o, mid) - (min(o, c) - l) * morning_frac
        m_open = o
        m_close = mid
        m_vol = v * morning_frac

        # Afternoon session 13:15
        a_high = max(mid, c) + (h - max(o, c)) * afternoon_frac
        a_low = min(mid, c) - (min(o, c) - l) * afternoon_frac
        a_open = mid
        a_close = c
        a_vol = v * afternoon_frac

        rows.append({
            'ts': ts.normalize() + pd.Timedelta(hours=9, minutes=15),
            'open': m_open, 'high': m_high, 'low': m_low,
            'close': m_close, 'volume': m_vol,
        })
        rows.append({
            'ts': ts.normalize() + pd.Timedelta(hours=13, minutes=15),
            'open': a_open, 'high': a_high, 'low': a_low,
            'close': a_close, 'volume': a_vol,
        })

    if not rows:
        return pd.DataFrame(columns=['open', 'high', 'low', 'close', 'volume'])

    df_4h = pd.DataFrame(rows).set_index('ts')
    # Add Apollo indicator columns
    df_4h = compute_all_indicators(df_4h)
    return df_4h


def resample_weekly(df_daily: pd.DataFrame) -> pd.DataFrame:
    """Resample daily OHLCV to weekly (W-FRI anchor). Added v3 alias."""
    w = df_daily.resample('W-FRI').agg({
        'open': 'first', 'high': 'max', 'low': 'min',
        'close': 'last', 'volume': 'sum'
    }).dropna(subset=['close'])
    return w