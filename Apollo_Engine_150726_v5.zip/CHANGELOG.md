# Apollo Engine — Changelog

All notable changes to the Apollo Engine are documented here.
The format is loosely based on [Keep a Changelog](https://keepachangelog.com/).

---

## [v5.0.0] — 2026-07-15

### Summary
Adds (a) **disk-based data cache** so backtests no longer re-fetch yfinance data
every session, (b) **three selectable exit modes** for head-to-head comparison,
(c) **gap-down-aware stop-loss fills** (fixes v4's P&L-worse-than-5% bug), and
(d) a **stock bucketing framework** for per-regime tuning.

### Added
- **`scripts/data_cache.py`** (new)
  - Pickle-based disk cache at `/home/z/my-project/data_cache/<SYMBOL>.pkl`
  - Each cached entry contains: daily_df (OHLCV + Apollo indicators),
    4h_df (synthesized), weekly_df, metadata
  - `get_stock_data(symbol, start, end)` — returns cached or fetches+caches
  - Cache invalidation: manual (`--refresh`) or auto (if cached end_date < requested)
  - CLI: `python data_cache.py --list` / `--clear` / `--precache SYM1,SYM2`
  - Eliminates yfinance rate-limit failures across multi-mode backtests

- **`run_backtest_v5.py`** (new top-level entry point)
  - `extract_trades_v5(daily_results, df_d, exit_mode, sl_percent)` — single
    unified trade extractor supporting 4 exit modes
  - `run_backtest_v5(...)` — wraps v4 backtest loop, uses v5 extractor
  - `run_one_stock_mode(...)` — runs one stock × one exit mode
  - `generate_comparison_report(...)` — produces matrix-style XLSX with
    Stock × Mode P&L grid, per-mode aggregate, recommendation
  - CLI flags: `--exit-mode {NONE, FIXED_SL, TRAILING_SL, DI_CROSSOVER}`,
    `--compare-all` (runs all 4 modes on same universe), `--refresh` (force re-fetch)

- **`STOCK_BUCKETING_FRAMEWORK.md`** (new)
  - 5 buckets: Strong Uptrend, Cyclical/Range-Bound, High Volatility,
    Downtrend, Low Liquidity
  - Per-bucket: identification criteria, typical NSE examples, recommended
    Apollo tuning (entry/exit thresholds, SL type/width, position sizing)
  - Operational procedure: how to assign stocks to buckets using cached data
  - Validated on our 5 backtested stocks — correctly identified CENTRALBK
    as Bucket 4 (Downtrend) which Apollo should have skipped

- **`scripts/classify_buckets.py`** (new)
  - Reference implementation of the bucket classifier
  - Outputs per-stock: bucket assignment + all metrics driving the decision

### Fixed (vs v4)
- **Stop-loss gap-down bug**: v4 checked `close <= entry × 0.95` and exited at
  `close`, producing P&L as bad as -10.25% on gap-down days. v5 fixes this by:
  - Triggering SL when `close <= sl_price OR open <= sl_price`
  - Filling at `min(open, sl_price)` — realistic stop-order behavior
  - Verification: 6 of 8 CENTRALBK SL exits now at exactly -5.00%, only 2 with
    minor slippage (-5.11%, -5.72%) on true gap-down days

### Exit Modes (v5)

| Mode | Trigger | Fill Price | Use Case |
|------|---------|------------|----------|
| `NONE` | (no SL/crossover exit) | N/A | Baseline — only score<50 and divergence exits |
| `FIXED_SL` | `close ≤ entry × 0.95` OR `open ≤ entry × 0.95` | `min(open, sl_price)` | Hard risk cap; works for range-bound stocks |
| `TRAILING_SL` | `close ≤ peak_close × 0.95` OR `open ≤ peak_close × 0.95` | `min(open, sl_price)` | Trend-following; lets winners run |
| `DI_CROSSOVER` | `+DI[t-1] > -DI[t-1]` AND `+DI[t] < -DI[t]` | close | Directional reversal; momentum-aware |

All modes (except NONE) trigger 5-day cooldown after exit (reuses `DIVERGENCE_COOLDOWN`).
Period-end open trades always marked PERIOD_END (not SL), even if underwater.

### Comparison Results (5 stocks × 4 modes, 2024-01-01 → 2025-07-14)

| Mode | Avg P&L | Total Trades | Avg Win Rate | Avg Max DD | SL/Crossover Exits |
|------|---------|--------------|--------------|------------|---------------------|
| **NONE** (baseline) | **+29.2%** | 60 | 40% | -28.8% | 0 |
| FIXED_SL | +23.7% | 66 | 35% | -29.1% | 22 |
| DI_CROSSOVER | +19.4% | 72 | 35% | -27.4% | 16 (DI crosses) |
| TRAILING_SL | +5.3% | 90 | 41% | -23.3% | 71 (trail hits) |

**Per-stock best mode:**
- KAYNES: NONE (+120.7%) — trend was strong, SL/crossover cut winners short
- VTL: FIXED_SL (+33.9%) — SL contained gap-down risk in choppy tape
- ZYDUSWELL: FIXED_SL (+28.2%)
- RAINBOW: NONE (+30.5%)
- CENTRALBK: TRAILING_SL (-18.5%, vs -55.3% baseline) — trailing cut losses fastest

**Recommendation**: No single mode dominates. Per-bucket tuning (see
`STOCK_BUCKETING_FRAMEWORK.md`) is the right next step:
- Bucket 1 (Strong Uptrend) → NONE or TRAILING_SL (wide, 7-8%)
- Bucket 2 (Cyclical) → FIXED_SL (tight, 5%)
- Bucket 3 (High Volatility) → skip
- Bucket 4 (Downtrend) → skip

### Charter Impact

Proposed new rules:

> **Rule 10 (new) — Stock Bucketing**
> Every backtest MUST classify each stock into one of 5 buckets
> (Strong Uptrend, Cyclical, High Volatility, Downtrend, Low Liquidity)
> using documented criteria. The report MUST include a Bucket Assignment
> sheet showing each stock's bucket + the metrics that drove the assignment.
> Stocks in Bucket 4 (Downtrend) and Bucket 5 (Low Liquidity) MUST be
> flagged as "skip" with rationale; their backtest results (if any) MUST
> be quarantined to a separate sheet, not included in the main ranking.

> **Rule 11 (new) — Data Cache**
> Backtests MUST use the disk cache at `/home/z/my-project/data_cache/`
> for all yfinance data. Re-fetching is allowed only when (a) cache file
> is missing, (b) cached `end_date` is older than requested, or (c) user
> passes `--refresh`. This eliminates yfinance rate-limit failures and
> makes multi-mode comparisons fast (under 30 seconds for 5 stocks × 4 modes).

> **Rule 12 (new) — Exit Mode Disclosure**
> When a backtest uses an exit mode other than the default (score<50 +
> divergence), the report MUST disclose: (a) the exit mode name, (b) the
> trigger condition, (c) the fill price formula, (d) cooldown behavior.
> Comparison reports (multiple modes on same universe) MUST include a
> Stock × Mode P&L matrix and a per-mode aggregate row.

### Files Touched
| File | Change Type |
|------|-------------|
| `scripts/data_cache.py` | **New** |
| `scripts/classify_buckets.py` | **New** |
| `run_backtest_v5.py` | **New** |
| `STOCK_BUCKETING_FRAMEWORK.md` | **New** |
| `CHANGELOG.md` | Modified (this entry) |

### Backward Compatibility
- v2/v3/v4 entry points unchanged.
- v5 reads from disk cache transparently; if cache is empty, it falls back
  to yfinance (same behavior as v3/v4).

---

## [v4.0.0] — 2026-07-15

### Summary
Adds a **hard stop-loss** to the trade extraction logic. When enabled, any open
position that closes more than X% below its entry price is force-closed,
overriding the score-based exit and RSI divergence exit. This prevents runaway
losses when the engine's recovery-detection thesis fails.

### Added
- **`run_backtest_v4.py`** (new top-level entry point)
  - `extract_trades_with_sl(daily_results, df_d, sl_percent=5.0)` — drop-in
    replacement for `v2.extract_trades` with stop-loss logic
  - `run_backtest_with_sl(...)` — wraps the v2 backtest loop but uses the
    SL-aware extractor
  - `pick_random_stocks_filtered(n, seed, min_listing_date)` — picks random
    stocks and **filters out any listed on/after the backtest start** (verified
    via yfinance probe of a 1-month window in 2022-11)
  - `generate_consolidated_report_v4(...)` — extends v3's report with:
    - "SL Hits" column in the stock ranking table
    - Exit Type Breakdown in Portfolio Aggregate (SL / Divergence / Score<50 / Period-End)
    - Avg P&L per SL trade metric
    - Per-stock Stop-Loss Analysis sub-section with avg/worst/best SL P&L
    - Pink color coding for SL_HIT exit rows (vs green=ENTRY, orange=DIVERGENCE, red=SCORE<50, gray=PERIOD_END)
  - CLI flags: `--sl-percent` (default 5.0), `--seed` (default 123)

### Stop-Loss Semantics (IMPORTANT — read before tuning)
- **Trigger**: `close <= entry_price * (1 - sl_percent/100)` on any daily close
- **Checked on**: daily close only (not intraday)
- **Precedence**: SL > divergence exit > score-based exit (`score < 50`)
- **Cooldown after SL**: 5 trading days (same as divergence exit — reuses `DIVERGENCE_COOLDOWN` constant)
- **Period-end open trades**: marked `PERIOD_END`, NOT `SL_HIT`, even if underwater
  by more than `sl_percent`. Rationale: a position still open at backtest end is
  a "hold" decision, not a stop-out — the SL rule only fires intra-period.
- **Exit reason text**: `"SL_HIT (-X.X% stop-loss from entry Y.YY)"`

### Backward Compatibility
- Original `run_backtest.py` (v2) and `run_backtest_v3.py` are **unchanged**.
- Setting `--sl-percent 0` in v4 disables SL entirely, producing v3 behavior.
- All v3 indicator auto-compute, 4H synthesis, and consolidated report features
  carry through unchanged.

### Charter Impact

Proposed new rule:

> **Rule 9 (new) — Stop-Loss Specification**
> When a backtest includes a stop-loss, the report MUST disclose:
> (a) the SL percentage and whether it is from entry or peak,
> (b) the SL precedence relative to other exit rules,
> (c) the cooldown applied after an SL exit,
> (d) how period-end open trades are treated (SL vs PERIOD_END).
> Filename convention for SL-enabled backtests:
> `Apollo_Engine_BT_[ddmmyy]_v[N]_N[tickers]_SL[percent].xlsx`

### Files Touched
| File | Change Type |
|------|-------------|
| `run_backtest_v4.py` | **New** |
| `CHANGELOG.md` | Modified (this entry) |

### v4 vs v3 Backtest Comparison (same 5-stock universe — different stocks due to seed)

| Metric | v3 (no SL) | v4 (5% SL) |
|--------|------------|------------|
| Stocks backtested | 5 | 5 (different set) |
| Avg cumulative P&L | +17.4% | +28.3% |
| Total trades | 45 | 64 |
| Avg win rate | 34% | 37% |
| SL-triggered exits | N/A | 19 (29.7% of all exits) |

**Caveat**: The v3 and v4 backtests use **different stocks** (v3 seed=42, v4 seed=123),
so the numbers above are NOT a controlled A/B test of the SL rule's impact on the
SAME portfolio. To run a true A/B comparison, use the same `--tickers` list for
both v3 and v4.

---

## [v3.0.0] — 2026-07-15

### Summary
Apollo Engine can now backtest **any NSE stock from raw OHLCV data** (e.g. yfinance)
without requiring pre-computed indicator CSVs from ChartAlert/Spider. When real 4H
intraday data is unavailable, the engine synthesizes deterministic 4H bars from daily
bars and discloses this in the report. Multi-stock batched backtests with consolidated
reporting are now first-class.

### Added
- **`apollo_engine/indicators.py`**
  - `compute_wc(df, period)` — generic WC SMA helper.
  - `compute_wc21(df)` — 21-period SMA of Weighted Close (was missing; needed for B6 signal).
  - `compute_all_indicators(df)` — single entry point that produces the full Apollo
    indicator set (RSI 21/36/56, TP28, WC21, WC50, +DI/-DI/ADX 14, MACD 12/26/9,
    Signal, Histogram) named in the original ChartAlert schema.
  - `APOLLO_INDICATOR_SPEC` — declarative spec mapping Apollo column names to their
    (function, args) tuples.
  - `get_indicator_provenance(df)` — tags each indicator column as `pre_supplied`
    or `computed` (charter rule 7).

- **`apollo_engine/data_loader.py`**
  - `parse_apollo_date(date_str)` — handles `"Thu Aug 11 2022 00:00:00 GMT+0530 (India Standard Time)"`.
  - `normalize_apollo_csv(df)` — strips zero-width chars, lowercases columns,
    extracts engine-friendly aliases (rsi21, tp28, wc21, etc.).
  - `load_daily_csv_auto(path)` / `load_4h_csv_auto(path)` — backward-compatible
    loaders that auto-compute missing indicators. Returns `(df, provenance_dict)`.
  - `aggregate_intraday_to_4h(df_intraday)` — converts real 1h/15m Kite Connect
    data into NSE-anchored 4H bars (09:15, 13:15 buckets). Use this when you have
    a paid Kite subscription.
  - `synthesize_4h_from_daily(df_daily, seed=42)` — deterministic daily→4H
    synthesizer (2 bars/NSE session, 55/45 volume split, no random noise).
    Used as fallback when real 4H is unavailable.
  - `resample_weekly(df_daily)` — added W-FRI anchored resampler (engine-compatible
    alias of the existing function in `run_backtest.py`).

- **`apollo_engine/__init__.py`**
  - Re-exported all new functions.
  - Bumped `__version__` to `"3.0.0"`.

- **`run_backtest_v3.py`** (new top-level entry point)
  - Multi-stock batched backtest with consolidated XLSX output.
  - Auto-fetches yfinance data with 1-year warmup.
  - Picks N random stocks from `smallcap250.json` (seeded for reproducibility).
  - Auto-retries rate-limited tickers; falls back to replacement picks.
  - Generates one XLSX with: Summary sheet + one sheet per stock containing
    KPIs, Trade Log, Signal Analysis, and Critical Findings.
  - Data Provenance block in Summary sheet (charter rule 7).

- **`requirements.txt`**
  - Added `yfinance>=0.2.30`.

- **`ZERODHA_KITE_SETUP.md`** (new)
  - Step-by-step guide to register, authenticate, and fetch real 4H historical
    data from Kite Connect (free tier for daily, paid for intraday >60 days).

- **`CHANGELOG.md`** (this file).

### Changed
- **`apollo_engine/indicators.py`**
  - Refactored `compute_wc50` to delegate to new `compute_wc` helper (no behaviour
    change for existing callers).

### Backward Compatibility
- Existing `run_backtest.py` is **unchanged** and continues to work with the
  original `data/APOLLO D.csv` + `data/APOLLO 4H.csv` ChartAlert export format.
- Existing `apollo_engine.engine.ApolloAnalysisEngine` API is **unchanged**.
- `compute_rsi`, `compute_tp28`, `compute_wc50`, `compute_adx`, `compute_macd`
  signatures and behaviour are **unchanged**.

### Charter Impact

The following two rules are proposed as addenda to the Apollo Project Charter:

> **Rule 7 (new) — Indicator Auto-Compute Mode**
> When input CSVs lack pre-computed indicator columns (RSI, TP, WC, ADX, MACD),
> the engine MUST auto-compute them using documented formulas in
> `apollo_engine/indicators.py`. The report's Executive Summary MUST flag which
> indicators were computed vs. pre-supplied via a "Data Provenance" row.
> Synthetic 4H bars (when used) MUST be disclosed in the same row.

> **Rule 8 (new) — Consolidated Reports**
> A backtest request for N>1 stocks produces a single XLSX with: (1) Summary
> sheet ranking all stocks by cumulative P&L, (2) one sheet per stock containing
> Executive Summary + Trade Log + Signal Analysis. Filename:
> `Apollo_Engine_BT_[ddmmyy]_v[N]_N[tickers].xlsx`.

### Files Touched
| File | Change Type |
|------|-------------|
| `apollo_engine/__init__.py` | Modified (version bump, re-exports) |
| `apollo_engine/indicators.py` | Modified (added WC21 + compute_all_indicators) |
| `apollo_engine/data_loader.py` | Modified (added auto-loader, 4H synthesizer, intraday aggregator) |
| `run_backtest_v3.py` | **New** |
| `requirements.txt` | Modified (added yfinance) |
| `CHANGELOG.md` | **New** |
| `ZERODHA_KITE_SETUP.md` | **New** |

---

## [v2.0.0] — 2026-07-14 (Apollo_Engine_150726_v2.zip)

Original v6 reproduction build. 21 signals, 6 pools, entry=70, exit=50.
Reads pre-computed indicator CSVs in ChartAlert format.
