"""Apollo Backtest Studio — Streamlit front-end.

A local Python backtesting application for NSE stocks using the eod2 data
source and Apollo multi-timeframe RSI recovery scoring engine.

Run with:
    cd /path/to/apollo_app
    streamlit run app.py

Version: 2.0 — With SQLite Backtest History
"""

from __future__ import annotations

import json
import sys
import time
from datetime import date, datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from apollo_engine.backtest import run_stock_backtest
from apollo_engine.eod2_loader import scan_eod2_directory
from report_generator import generate_report
from backtest_history import BacktestHistory, save_current_backtest


# =====================================================================
# Page Config & Theme
# =====================================================================
st.set_page_config(
    page_title="Apollo Backtest Studio",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="collapsed",
)

DARK_CSS = """
<style>
    /* ---- Global ---- */
    .stApp {
        background-color: #0f1117;
        color: #e2e8f0;
    }
    /* ---- Block containers ---- */
    .stApp > div > div > div {
        background-color: #161b22;
    }
    /* ---- Sidebar ---- */
    [data-testid="stSidebar"] {
        background-color: #0f1117 !important;
    }
    [data-testid="stSidebar"] * {
        color: #e2e8f0 !important;
    }
    /* ---- Tabs ---- */
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
        background-color: #161b22;
    }
    .stTabs [data-baseweb="tab"] {
        background-color: #1e2430;
        color: #94a3b8;
        border-radius: 8px 8px 0 0;
        padding: 10px 24px;
        font-weight: 500;
    }
    .stTabs [aria-selected="true"] {
        background-color: #14b8a6 !important;
        color: #0f1117 !important;
        font-weight: 700;
    }
    .stTabs [data-baseweb="tab-highlight"] {
        background-color: #14b8a6;
        height: 3px;
    }
    /* ---- Dataframe ---- */
    .stDataFrame {
        background-color: #161b22;
    }
    /* ---- Metric cards ---- */
    [data-testid="stMetric"] {
        background-color: #1e2430;
        border-radius: 10px;
        padding: 16px;
        border: 1px solid #2d3748;
    }
    [data-testid="stMetricLabel"] {
        color: #94a3b8;
        font-size: 13px;
    }
    [data-testid="stMetricValue"] {
        color: #e2e8f0;
        font-size: 22px;
        font-weight: 700;
    }
    /* ---- Buttons ---- */
    .stButton > button {
        background-color: #14b8a6;
        color: #0f1117;
        font-weight: 600;
        border-radius: 8px;
        border: none;
        padding: 8px 24px;
    }
    .stButton > button:hover {
        background-color: #0d9488;
        color: #ffffff;
    }
    /* ---- Selectbox / Input ---- */
    div[data-testid="stTextInput"] label,
    div[data-testid="stSelectbox"] label,
    div[data-testid="stSlider"] label {
        color: #e2e8f0;
    }
    /* ---- Progress bar ---- */
    .stProgress > div > div > div {
        background-color: #14b8a6;
    }
    /* ---- Expander ---- */
    .streamlit-expanderHeader {
        color: #e2e8f0;
    }
    /* ---- Scrollbar ---- */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    ::-webkit-scrollbar-track {
        background: #0f1117;
    }
    ::-webkit-scrollbar-thumb {
        background: #2d3748;
        border-radius: 4px;
    }
    ::-webkit-scrollbar-thumb:hover {
        background: #4a5568;
    }
</style>
"""
st.markdown(DARK_CSS, unsafe_allow_html=True)

# =====================================================================
# Defaults
# =====================================================================
DEFAULT_DATA_DIR = (
    r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research"
    r"\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily"
)
DEFAULT_START = date(2024, 1, 1)
DEFAULT_END = date.today()
# Universe files — user can pick which one to load
UNIVERSE_FILES = {
    "My Watchlist": Path(__file__).parent / "my_watchlist.json",
    "Nifty Smallcap 500": Path(__file__).parent / "smallcap500.json",
}
DEFAULT_UNIVERSE = "My Watchlist"

EXIT_MODE_DESCRIPTIONS = {
    "NONE": "No stop-loss — exits only via score drop or divergence detection.",
    "FIXED_SL": "Hard stop-loss at a fixed % below the entry price (gap-down aware).",
    "TRAILING_SL": "Stop-loss trails from the highest close seen since entry.",
    "DI_CROSSOVER": "Exit when +DI crosses below -DI on the daily timeframe.",
}


# =====================================================================
# Session-state initialization
# =====================================================================
for key, default in [
    ("data_dir", DEFAULT_DATA_DIR),
    ("stock_list", None),
    ("selected_stocks", set()),
    ("universe_choice", DEFAULT_UNIVERSE),
    ("universe_auto_loaded", False),
    ("start_date", DEFAULT_START),
    ("end_date", DEFAULT_END),
    ("exit_mode", "FIXED_SL"),
    ("sl_percent", 5.0),
    ("entry_threshold", 70),
    ("exit_threshold", 50),
    ("divergence_rsi_drop", 3.0),
    ("divergence_cooldown", 5),
    ("backtest_results", None),
    ("run_in_progress", False),
    ("failed_stocks", []),
    ("backtest_duration", 0.0),
    # NEW: History-related session state
    ("history_db", None),
    ("last_saved_run_id", None),
]:
    if key not in st.session_state:
        st.session_state[key] = default


# =====================================================================
# Cached helpers
# =====================================================================

@st.cache_data(show_spinner=False)
def _cached_scan(data_dir: str) -> list[dict]:
    """Scan an eod2 data directory (cached by data_dir)."""
    return scan_eod2_directory(data_dir)


def _load_universe_json(path: Path) -> list[dict]:
    """Load the smallcap500 universe JSON."""
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def _sym_to_eod2(sym: str) -> str:
    """Convert Yahoo/NSE-style symbol (e.g. 'RHIM.NS') to eod2 filename stem."""
    return sym.replace(".NS", "").replace(".BO", "").lower()


# =====================================================================
# Helper: colour for P&L
# =====================================================================
def _pnl_colour(val: float) -> str:
    if val > 0:
        return "#14b8a6"  # teal-green
    elif val < 0:
        return "#ef4444"  # red
    return "#94a3b8"  # grey


# =====================================================================
# HEADER
# =====================================================================
st.markdown(
    """
    <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
        <span style="font-size:32px;">🚀</span>
        <h1 style="margin:0; color:#14b8a6; font-family:monospace;">
            Apollo Backtest Studio
        </h1>
    </div>
    <p style="color:#64748b; margin-top:0;">
        Multi-timeframe RSI Recovery Scoring Engine &mdash; NSE Backtester
        <span style="background:#1e293b; padding:2px 8px; border-radius:4px; font-size:12px; margin-left:8px;">
            v2.0 with History
        </span>
    </p>
    """,
    unsafe_allow_html=True,
)

# =====================================================================
# TABS (MODIFIED: Added History tab)
# =====================================================================
tab_data, tab_strategy, tab_run, tab_results, tab_history = st.tabs([
    "📊 Data",
    "⚙️ Strategy",
    "🚀 Run",
    "📈 Results",
    "📂 History",  # NEW TAB
])


# =====================================================================
# TAB 1 — DATA
# =====================================================================
with tab_data:
    st.markdown("#### Data Source")

    col_path, col_btn = st.columns([4, 1])
    with col_path:
        data_dir = st.text_input(
            "EOD2 Data Directory (containing .csv files)",
            value=st.session_state.data_dir,
            placeholder=r"C:\path\to\eod2_data\daily",
            key="data_dir_input",
        )
    with col_btn:
        st.markdown("<br>", unsafe_allow_html=True)  # vertical spacer
        scan_clicked = st.button("🔍 Scan Directory", use_container_width=True)

    if scan_clicked:
        st.session_state.data_dir = data_dir
        st.session_state.universe_auto_loaded = False  # reset so auto-load re-fires
        with st.spinner("Scanning directory..."):
            try:
                st.session_state.stock_list = _cached_scan(data_dir)
                st.session_state.selected_stocks = set()
                st.success(
                    f"Found **{len(st.session_state.stock_list)}** stocks."
                )
            except Exception as exc:
                st.error(f"Scan failed: {exc}")
                st.session_state.stock_list = None

    stock_list = st.session_state.stock_list
    if stock_list is not None and len(stock_list) > 0:
        st.markdown("---")

        # --- Auto-load default universe (runs once per scan) ---
        if not st.session_state.universe_auto_loaded:
            default_file = UNIVERSE_FILES.get(DEFAULT_UNIVERSE)
            if default_file and default_file.exists():
                universe = _load_universe_json(default_file)
                universe_syms = {_sym_to_eod2(item["sym"]) for item in universe}
                available = {item["symbol"] for item in stock_list}
                matched = universe_syms & available
                st.session_state.selected_stocks = matched
                st.session_state.universe_auto_loaded = True
                st.info(
                    f"Auto-loaded **{DEFAULT_UNIVERSE}**: "
                    f"matched **{len(matched)}** of **{len(universe)}** stocks. "
                    f"Use the dropdown below to switch universe."
                )

        # Universe selector + loader
        col_uni_pick, col_uni_btn, col_info = st.columns([2, 1, 3])
        with col_uni_pick:
            st.session_state.universe_choice = st.selectbox(
                "Universe",
                options=list(UNIVERSE_FILES.keys()),
                index=list(UNIVERSE_FILES.keys()).index(
                    st.session_state.universe_choice
                )
                if st.session_state.universe_choice in UNIVERSE_FILES
                else 0,
                help="Choose which stock universe to load. 'My Watchlist' uses your custom tickers.",
            )
        with col_uni_btn:
            load_uni = st.button(
                "🌐 Load Universe",
                help="Pre-select stocks from the chosen universe file",
                use_container_width=True,
            )
        with col_info:
            chosen_file = UNIVERSE_FILES.get(st.session_state.universe_choice)
            if chosen_file and chosen_file.exists():
                st.markdown(
                    f'<span style="color:#64748b; font-size:13px;">'
                    f'Universe file: <code>{chosen_file.name}</code> found.</span>',
                    unsafe_allow_html=True,
                )
            elif chosen_file:
                st.warning(f"Universe file not found at `{chosen_file}`")

        if load_uni:
            chosen_file = UNIVERSE_FILES.get(st.session_state.universe_choice)
            if chosen_file and chosen_file.exists():
                universe = _load_universe_json(chosen_file)
                universe_syms = {_sym_to_eod2(item["sym"]) for item in universe}
                available = {item["symbol"] for item in stock_list}
                matched = universe_syms & available
                st.session_state.selected_stocks = matched
                st.success(
                    f"Matched **{len(matched)}** of **{len(universe)}** "
                    f"{st.session_state.universe_choice} "
                    f"stocks to the scanned directory."
                )
            else:
                st.error(
                    f"Universe file for **{st.session_state.universe_choice}** "
                    f"not found. Please check the file exists."
                )

        # Search filter
        search_term = st.text_input(
            "🔎 Filter by symbol",
            placeholder="Type to filter...",
            key="stock_filter",
        )

        # Select All / Deselect All
        col_sa, col_da = st.columns(2)
        with col_sa:
            if st.button("Select All (filtered)", use_container_width=True):
                filtered = [
                    item["symbol"]
                    for item in stock_list
                    if search_term.lower() in item["symbol"].lower()
                ]
                st.session_state.selected_stocks.update(filtered)
        with col_da:
            if st.button("Deselect All", use_container_width=True):
                st.session_state.selected_stocks = set()

        # Dataframe showing available stocks
        filtered_list = [
            item
            for item in stock_list
            if search_term.lower() in item["symbol"].lower()
        ]

        if filtered_list:
            df_scan = pd.DataFrame(filtered_list)
            st.dataframe(
                df_scan[["symbol", "rows", "date_start", "date_end"]].rename(
                    columns={
                        "symbol": "Symbol",
                        "rows": "Rows",
                        "date_start": "Date Start",
                        "date_end": "Date End",
                    }
                ),
                use_container_width=True,
                height=420,
                hide_index=True,
                column_config={
                    "Symbol": st.column_config.TextColumn("Symbol", width="medium"),
                    "Rows": st.column_config.NumberColumn("Rows", format="%d"),
                    "Date Start": st.column_config.TextColumn("Date Start"),
                    "Date End": st.column_config.TextColumn("Date End"),
                },
            )

            # Manual selection via multiselect
            current_sel = st.multiselect(
                "Selected stocks (or use buttons above)",
                options=[item["symbol"] for item in stock_list],
                default=sorted(st.session_state.selected_stocks),
                key="manual_stock_select",
            )
            st.session_state.selected_stocks = set(current_sel)

        n_selected = len(st.session_state.selected_stocks)
        n_total = len(stock_list)
        st.markdown(
            f"<div style='padding:10px 16px; background:#1e2430; border-radius:8px; "
            f"border-left:4px solid #14b8a6; color:#e2e8f0;'>"
            f'<b>{n_selected}</b> of <b>{n_total}</b> stocks selected'
            f'</div>',
            unsafe_allow_html=True,
        )
    elif stock_list is not None:
        st.info("No CSV files found in the specified directory.")
    else:
        st.info(
            "Enter your eod2 data directory path above and click **Scan Directory** "
            "to discover available stocks."
        )


# =====================================================================
# TAB 2 — STRATEGY
# =====================================================================
with tab_strategy:
    st.markdown("#### Strategy Parameters")

    c1, c2 = st.columns(2)
    with c1:
        st.session_state.entry_threshold = st.slider(
            "Entry Threshold",
            min_value=50,
            max_value=100,
            value=st.session_state.entry_threshold,
            step=5,
            help="Minimum Apollo score required to enter a trade.",
        )
        st.session_state.exit_threshold = st.slider(
            "Exit Threshold",
            min_value=30,
            max_value=80,
            value=st.session_state.exit_threshold,
            step=5,
            help="Score below this triggers an exit when in a trade.",
        )
        st.session_state.exit_mode = st.selectbox(
            "Exit Mode",
            options=["NONE", "FIXED_SL", "TRAILING_SL", "DI_CROSSOVER"],
            index=["NONE", "FIXED_SL", "TRAILING_SL", "DI_CROSSOVER"].index(
                st.session_state.exit_mode
            ),
            help="Select the exit mechanism.",
        )
        st.caption(EXIT_MODE_DESCRIPTIONS.get(st.session_state.exit_mode, ""))

    with c2:
        if st.session_state.exit_mode != "NONE":
            st.session_state.sl_percent = st.slider(
                "Stop Loss %",
                min_value=1.0,
                max_value=15.0,
                value=st.session_state.sl_percent,
                step=0.5,
                help="Stop-loss percentage (fixed or trailing depending on mode).",
            )
        else:
            st.session_state.sl_percent = 0.0
            st.markdown(
                '<span style="color:#64748b;">SL disabled (exit mode = NONE)</span>',
                unsafe_allow_html=True,
            )

        st.session_state.divergence_rsi_drop = st.slider(
            "Divergence RSI Drop",
            min_value=1.0,
            max_value=10.0,
            value=st.session_state.divergence_rsi_drop,
            step=0.5,
            help="RSI must drop this many points below peak to trigger divergence exit.",
        )
        st.session_state.divergence_cooldown = int(
            st.slider(
                "Cooldown Days",
                min_value=1,
                max_value=15,
                value=st.session_state.divergence_cooldown,
                step=1,
                help="Trading days after a non-score exit before re-entry is allowed.",
            )
        )

    st.markdown("---")
    st.markdown("#### Date Range")

    col_sd, col_ed = st.columns(2)
    with col_sd:
        st.session_state.start_date = st.date_input(
            "Start Date",
            value=st.session_state.start_date,
            min_value=date(2010, 1, 1),
            max_value=date.today(),
        )
    with col_ed:
        st.session_state.end_date = st.date_input(
            "End Date",
            value=st.session_state.end_date,
            min_value=date(2010, 1, 1),
            max_value=date.today(),
        )

    # Save / Load strategy
    st.markdown("---")
    col_save, col_load = st.columns(2)
    with col_save:
        strategy_json = json.dumps({
            "entry_threshold": st.session_state.entry_threshold,
            "exit_threshold": st.session_state.exit_threshold,
            "exit_mode": st.session_state.exit_mode,
            "sl_percent": st.session_state.sl_percent,
            "divergence_rsi_drop": st.session_state.divergence_rsi_drop,
            "divergence_cooldown": st.session_state.divergence_cooldown,
            "start_date": str(st.session_state.start_date),
            "end_date": str(st.session_state.end_date),
        }, indent=2)
        st.download_button(
            "💾 Save Strategy",
            data=strategy_json.encode("utf-8"),
            file_name="apollo_strategy.json",
            mime="application/json",
            use_container_width=True,
        )
    with col_load:
        uploaded = st.file_uploader(
            "📂 Load Strategy",
            type=["json"],
            label_visibility="collapsed",
        )
        if uploaded is not None:
            try:
                s = json.loads(uploaded.read().decode("utf-8"))
                st.session_state.entry_threshold = s.get("entry_threshold", 70)
                st.session_state.exit_threshold = s.get("exit_threshold", 50)
                st.session_state.exit_mode = s.get("exit_mode", "FIXED_SL")
                st.session_state.sl_percent = s.get("sl_percent", 5.0)
                st.session_state.divergence_rsi_drop = s.get("divergence_rsi_drop", 3.0)
                st.session_state.divergence_cooldown = s.get("divergence_cooldown", 5)
                if s.get("start_date"):
                    st.session_state.start_date = date.fromisoformat(s["start_date"])
                if s.get("end_date"):
                    st.session_state.end_date = date.fromisoformat(s["end_date"])
                st.success("Strategy loaded! Refresh the page to see updated sliders.")
            except Exception as exc:
                st.error(f"Failed to load strategy: {exc}")

    # Summary card
    n_sel = len(st.session_state.selected_stocks)
    st.markdown("---")
    st.markdown(
        f"<div style='padding:14px 20px; background:#1e2430; border-radius:10px; "
        f"border:1px solid #2d3748; color:#e2e8f0;'>"
        f"📊 With current settings, <b style='color:#14b8a6;'>{n_sel}</b> "
        f"stocks will be backtested from "
        f"<b>{st.session_state.start_date}</b> to "
        f"<b>{st.session_state.end_date}</b>.<br>"
        f"<span style='color:#64748b;'>"
        f"Entry>={st.session_state.entry_threshold} | "
        f"Exit<{st.session_state.exit_threshold} | "
        f"Mode={st.session_state.exit_mode} | "
        f"SL={st.session_state.sl_percent}%"
        f"</span>"
        f"</div>",
        unsafe_allow_html=True,
    )


# =====================================================================
# TAB 3 — RUN
# =====================================================================
with tab_run:
    st.markdown("#### Backtest Execution")

    n_sel = len(st.session_state.selected_stocks)

    # Parameter summary
    st.markdown(
        f"<div style='display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); "
        f"gap:12px; margin-bottom:20px;'>"
        f"<div style='padding:12px; background:#1e2430; border-radius:8px; border-left:3px solid #14b8a6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Stocks</span><br>"
        f"<b style='color:#e2e8f0;'>{n_sel}</b>"
        f"</div>"
        f"<div style='padding:12px; background:#1e2430; border-radius:8px; border-left:3px solid #14b8a6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Date Range</span><br>"
        f"<b style='color:#e2e8f0;'>{st.session_state.start_date} → {st.session_state.end_date}</b>"
        f"</div>"
        f"<div style='padding:12px; background:#1e2430; border-radius:8px; border-left:3px solid #14b8a6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Entry / Exit</span><br>"
        f"<b style='color:#e2e8f0;'>>={st.session_state.entry_threshold} / <{st.session_state.exit_threshold}</b>"
        f"</div>"
        f"<div style='padding:12px; background:#1e2430; border-radius:8px; border-left:3px solid #14b8a6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Exit Mode</span><br>"
        f"<b style='color:#e2e8f0;'>{st.session_state.exit_mode}"
        f"{f' ({st.session_state.sl_percent}% SL)' if st.session_state.exit_mode != 'NONE' else ''}"
        f"</b>"
        f"</div>"
        f"</div>",
        unsafe_allow_html=True,
    )

    # Dynamic content placeholder
    run_placeholder = st.empty()
    progress_placeholder = st.empty()
    status_placeholder = st.empty()

    col_start, col_stop = st.columns(2)
    with col_start:
        start_disabled = n_sel == 0 or st.session_state.run_in_progress
        start_btn = st.button(
            "▶ Start Backtest",
            disabled=start_disabled,
            use_container_width=True,
            type="primary",
        )
    with col_stop:
        stop_btn = st.button(
            "⏹ Stop",
            disabled=not st.session_state.run_in_progress,
            use_container_width=True,
        )

    if stop_btn:
        st.session_state.run_in_progress = False
        st.warning("Backtest stopped by user.")

    if start_btn and n_sel > 0:
        st.session_state.run_in_progress = True
        st.session_state.backtest_results = []
        st.session_state.failed_stocks = []

        selected = sorted(st.session_state.selected_stocks)
        total = len(selected)
        t0 = time.time()

        progress_bar = progress_placeholder.progress(0, text="Starting...")
        status_area = status_placeholder.empty()

        for idx, sym in enumerate(selected):
            if not st.session_state.run_in_progress:
                break

            pct = (idx + 1) / total
            progress_bar.progress(pct, text=f"Processing {idx+1}/{total}")

            try:
                result = run_stock_backtest(
                    data_dir=st.session_state.data_dir,
                    symbol=sym,
                    start_date=str(st.session_state.start_date),
                    end_date=str(st.session_state.end_date),
                    exit_mode=st.session_state.exit_mode,
                    sl_percent=st.session_state.sl_percent,
                    entry_threshold=st.session_state.entry_threshold,
                    exit_threshold=st.session_state.exit_threshold,
                )
                st.session_state.backtest_results.append(result)

                # Compute n_days from daily_df
                if result.get("daily_df") is not None and not result["daily_df"].empty:
                    result["n_days"] = len(result["daily_df"])
                else:
                    result["n_days"] = 0

                pnl_str = f"{result['cum_pnl']:+.2f}%" if result.get("cum_pnl") else "N/A"
                status_area.markdown(
                    f"<span style='color:#64748b;'>Processing:</span> "
                    f"<b style='color:#e2e8f0;'>{sym.upper()}</b> &mdash; "
                    f"Trades: **{result.get('n_trades', 0)}** | "
                    f"P&L: **{pnl_str}** | "
                    f"Win Rate: **{result.get('win_rate', 0)}%**",
                    unsafe_allow_html=True,
                )

            except Exception as exc:
                st.session_state.failed_stocks.append({"symbol": sym, "error": str(exc)})
                status_area.markdown(
                    f"<span style='color:#ef4444;'>⚠ {sym.upper()} failed: {exc}</span>",
                    unsafe_allow_html=True,
                )

        elapsed = round(time.time() - t0, 2)
        st.session_state.backtest_duration = elapsed
        st.session_state.run_in_progress = False

        progress_bar.progress(1.0, text="Complete!")
        n_ok = len(st.session_state.backtest_results)
        n_fail = len(st.session_state.failed_stocks)
        
        # ============================================================
        # AUTO-SAVE TO HISTORY (NEW)
        # ============================================================
        try:
            saved_run_id = save_current_backtest(
                results=st.session_state.backtest_results,
                session_state=st.session_state,
                duration=elapsed,
                failed=st.session_state.failed_stocks,
            )
            st.session_state.last_saved_run_id = saved_run_id
            
            status_placeholder.success(
                f"✅ Backtest complete in **{elapsed}s**! "
                f"{n_ok} stocks processed, {n_fail} failed. "
                f"💾 **Auto-saved as Run #{saved_run_id}**"
            )
        except Exception as save_err:
            # If auto-save fails, still show success but warn about save failure
            status_placeholder.success(
                f"✅ Backtest complete in **{elapsed}s**! "
                f"{n_ok} stocks processed, {n_fail} failed. "
                f"⚠️ Auto-save failed: {save_err}"
            )
        # ============================================================
        
        if n_fail > 0:
            with st.expander("Failed Stocks", expanded=False):
                for fs in st.session_state.failed_stocks:
                    st.markdown(
                        f"- **{fs['symbol']}**: `{fs['error']}`"
                    )

        st.markdown(
            "<div style='margin-top:16px;'>"
            "<span style='color:#14b8a6; font-weight:600;'>→ Switch to the "
            "</span>"
            "<span style='color:#14b8a6; font-weight:600; text-decoration:underline; cursor:pointer;'>"
            "📈 Results tab</span>"
            "<span style='color:#14b8a6; font-weight:600;'> to view your backtest results.</span>"
            "<br><span style='color:#14b8a6; font-weight:600;'>→ Or go to "
            "</span>"
            "<span style='color:#14b8a6; font-weight:600; text-decoration:underline; cursor:pointer;'>"
            "📂 History tab</span>"
            "<span style='color:#14b8a6; font-weight:600;'> to compare with past runs.</span>"
            "</div>",
            unsafe_allow_html=True,
        )

    elif start_btn and n_sel == 0:
        st.warning("No stocks selected. Go to the Data tab to select stocks.")

    # If already completed, show a reminder
    if (
        st.session_state.backtest_results is not None
        and len(st.session_state.backtest_results) > 0
        and not start_btn
    ):
        last_run_msg = ""
        if st.session_state.last_saved_run_id:
            last_run_msg = f" (Saved as Run #{st.session_state.last_saved_run_id})"
        st.info(
            f"A previous backtest with **{len(st.session_state.backtest_results)}** stocks "
            f"is available in the Results tab.{last_run_msg}"
        )


# =====================================================================
# TAB 4 — RESULTS
# =====================================================================
with tab_results:
    results = st.session_state.backtest_results

    if results is None or len(results) == 0:
        st.markdown(
            """
            <div style="text-align:center; padding:60px 0;">
                <span style="font-size:48px;">📊</span>
                <h2 style="color:#64748b;">No Results Yet</h2>
                <p style="color:#475569;">
                Run a backtest from the <b>Run</b> tab to see results here.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.stop()

    # ---------------------------------------------------------------
    # Aggregate metrics
    # ---------------------------------------------------------------
    total_trades = sum(r.get("n_trades", 0) for r in results)
    total_entries = sum(len(r.get("entries", [])) for r in results)
    all_completed = []
    for r in results:
        all_completed.extend(r.get("completed", []))
    winning = [e for e in all_completed if e.get("pnl", 0) > 0]
    losing = [e for e in all_completed if e.get("pnl", 0) <= 0]
    win_rate = (
        round(len(winning) / len(all_completed) * 100, 1)
        if all_completed
        else 0.0
    )
    total_cum_pnl = sum(r.get("cum_pnl", 0.0) for r in results)
    stocks_with_trades = [r for r in results if r.get("n_trades", 0) > 0]
    avg_pnl = (
        round(
            sum(r.get("avg_pnl_per_trade", 0.0) for r in stocks_with_trades)
            / max(1, len(stocks_with_trades)),
            2,
        )
    )
    max_dd_vals = [
        r.get("max_drawdown", 0.0)
        for r in results
        if r.get("max_drawdown", 0.0) != 0.0
    ]
    avg_max_dd = round(sum(max_dd_vals) / len(max_dd_vals), 2) if max_dd_vals else 0.0
    worst_dd = round(min(max_dd_vals), 2) if max_dd_vals else 0.0

    # Section 1: Metric Cards
    st.markdown("#### Portfolio Overview")
    mc1, mc2, mc3, mc4, mc5, mc6 = st.columns(6)
    cards = [
        (mc1, "Total Stocks", len(results), "#e2e8f0"),
        (mc2, "Total Trades", total_trades, "#e2e8f0"),
        (mc3, "Win Rate", f"{win_rate}%", _pnl_colour(win_rate)),
        (mc4, "Avg P&L/Trade", f"{avg_pnl}%", _pnl_colour(avg_pnl)),
        (mc5, "Cumulative P&L", f"{total_cum_pnl:+.2f}%", _pnl_colour(total_cum_pnl)),
        (mc6, "Worst Max DD", f"{worst_dd}%", _pnl_colour(worst_dd)),
    ]
    for col, label, value, colour in cards:
        with col:
            st.markdown(
                f"<div style='text-align:center; padding:14px 8px; background:#1e2430; "
                f"border-radius:10px; border:1px solid #2d3748;'>"
                f"<div style='color:#64748b; font-size:12px; margin-bottom:4px;'>{label}</div>"
                f"<div style='color:{colour}; font-size:22px; font-weight:700;'>{value}</div>"
                f"</div>",
                unsafe_allow_html=True,
            )

    st.markdown("---")

    # ---------------------------------------------------------------
    # Section 2: Stock Ranking Table
    # ---------------------------------------------------------------
    st.markdown("#### Stock Ranking")

    ranking_rows = []
    for r in sorted(results, key=lambda x: x.get("cum_pnl", 0.0), reverse=True):
        trades = r.get("trades", [])
        scores = [
            e.get("score", 0) for e in trades if e.get("score") is not None
        ]
        avg_sc = round(sum(scores) / len(scores), 1) if scores else 0.0
        peak_sc = round(max(scores), 1) if scores else 0.0

        ranking_rows.append({
            "Symbol": r.get("symbol", "").upper(),
            "Trades": r.get("n_trades", 0),
            "Win Rate%": r.get("win_rate", 0.0),
            "Cum P&L%": round(r.get("cum_pnl", 0.0), 2),
            "Avg Score": avg_sc,
            "Peak Score": peak_sc,
            "Max DD%": round(r.get("max_drawdown", 0.0), 2),
            "SL Exits": len(r.get("sl_exits", [])),
            "Div Exits": len(r.get("div_exits", [])),
            "Score Exits": len(r.get("score_exits", [])),
        })

    df_rank = pd.DataFrame(ranking_rows)

    st.dataframe(
        df_rank,
        use_container_width=True,
        height=min(400, max(120, 35 * len(df_rank) + 40)),
        hide_index=True,
        column_config={
            "Symbol": st.column_config.TextColumn("Symbol", width="medium"),
            "Trades": st.column_config.NumberColumn("Trades", format="%d"),
            "Win Rate%": st.column_config.NumberColumn("Win Rate%", format="%.1f"),
            "Cum P&L%": st.column_config.NumberColumn(
                "Cum P&L%",
                format="%.2f",
            ),
            "Avg Score": st.column_config.NumberColumn("Avg Score", format="%.1f"),
            "Peak Score": st.column_config.NumberColumn("Peak Score", format="%.1f"),
            "Max DD%": st.column_config.NumberColumn("Max DD%", format="%.2f"),
            "SL Exits": st.column_config.NumberColumn("SL Exits", format="%d"),
            "Div Exits": st.column_config.NumberColumn("Div Exits", format="%d"),
            "Score Exits": st.column_config.NumberColumn("Score Exits", format="%d"),
        },
    )

    st.markdown("---")

    # ---------------------------------------------------------------
    # Section 3: Interactive Charts
    # ---------------------------------------------------------------
    st.markdown("#### Charts")
    chart_tab1, chart_tab2, chart_tab3 = st.tabs([
        "P&L by Stock",
        "P&L Distribution",
        "Win Rate vs Avg Score",
    ])

    with chart_tab1:
        df_chart = df_rank.sort_values("Cum P&L%", ascending=True).reset_index(drop=True)
        colors = [
            "#14b8a6" if v >= 0 else "#ef4444" for v in df_chart["Cum P&L%"]
        ]
        fig1 = go.Figure(
            go.Bar(
                y=df_chart["Symbol"],
                x=df_chart["Cum P&L%"],
                orientation="h",
                marker_color=colors,
                text=[f"{v:+.2f}%" for v in df_chart["Cum P&L%"]],
                textposition="outside",
            )
        )
        fig1.update_layout(
            title={"text": "Cumulative P&L by Stock", "x": 0.5},
            xaxis_title="Cumulative P&L (%)",
            yaxis_title="",
            plot_bgcolor="#161b22",
            paper_bgcolor="#0f1117",
            font=dict(color="#e2e8f0"),
            margin=dict(l=80),
            height=max(400, 30 * len(df_chart) + 100),
        )
        fig1.update_xaxes(gridcolor="#2d3748")
        fig1.update_yaxes(gridcolor="#2d3748")
        st.plotly_chart(fig1, use_container_width=True)

    with chart_tab2:
        if all_completed:
            pnl_values = [e["pnl"] for e in all_completed]
            fig2 = go.Figure(
                go.Histogram(
                    x=pnl_values,
                    nbinsx=50,
                    marker_color="#14b8a6",
                    marker_line_color="#0d9488",
                    marker_line_width=1,
                )
            )
            avg_line = float(np.mean(pnl_values))
            fig2.add_vline(
                x=avg_line,
                line_dash="dash",
                line_color="#f59e0b",
                annotation_text=f"Mean: {avg_line:.2f}%",
                annotation_position="top right",
            )
            fig2.update_layout(
                title={"text": "Distribution of Per-Trade P&L", "x": 0.5},
                xaxis_title="P&L (%)",
                yaxis_title="Frequency",
                plot_bgcolor="#161b22",
                paper_bgcolor="#0f1117",
                font=dict(color="#e2e8f0"),
                bargap=0.05,
            )
            fig2.update_xaxes(gridcolor="#2d3748")
            fig2.update_yaxes(gridcolor="#2d3748")
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info("No completed trades to plot.")

    with chart_tab3:
        if len(df_rank) > 0:
            fig3 = go.Figure(
                go.Scatter(
                    x=df_rank["Avg Score"],
                    y=df_rank["Win Rate%"],
                    mode="markers+text",
                    text=df_rank["Symbol"],
                    textposition="top center",
                    textfont=dict(size=9, color="#94a3b8"),
                    marker=dict(
                        size=10,
                        color=df_rank["Cum P&L%"],
                        colorscale=["#ef4444", "#14b8a6"],
                        cmin=float(df_rank["Cum P&L%"].min()),
                        cmax=float(df_rank["Cum P&L%"].max()),
                        line=dict(width=1, color="#2d3748"),
                    ),
                    hovertemplate=(
                        "<b>%{text}</b><br>"
                        "Avg Score: %{x:.1f}<br>"
                        "Win Rate: %{y:.1f}%<br>"
                        "<extra></extra>"
                    ),
                )
            )
            fig3.update_layout(
                title={"text": "Win Rate vs Average Score", "x": 0.5},
                xaxis_title="Average Score",
                yaxis_title="Win Rate (%)",
                plot_bgcolor="#161b22",
                paper_bgcolor="#0f1117",
                font=dict(color="#e2e8f0"),
            )
            fig3.update_xaxes(gridcolor="#2d3748")
            fig3.update_yaxes(gridcolor="#2d3748")
            st.plotly_chart(fig3, use_container_width=True)

    st.markdown("---")

    # ---------------------------------------------------------------
    # Section 4: Stock Drilldown
    # ---------------------------------------------------------------
    st.markdown("#### Stock Drilldown")

    symbol_options = [r.get("symbol", "").upper() for r in results]
    chosen_sym = st.selectbox(
        "Select a stock", options=symbol_options, key="drilldown_sym"
    )

    # Find the result
    chosen_result = None
    for r in results:
        if r.get("symbol", "").upper() == chosen_sym:
            chosen_result = r
            break

    if chosen_result is None:
        st.warning("Stock not found in results.")
    else:
        cr = chosen_result
        comp = cr.get("completed", [])
        entries = cr.get("entries", [])
        trades = cr.get("trades", [])

        # KPI cards — row 1
        kpi_c1, kpi_c2, kpi_c3, kpi_c4 = st.columns(4)
        kpis = [
            (kpi_c1, "Entries", len(entries), None),
            (kpi_c2, "Completed Exits", len(comp), None),
            (kpi_c3, "Win Rate", f"{cr.get('win_rate', 0)}%", cr.get("win_rate", 0)),
            (
                kpi_c4,
                "Cumulative P&L",
                f"{round(cr.get('cum_pnl', 0), 2)}%",
                cr.get("cum_pnl", 0),
            ),
        ]
        for col, label, value, num_val in kpis:
            with col:
                colour = "#e2e8f0"
                if num_val is not None and isinstance(num_val, (int, float)):
                    colour = _pnl_colour(float(num_val))
                st.markdown(
                    f"<div style='text-align:center; padding:12px; background:#1e2430; "
                    f"border-radius:8px; border:1px solid #2d3748;'>"
                    f"<div style='color:#64748b; font-size:12px;'>{label}</div>"
                    f"<div style='color:{colour}; font-size:20px; font-weight:700;'>{value}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

        # KPI cards — row 2
        kpi_c5, kpi_c6, kpi_c7, kpi_c8 = st.columns(4)
        scores_all = [
            e.get("score", 0) for e in trades if e.get("score") is not None
        ]
        avg_sc = round(sum(scores_all) / len(scores_all), 2) if scores_all else 0.0
        peak_sc = round(max(scores_all), 2) if scores_all else 0.0
        kpis2 = [
            (
                kpi_c5,
                "Avg P&L/Trade",
                f"{round(cr.get('avg_pnl_per_trade', 0), 2)}%",
                cr.get("avg_pnl_per_trade", 0),
            ),
            (
                kpi_c6,
                "Max Drawdown",
                f"{round(cr.get('max_drawdown', 0), 2)}%",
                cr.get("max_drawdown", 0),
            ),
            (kpi_c7, "Avg Score", avg_sc, None),
            (kpi_c8, "Peak Score", peak_sc, None),
        ]
        for col, label, value, num_val in kpis2:
            with col:
                colour = "#e2e8f0"
                if num_val is not None and isinstance(num_val, (int, float)):
                    colour = _pnl_colour(float(num_val))
                st.markdown(
                    f"<div style='text-align:center; padding:12px; background:#1e2430; "
                    f"border-radius:8px; border:1px solid #2d3748;'>"
                    f"<div style='color:#64748b; font-size:12px;'>{label}</div>"
                    f"<div style='color:{colour}; font-size:20px; font-weight:700;'>{value}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

        # Trade log expander
        with st.expander("Trade Log", expanded=True):
            if trades:
                trade_rows = []
                for e in trades:
                    pnl = e.get("pnl")
                    trade_rows.append({
                        "Date": str(e.get("date", "")),
                        "Type": e.get("type", ""),
                        "Close": round(e.get("close", 0), 2),
                        "Score": e.get("score", ""),
                        "Pool A": e.get("pool_a", ""),
                        "Pool B": e.get("pool_b", ""),
                        "Pool C": e.get("pool_c", ""),
                        "Bonus": e.get("bonus", ""),
                        "Entry Price": (
                            round(e.get("entry_price", 0), 2)
                            if e.get("entry_price")
                            else ""
                        ),
                        "P&L%": round(pnl, 2) if pnl is not None else "",
                        "Exit Reason": e.get("exit_reason", ""),
                        "Bars from Trough": e.get("bars_from_trough", ""),
                    })
                df_trades = pd.DataFrame(trade_rows)
                st.dataframe(df_trades, use_container_width=True, hide_index=True)
            else:
                st.info("No trade events for this stock.")

        # Exit breakdown expander
        sl_ex = cr.get("sl_exits", [])
        div_ex = cr.get("div_exits", [])
        score_ex = cr.get("score_exits", [])
        period_ex = cr.get("period_end_exits", [])
        with st.expander("Exit Type Breakdown", expanded=False):
            eb_rows = []
            for label, group in [
                ("SL Exit", sl_ex),
                ("Divergence Exit", div_ex),
                ("Score Exit", score_ex),
                ("Period-End Exit", period_ex),
            ]:
                cnt = len(group)
                avg_p = (
                    round(sum(e["pnl"] for e in group) / cnt, 2)
                    if cnt > 0
                    else 0.0
                )
                eb_rows.append({
                    "Exit Type": label,
                    "Count": cnt,
                    "Avg P&L%": avg_p,
                })
            st.dataframe(
                pd.DataFrame(eb_rows), use_container_width=True, hide_index=True
            )

        # Equity curve expander
        with st.expander("Equity Curve", expanded=True):
            if comp:
                dates = [str(e.get("date", "")) for e in comp]
                pnl_list = [e.get("pnl", 0) for e in comp]
                cum_pnl = list(np.cumsum(pnl_list))

                fig_eq = go.Figure()
                fig_eq.add_trace(
                    go.Scatter(
                        x=dates,
                        y=cum_pnl,
                        mode="lines+markers",
                        name="Cumulative P&L",
                        line=dict(color="#14b8a6", width=2),
                        marker=dict(size=5),
                        fill="tozeroy",
                        fillcolor="rgba(20, 184, 166, 0.1)",
                    )
                )
                fig_eq.add_hline(
                    y=0,
                    line_dash="dash",
                    line_color="#475569",
                )
                fig_eq.update_layout(
                    title={"text": f"Equity Curve — {chosen_sym}", "x": 0.5},
                    xaxis_title="Date",
                    yaxis_title="Cumulative P&L (%)",
                    plot_bgcolor="#161b22",
                    paper_bgcolor="#0f1117",
                    font=dict(color="#e2e8f0"),
                )
                fig_eq.update_xaxes(gridcolor="#2d3748")
                fig_eq.update_yaxes(gridcolor="#2d3748")
                st.plotly_chart(fig_eq, use_container_width=True)
            else:
                st.info("No completed exits to plot equity curve.")

    st.markdown("---")

    # ---------------------------------------------------------------
    # Section 5: Export
    # ---------------------------------------------------------------
    st.markdown("#### Export")

    col_exp1, col_exp2 = st.columns(2)
    with col_exp1:
        output_name = (
            f"apollo_report_{st.session_state.start_date}"
            f"_{st.session_state.end_date}.xlsx"
        )
        xlsx_bytes = _generate_xlsx_bytes(results)
        if xlsx_bytes:
            st.download_button(
                "📄 Export XLSX Report",
                data=xlsx_bytes,
                file_name=output_name,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )
    with col_exp2:
        # Export results as JSON
        export_results = []
        for r in results:
            d = {k: v for k, v in r.items()
                 if k not in ("daily_df", "trades", "entries",
                              "completed", "sl_exits", "div_exits",
                              "score_exits", "period_end_exits")}
            d["n_entries"] = len(r.get("entries", []))
            d["n_completed"] = len(r.get("completed", []))
            d["n_sl"] = len(r.get("sl_exits", []))
            d["n_div"] = len(r.get("div_exits", []))
            d["n_score"] = len(r.get("score_exits", []))
            d["n_period"] = len(r.get("period_end_exits", []))
            export_results.append(d)
        json_bytes = json.dumps(
            export_results, indent=2, default=str
        ).encode("utf-8")
        json_name = (
            f"apollo_results_{st.session_state.start_date}"
            f"_{st.session_state.end_date}.json"
        )
        st.download_button(
            "📃 Export Results (JSON)",
            data=json_bytes,
            file_name=json_name,
            mime="application/json",
            use_container_width=True,
        )

    # Failed stocks reminder
    if st.session_state.failed_stocks:
        with st.expander(f"⚠ Failed Stocks ({len(st.session_state.failed_stocks)})"):
            for fs in st.session_state.failed_stocks:
                st.markdown(f"- **{fs['symbol']}**: `{fs['error']}`")


# =====================================================================
# TAB 5 — HISTORY (NEW)
# =====================================================================
with tab_history:
    st.markdown("#### 📂 Backtest History")
    
    # Initialize history DB connection
    if st.session_state.history_db is None:
        st.session_state.history_db = BacktestHistory()
    
    hist = st.session_state.history_db
    
    # Get stats
    db_stats = hist.get_stats()
    
    # Stats bar
    st.markdown(
        f"<div style='display:flex; gap:16px; flex-wrap:wrap; margin-bottom:20px;'>"
        f"<div style='padding:12px 18px; background:#1e2430; border-radius:8px; border-left:3px solid #14b8a6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Total Runs</span><br>"
        f"<b style='color:#e2e8f0; font-size:20px;'>{db_stats['total_runs']}</b>"
        f"</div>"
        f"<div style='padding:12px 18px; background:#1e2430; border-radius:8px; border-left:3px solid #f59e0b;'>"
        f"<span style='color:#64748b; font-size:12px;'>DB Size</span><br>"
        f"<b style='color:#e2e8f0; font-size:20px;'>{db_stats['db_size_mb']} MB</b>"
        f"</div>"
        f"<div style='padding:12px 18px; background:#1e2430; border-radius:8px; border-left:3px solid #8b5cf6;'>"
        f"<span style='color:#64748b; font-size:12px;'>Last Run</span><br>"
        f"<b style='color:#e2e8f0; font-size:14px;'>{db_stats['latest_run'][:16] if db_stats['latest_run'] != 'Never' else 'Never'}</b>"
        f"</div>"
        f"</div>",
        unsafe_allow_html=True,
    )
    
    # Fetch all runs
    all_runs = hist.get_all_runs(limit=100)
    
    if not all_runs:
        st.info(
            "No saved backtest runs yet. "
            "Run a backtest from the **Run** tab — it will be **auto-saved** here!"
        )
        st.stop()
    
    # ================================================================
    # RUN SELECTION TABLE
    # ================================================================
    st.markdown("##### Saved Runs")
    
    # Prepare display data
    run_display = []
    for run in all_runs:
        run_display.append({
            "ID": run["run_id"],
            "Name": run["run_name"],
            "Date": run["created_at"][:16].replace("T", " "),
            "⭐": "⭐" if run["is_bookmarked"] else "☆",
            "Stocks": run["total_stocks"],
            "Trades": run["total_trades"],
            "Win Rate": f"{run['win_rate']:.1f}%",
            "Cum P&L": f"{run['total_cumulative_pnl']:+.2f}%",
            "Avg P&L": f"{run['avg_pnl_per_trade']:+.2f}%",
            "Params": f"ET:{run['entry_threshold']} EX:{run['exit_threshold']} {run['exit_mode']}",
            "Duration": f"{run['duration_seconds']:.1f}s",
        })
    
    df_runs = pd.DataFrame(run_display)
    
    # Display with selection
    selected_run_ids = st.multiselect(
        "Select runs to compare (or view details below)",
        options=[r["run_id"] for r in all_runs],
        format_func=lambda x: f"#{x} — {next((r['run_name'] for r in all_runs if r['run_id']==x), '')}",
        default=[],
        key="history_run_select",
    )
    
    st.dataframe(
        df_runs,
        use_container_width=True,
        height=min(350, max(120, 35 * len(df_runs) + 40)),
        hide_index=True,
        column_config={
            "ID": st.column_config.NumberColumn("ID", width="small"),
            "Name": st.column_config.TextColumn("Run Name", width="medium"),
            "Date": st.column_config.TextColumn("Timestamp", width="medium"),
            "⭐": st.column_config.TextColumn("", width="small"),
            "Stocks": st.column_config.NumberColumn("Stocks", format="%d"),
            "Trades": st.column_config.NumberColumn("Trades", format="%d"),
            "Win Rate": st.column_config.TextColumn("Win Rate"),
            "Cum P&L": st.column_config.TextColumn("Cum P&L"),
            "Avg P&L": st.column_config.TextColumn("Avg P&L"),
            "Params": st.column_config.TextColumn("Parameters", width="medium"),
            "Duration": st.column_config.TextColumn("Dur.", width="small"),
        },
    )
    
    # ================================================================
    # ACTION BUTTONS
    # ================================================================
    st.markdown("---")
    col_actions1, col_actions2, col_actions3, col_actions4 = st.columns(4)
    
    with col_actions1:
        if st.button("🗑️ Delete Selected", disabled=len(selected_run_ids) == 0):
            n_deleted = hist.delete_multiple_runs(selected_run_ids)
            st.success(f"Deleted {n_deleted} run(s).")
            st.rerun()
    
    with col_actions2:
        if st.button("🧹 Cleanup Old Runs (Keep Latest 20)"):
            n_deleted = hist.delete_old_runs(keep_latest=20)
            if n_deleted > 0:
                st.success(f"Cleaned up {n_deleted} old run(s).")
            else:
                st.info("No old runs to clean up.")
            st.rerun()
    
    with col_actions3:
        # Export selected runs as JSON
        if selected_run_ids:
            export_data = []
            for rid in selected_run_ids:
                export_data.append(hist.export_run_to_dict(rid))
            export_json = json.dumps(export_data, indent=2, default=str).encode("utf-8")
            st.download_button(
                "📥 Export Selected (JSON)",
                data=export_json,
                file_name=f"apollo_history_{len(selected_run_ids)}runs.json",
                mime="application/json",
                use_container_width=True,
            )
        else:
            st.button("📥 Export Selected (JSON)", disabled=True)
    
    with col_actions4:
        # Bookmark toggle
        if len(selected_run_ids) == 1:
            is_bookmarked = next(
                (r["is_bookmarked"] for r in all_runs if r["run_id"] == selected_run_ids[0]),
                False,
            )
            btn_label = "⭐ Unbookmark" if is_bookmarked else "☆ Bookmark"
            if st.button(btn_label):
                hist.toggle_bookmark(selected_run_ids[0])
                st.rerun()
        elif len(selected_run_ids) > 1:
            st.button("⭐ Bookmark (select 1)", disabled=True)
        else:
            st.button("⭐ Bookmark (select 1)", disabled=True)
    
    # ================================================================
    # DETAILED VIEW OF SELECTED RUN(S)
    # ================================================================
    if selected_run_ids:
        st.markdown("---")
        st.markdown("##### 📋 Detailed View")
        
        if len(selected_run_ids) == 1:
            # Single run detail view
            _render_single_run_detail(hist, selected_run_ids[0], all_runs)
        else:
            # Multi-run comparison view
            _render_comparison_view(hist, selected_run_ids)


def _render_single_run_detail(hist: BacktestHistory, run_id: int, all_runs: list[dict]):
    """Render detailed view of a single saved run."""
    run = hist.get_run(run_id)
    if not run:
        st.error(f"Run {run_id} not found.")
        return
    
    # Header with bookmark and notes
    col_hdr1, col_hdr2 = st.columns([4, 1])
    with col_hdr1:
        st.markdown(
            f"<h3 style='margin:0;'>📊 Run #{run_id}: {run['run_name']}</h3>",
            unsafe_allow_html=True,
        )
    with col_hdr2:
        if st.button("🗑️ Delete This Run", key=f"del_{run_id}"):
            hist.delete_run(run_id)
            st.rerun()
    
    # Parameter summary
    with st.expander("⚙️ Parameters Used", expanded=False):
        st.json({
            "Date Range": f"{run['start_date']} → {run['end_date']}",
            "Entry Threshold": run["entry_threshold"],
            "Exit Threshold": run["exit_threshold"],
            "Exit Mode": run["exit_mode"],
            "Stop Loss %": run["sl_percent"],
            "Divergence RSI Drop": run["divergence_rsi_drop"],
            "Cooldown Days": run["divergence_cooldown"],
        })
    
    # Notes editor
    new_notes = st.text_area(
        "📝 Notes (for your reference)",
        value=run.get("notes", ""),
        key=f"notes_{run_id}",
        height=80,
    )
    if new_notes != run.get("notes", ""):
        hist.update_notes(run_id, new_notes)
    
    # Aggregate metrics cards
    st.markdown("###### Portfolio Metrics")
    mc1, mc2, mc3, mc4, mc5, mc6 = st.columns(6)
    cards = [
        (mc1, "Total Stocks", run["total_stocks"]),
        (mc2, "Total Trades", run["total_trades"]),
        (mc3, "Win Rate", f"{run['win_rate']:.1f}%"),
        (mc4, "Cum P&L", f"{run['total_cumulative_pnl']:+.2f}%"),
        (mc5, "Avg P&L/Trade", f"{run['avg_pnl_per_trade']:+.2f}%"),
        (mc6, "Worst Max DD", f"{run['worst_max_drawdown']:.2f}%"),
    ]
    for col, label, value in cards:
        with col:
            colour = "#14b8a6" if isinstance(value, str) and "+" in value else (
                "#ef4444" if isinstance(value, str) and "-" in value else "#e2e8f0"
            )
            st.markdown(
                f"<div style='text-align:center; padding:12px 8px; "
                f"background:#1e2430; border-radius:8px; border:1px solid #2d3748;'>"
                f"<div style='color:#64748b; font-size:11px;'>{label}</div>"
                f"<div style='color:{colour}; font-size:18px; font-weight:700;'>{value}</div>"
                f"</div>",
                unsafe_allow_html=True,
            )
    
    # Stock ranking from this run
    st.markdown("###### Stock Results")
    stocks = hist.get_stock_results(run_id)
    
    if stocks:
        df_stocks = pd.DataFrame(stocks)
        # Rename columns for display
        df_display = df_stocks.rename(columns={
            "symbol": "Symbol",
            "n_trades": "Trades",
            "n_completed": "Exits",
            "win_rate": "Win Rate %",
            "cum_pnl": "Cum P&L %",
            "avg_pnl_per_trade": "Avg P&L",
            "max_drawdown": "Max DD %",
            "avg_score": "Avg Score",
            "peak_score": "Peak Score",
        })[["Symbol", "Trades", "Exits", "Win Rate %", "Cum P&L %", 
           "Avg P&L", "Max DD %", "Avg Score"]]
        
        st.dataframe(df_display, use_container_width=True, hide_index=True)
        
        # Stock selector for drill-down
        st.markdown("###### Trade Log Drilldown")
        stock_options = [s["symbol"].upper() for s in stocks]
        chosen_stock = st.selectbox(
            "Select stock to view trade log",
            options=stock_options,
            key=f"hist_drill_{run_id}",
        )
        
        # Fetch trade events for this stock
        trades = hist.get_trade_events(run_id, symbol=chosen_stock)
        
        if trades:
            df_trades = pd.DataFrame(trades)[
                ["date", "event_type", "close_price", "score", 
                 "classification", "entry_price", "pnl_percentage", 
                 "exit_reason"]
            ].rename(columns={
                "date": "Date",
                "event_type": "Type",
                "close_price": "Close",
                "score": "Score",
                "classification": "Classification",
                "entry_price": "Entry Price",
                "pnl_percentage": "P&L %",
                "exit_reason": "Exit Reason",
            })
            st.dataframe(df_trades, use_container_width=True, hide_index=True, height=400)
        else:
            st.info(f"No trade events found for {chosen_stock}")
    else:
        st.info("No stock results for this run.")


def _render_comparison_view(hist: BacktestHistory, run_ids: list[int]):
    """Render side-by-side comparison of multiple runs."""
    comparisons = hist.get_run_comparison(run_ids)
    
    if not comparisons:
        st.error("Could not load comparison data.")
        return
    
    st.markdown(f"Comparing **{len(comparisons)}** runs:")
    
    # Comparison table
    comp_rows = []
    for c in comparisons:
        comp_rows.append({
            "Run ID": c["run_id"],
            "Name": c["run_name"][:16],
            "Date": c["created_at"][:10],
            "Entry Thresh": c["entry_threshold"],
            "Exit Thresh": c["exit_threshold"],
            "Mode": c["exit_mode"],
            "SL %": c["sl_percent"],
            "Stocks": c["total_stocks"],
            "Trades": c["total_trades"],
            "Win Rate": f"{c['win_rate']:.1f}%",
            "Cum P&L": f"{c['total_cumulative_pnl']:+.2f}%",
            "Avg P&L": f"{c['avg_pnl_per_trade']:+.2f}%",
            "Max DD": f"{c['worst_max_drawdown']:.2f}%",
            "Duration": f"{c['duration_seconds']:.1f}s",
        })
    
    df_comp = pd.DataFrame(comp_rows)
    st.dataframe(df_comp, use_container_width=True, hide_index=True)
    
    # Visual comparison chart
    if len(comparisons) >= 2:
        fig = go.Figure()
        
        run_names = [c["run_name"][:12] for c in comparisons]
        cum_pnls = [c["total_cumulative_pnl"] for c in comparisons]
        
        colors = ["#14b8a6" if v >= 0 else "#ef4444" for v in cum_pnls]
        
        fig.add_trace(go.Bar(
            x=run_names,
            y=cum_pnls,
            name="Cumulative P&L %",
            marker_color=colors,
            text=[f"{v:+.1f}%" for v in cum_pnls],
            textposition="outside",
        ))
        
        fig.update_layout(
            title={"text": "P&L Comparison Across Runs", "x": 0.5},
            yaxis_title="Cumulative P&L (%)",
            plot_bgcolor="#161b22",
            paper_bgcolor="#0f1117",
            font=dict(color="#e2e8f0"),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True)


# =====================================================================
# XLSX generation helper (in-memory)
# =====================================================================

def _generate_xlsx_bytes(results: list[dict]) -> bytes | None:
    """Generate XLSX report in memory and return bytes for download."""
    import tempfile

    try:
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as tmp:
            tmp_path = tmp.name

        path = generate_report(
            results=results,
            start_date=str(st.session_state.start_date),
            end_date=str(st.session_state.end_date),
            exit_mode=st.session_state.exit_mode,
            sl_percent=st.session_state.sl_percent,
            entry_threshold=st.session_state.entry_threshold,
            exit_threshold=st.session_state.exit_threshold,
            output_path=tmp_path,
            data_source="eod2",
        )
        with open(path, "rb") as f:
            data = f.read()
        Path(tmp_path).unlink(missing_ok=True)
        return data
    except Exception as exc:
        st.error(f"Failed to generate XLSX: {exc}")
        return None
