"""Apollo Engine Constants — Signal definitions, pool metadata, thresholds."""

ENTRY_THRESHOLD = 70
EXIT_THRESHOLD = 50
DIVERGENCE_RSI_DROP = 3.0
DIVERGENCE_COOLDOWN = 5

SIGNAL_DEFS = [
    # Pool A — RSI Recovery (42 pts)
    ("A1", "Trough Detected (D)", "A", 10),
    ("A2", "Trough Detected (4H)", "A", 8),
    ("A3", "Recovery Momentum (D)", "A", 8),
    ("A4", "Recovery Momentum (4H)", "A", 6),
    ("A5", "RSI21 > 50 (4H)", "A", 6),
    ("A6", "Multi-Speed Alignment (D)", "A", 4),
    # Pool B — Price Structure (30 pts)
    ("B1", "Close > TP28 (4H)", "B", 7),
    ("B2", "Close > WC50 (4H)", "B", 6),
    ("B3", "Approaching D-TP28 (D)", "B", 5),
    ("B4", "Higher Low Forming (D)", "B", 4),
    ("B5", "Price > Trough+10% (D)", "B", 3),
    ("B6", "WC21 Proximity (4H)", "B", 5),
    # Pool C — Multi-TF Confirmation (18 pts)
    ("C1", "Cross-TF Trough Agree", "C", 6),
    ("C2", "4H RSI36 > 45", "C", 4),
    ("C3", "W-RSI56 > 50 (prev W)", "C", 4),
    ("C4", "D-RSI21 > 45", "C", 4),
    # Bonus A — Volume/Support (8 pts)
    ("BA1", "Selling Exhaustion", "BA", 3),
    ("BA2", "Price > Trough+10%", "BA", 3),
    ("BA3", "4H Volume Expansion", "BA", 2),
    # Bonus B — Uptrend Context (10 pts)
    ("BB1", "52W High > Curr*1.5", "BB", 3),
    ("BB2", "Multi-Touch Support", "BB", 4),
    ("BB3", "Weekly RSI Reversal", "BB", 3),
    # Bonus C — Trend Momentum (5 pts)
    ("BC1", "ADX > -DI (D)", "BC", 2.5),
    ("BC2", "MACD > 0 (D)", "BC", 2.5),
]

POOL_MAX = {"A": 42, "B": 30, "C": 18, "BA": 8, "BB": 10, "BC": 5}
POOL_ORDER = ["A", "B", "C", "BA", "BB", "BC"]
POOL_NAMES = {
    "A": "Pool A (RSI Recovery)",
    "B": "Pool B (Price Structure)",
    "C": "Pool C (Multi-TF Confirm)",
    "BA": "Bonus A (Volume/Support)",
    "BB": "Bonus B (Uptrend Context)",
    "BC": "Bonus C (Trend Momentum)",
}
POOL_DESC = {
    "A": "Trough Detection, Recovery Momentum, Cross-TF RSI Alignment",
    "B": "TP28 Conv, WC50 Conv, Price Prox TP28, Higher Low, Price vs Trough, WC21 Proximity",
    "C": "Cross-TF Trough Agree, 4H RSI36>45, W-RSI56>50, D-RSI21>45",
    "BA": "Selling Exhaustion, Price>Trough+10%, 4H Volume Expansion",
    "BB": "52W High, Multi-Touch Support, Weekly RSI Reversal",
    "BC": "ADX Directional, MACD Bullish",
}