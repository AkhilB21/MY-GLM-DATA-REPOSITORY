"""Apollo Backtest Engine — self-contained scoring + trade extraction.

All signal evaluation, scoring, classification, and trade extraction logic
lives here.  Imports only from sibling modules (.constants, .indicators).
No references to any v2/v3/v4/v5 runner files.

Functions
---------
    _graded                  — linear interpolation in buffer zone
    eval_signals             — evaluate all 21 signals at one daily bar
    classify_score           — map total score → (action, position_pct)
    detect_troughs           — boolean series of RSI troughs
    get_latest_trough_pos    — most recent trough on or before index
    compute_weekly_rsi       — Wilder RSI on weekly close
    run_backtest             — main scoring loop → (daily_df, trades)
    extract_trades           — trade extraction with selectable exit mode
    run_stock_backtest       — high-level: load → score → extract → KPIs
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .constants import (
    ENTRY_THRESHOLD,
    EXIT_THRESHOLD,
    DIVERGENCE_RSI_DROP,
    DIVERGENCE_COOLDOWN,
    SIGNAL_DEFS,
    POOL_ORDER,
    POOL_MAX,
    POOL_NAMES,
    POOL_DESC,
)
from .indicators import compute_all_indicators


# =========================================================================
# Helpers
# =========================================================================

def _graded(value: float, max_pts: float, buf_lo: float, buf_hi: float) -> float:
    """Linear interpolation in buffer zone.

    Returns *max_pts* when ``value >= buf_hi``, 0.0 when ``value <= buf_lo``,
    and a linear ramp in between.  NaN → 0.0.
    """
    if np.isnan(value):
        return 0.0
    if value >= buf_hi:
        return float(max_pts)
    if value <= buf_lo:
        return 0.0
    ratio = (value - buf_lo) / (buf_hi - buf_lo)
    return round(max_pts * ratio, 2)


def classify_score(score: float) -> tuple[str, str]:
    """Map total score to (action_label, position_pct_string)."""
    if score >= 90:
        return "FULL STRONG", "100%"
    elif score >= 80:
        return "FULL ENTRY", "100%"
    elif score >= 70:
        return "STANDARD", "60-70%"
    elif score >= 50:
        return "WATCHLIST", "0%"
    else:
        return "DO NOT ENTER", "0%"


def detect_troughs(rsi: pd.Series, threshold: float, window: int) -> pd.Series:
    """Detect RSI troughs: RSI <= threshold AND local minimum in centered window."""
    rolling_min = rsi.rolling(window=window, center=True, min_periods=window).min()
    is_trough = (rsi <= threshold) & (rsi == rolling_min)
    return is_trough.fillna(False)


def get_latest_trough_pos(trough_series: pd.Series, idx: int) -> int | None:
    """Return the integer position of the most recent trough on or before *idx*."""
    mask = trough_series.iloc[: idx + 1]
    positions = np.where(mask.values)[0]
    if len(positions) == 0:
        return None
    return int(positions[-1])


def compute_weekly_rsi(df_weekly: pd.DataFrame, period: int) -> pd.Series:
    """Wilder-smoothed RSI on weekly close prices."""
    close = df_weekly["close"]
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = (-delta).where(delta < 0, 0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi


# =========================================================================
# Signal evaluation (all 21 signals)
# =========================================================================

def eval_signals(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    df_w: pd.DataFrame,
    d_idx: int,
    h_idx: int,
    w_idx: int,
    d_trough_pos: int | None,
    h_trough_pos: int | None,
    d_rsi21: pd.Series,
    d_rsi36: pd.Series,
    h_rsi21: pd.Series,
    h_rsi36: pd.Series,
    w_rsi21: pd.Series,
    w_rsi56: pd.Series,
    plus_di: pd.Series,
    minus_di: pd.Series,
    macd_line: pd.Series,
    crossover_price: float | None,
) -> dict:
    """Evaluate all 21 signals at a single daily bar.

    Returns
    -------
    dict  mapping signal_id → (pts: float, fired: bool)
    """
    results: dict[str, tuple[float, bool]] = {}

    close_d = df_d["close"].iloc[d_idx]

    # ------------------------------------------------------------------ Pool A
    # A1: Trough Detected (D) — 10 pts
    results["A1"] = (10.0, True) if d_trough_pos is not None else (0.0, False)

    # A2: Trough Detected (4H) — 8 pts
    results["A2"] = (8.0, True) if h_trough_pos is not None else (0.0, False)

    # A3: Recovery Momentum (D) — 8 pts
    a3_pts, a3_fired = 0.0, False
    if d_trough_pos is not None:
        bars = d_idx - d_trough_pos
        if 0 < bars <= 10:
            gain = d_rsi21.iloc[d_idx] - d_rsi21.iloc[d_trough_pos]
            if gain >= 8.0:
                a3_pts, a3_fired = 8.0, True
    results["A3"] = (a3_pts, a3_fired)

    # A4: Recovery Momentum (4H) — 6 pts
    a4_pts, a4_fired = 0.0, False
    if h_trough_pos is not None:
        bars = h_idx - h_trough_pos
        if 0 < bars <= 12:
            gain = h_rsi21.iloc[h_idx] - h_rsi21.iloc[h_trough_pos]
            if gain >= 10.0:
                a4_pts, a4_fired = 6.0, True
    results["A4"] = (a4_pts, a4_fired)

    # A5: RSI21 > 50 (4H) — 6 pts graded
    val = h_rsi21.iloc[h_idx]
    results["A5"] = (_graded(val, 6.0, 45.0, 55.0), not np.isnan(val) and val > 45.0)

    # A6: Multi-Speed Alignment (D) — 4 pts graded
    v21 = d_rsi21.iloc[d_idx]
    v36 = d_rsi36.iloc[d_idx]
    spread = v21 - v36
    results["A6"] = (
        _graded(spread, 4.0, -2.0, 2.0),
        spread > -2.0 if not np.isnan(spread) else False,
    )

    # ------------------------------------------------------------------ Pool B
    close_4h = df_4h["close"].iloc[h_idx]

    # B1: Close > TP28 (4H) — 7 pts graded
    tp_4h = df_4h["tp28"].iloc[h_idx]
    if not np.isnan(tp_4h):
        pct_b1 = (close_4h - tp_4h) / tp_4h * 100.0
        results["B1"] = (_graded(pct_b1, 7.0, -2.0, 1.0), pct_b1 > -2.0)
    else:
        results["B1"] = (0.0, False)

    # B2: Close > WC50 (4H) — 6 pts graded
    wc_4h = df_4h["wc50"].iloc[h_idx]
    if not np.isnan(wc_4h):
        pct_b2 = (close_4h - wc_4h) / wc_4h * 100.0
        results["B2"] = (_graded(pct_b2, 6.0, -2.0, 1.0), pct_b2 > -2.0)
    else:
        results["B2"] = (0.0, False)

    # B3: Approaching D-TP28 (D) — 5 pts (0.97× to 1.02× zone)
    tp_d = df_d["tp28"].iloc[d_idx]
    if not np.isnan(tp_d):
        if tp_d * 0.97 <= close_d <= tp_d * 1.02:
            results["B3"] = (5.0, True)
        else:
            results["B3"] = (0.0, False)
    else:
        results["B3"] = (0.0, False)

    # B4: Higher Low Forming (D) — 4 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        current_low = df_d["low"].iloc[d_idx]
        b4_fired = current_low > trough_low
        results["B4"] = (4.0 if b4_fired else 0.0, b4_fired)
    else:
        results["B4"] = (0.0, False)

    # B5: Price > Trough + 10% (D) — 3 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        b5_fired = close_d > trough_low * 1.10
        results["B5"] = (3.0 if b5_fired else 0.0, b5_fired)
    else:
        results["B5"] = (0.0, False)

    # B6: WC21 Proximity (4H) — 5 pts graded
    wc21_val = df_4h["wc21"].iloc[h_idx] if "wc21" in df_4h.columns else np.nan
    if not np.isnan(wc21_val) and close_4h > wc21_val and crossover_price is not None:
        pct_gain = (close_4h - crossover_price) / crossover_price * 100.0
        if 0 < pct_gain <= 5.0:
            pts_b6 = round(min(pct_gain, 5.0), 2)
            results["B6"] = (pts_b6, True)
        else:
            results["B6"] = (0.0, False)
    else:
        results["B6"] = (0.0, False)

    # ------------------------------------------------------------------ Pool C
    # C1: Cross-TF Trough Agree — 6 pts
    if d_trough_pos is not None and h_trough_pos is not None:
        d_trough_date = df_d.index[d_trough_pos]
        h_trough_date = df_4h.index[h_trough_pos]
        d_td = pd.Timestamp(d_trough_date).date()
        h_td = pd.Timestamp(h_trough_date).date()
        earlier = min(d_td, h_td)
        later = max(d_td, h_td)
        mask_c = (df_d.index.date > earlier) & (df_d.index.date < later)
        bars_between = int(mask_c.sum())
        c1_fired = bars_between <= 3
        results["C1"] = (6.0 if c1_fired else 0.0, c1_fired)
    else:
        results["C1"] = (0.0, False)

    # C2: 4H RSI36 > 45 — 4 pts graded
    val_c2 = h_rsi36.iloc[h_idx]
    results["C2"] = (_graded(val_c2, 4.0, 40.0, 50.0), not np.isnan(val_c2) and val_c2 > 40.0)

    # C3: W-RSI56 > 50 (prev W) — 4 pts
    if w_idx >= 1:
        prev_rsi56 = w_rsi56.iloc[w_idx - 1]
        c3_fired = not np.isnan(prev_rsi56) and prev_rsi56 > 50.0
        results["C3"] = (4.0 if c3_fired else 0.0, c3_fired)
    else:
        results["C3"] = (0.0, False)

    # C4: D-RSI21 > 45 — 4 pts graded
    val_c4 = d_rsi21.iloc[d_idx]
    results["C4"] = (_graded(val_c4, 4.0, 40.0, 50.0), not np.isnan(val_c4) and val_c4 > 40.0)

    # ---------------------------------------------------------------- Bonus A
    # BA1: Selling Exhaustion — disabled in v6 reproduction
    results["BA1"] = (0.0, False)

    # BA2: Price > Trough + 10% — 3 pts
    if d_trough_pos is not None:
        trough_low = df_d["low"].iloc[d_trough_pos]
        ba2_fired = close_d > trough_low * 1.10
        results["BA2"] = (3.0 if ba2_fired else 0.0, ba2_fired)
    else:
        results["BA2"] = (0.0, False)

    # BA3: 4H Volume Expansion — 2 pts
    ba3_pts, ba3_fired = 0.0, False
    if h_idx >= 20:
        avg_20 = df_4h["volume"].iloc[h_idx - 20 : h_idx].mean()
        if not np.isnan(avg_20) and avg_20 > 0:
            start = max(0, h_idx - 18)
            for v in df_4h["volume"].iloc[start : h_idx + 1]:
                if not np.isnan(v) and v > avg_20 * 1.5:
                    ba3_pts, ba3_fired = 2.0, True
                    break
    results["BA3"] = (ba3_pts, ba3_fired)

    # ---------------------------------------------------------------- Bonus B
    # BB1: 52W High > Current * 1.5 — 3 pts
    lookback = min(252, d_idx)
    if lookback >= 20:
        high_52w = df_d["high"].iloc[d_idx - lookback : d_idx + 1].max()
        bb1_fired = high_52w > close_d * 1.5
        results["BB1"] = (3.0 if bb1_fired else 0.0, bb1_fired)
    else:
        results["BB1"] = (0.0, False)

    # BB2: Multi-Touch Support — 4 pts
    bb2_pts, bb2_fired = 0.0, False
    lookback_bb2 = min(252, d_idx)
    if lookback_bb2 >= 30:
        window = df_d.iloc[d_idx - lookback_bb2 : d_idx + 1]
        lows = window["low"]
        rolling_min = lows.rolling(window=21, center=True, min_periods=21).min()
        trough_mask = lows == rolling_min
        trough_lows = lows[trough_mask].dropna()
        if len(trough_lows) >= 2:
            support_low = trough_lows.min()
            support_high = support_low + (trough_lows.max() - trough_lows.min()) * 0.3
            touches = lows[(lows >= support_low) & (lows <= support_high)]
            if len(touches) >= 2:
                bb2_pts, bb2_fired = 4.0, True
    results["BB2"] = (bb2_pts, bb2_fired)

    # BB3: Weekly RSI Reversal — 3 pts
    bb3_pts, bb3_fired = 0.0, False
    if w_idx >= 5:
        cur_rsi21 = w_rsi21.iloc[w_idx]
        cur_rsi56 = w_rsi56.iloc[w_idx]
        if not np.isnan(cur_rsi21) and not np.isnan(cur_rsi56):
            past_21 = w_rsi21.iloc[max(0, w_idx - 12) : w_idx]
            past_56 = w_rsi56.iloc[max(0, w_idx - 12) : w_idx]
            was_below = any(
                not np.isnan(p21) and not np.isnan(p56) and p21 < p56
                for p21, p56 in zip(past_21, past_56)
            )
            if was_below and cur_rsi21 > cur_rsi56:
                bb3_pts, bb3_fired = 3.0, True
    results["BB3"] = (bb3_pts, bb3_fired)

    # ---------------------------------------------------------------- Bonus C (binary)
    # BC1: ADX > -DI (Daily) — 2.5 pts
    pdi = plus_di.iloc[d_idx]
    mdi = minus_di.iloc[d_idx]
    bc1_fired = not np.isnan(pdi) and not np.isnan(mdi) and pdi > mdi
    results["BC1"] = (2.5 if bc1_fired else 0.0, bc1_fired)

    # BC2: MACD > 0 (Daily) — 2.5 pts
    macd_val = macd_line.iloc[d_idx]
    bc2_fired = not np.isnan(macd_val) and macd_val > 0
    results["BC2"] = (2.5 if bc2_fired else 0.0, bc2_fired)

    return results


# =========================================================================
# Main scoring loop
# =========================================================================

def run_backtest(
    df_d: pd.DataFrame,
    df_4h: pd.DataFrame,
    df_w: pd.DataFrame,
    start_date: str,
    end_date: str,
    entry_threshold: float = 70,
    exit_threshold: float = 50,
) -> tuple[pd.DataFrame, list]:
    """Run the full Apollo scoring loop.

    Parameters
    ----------
    df_d, df_4h, df_w : pd.DataFrame
        Daily, 4H, weekly DataFrames with indicator aliases.
    start_date, end_date : str
        Inclusive date range (YYYY-MM-DD or parseable by pandas).
    entry_threshold, exit_threshold : float
        Override the module-level thresholds.

    Returns
    -------
    (daily_df, trades)
        daily_df — one row per trading day with scores + pool breakdowns.
        trades   — list of event dicts (entries/exits/holds).
    """
    # --- Pre-compute indicator series ---
    d_rsi21 = df_d["rsi21"]
    d_rsi36 = df_d["rsi36"]
    d_rsi56 = df_d["rsi56"]
    h_rsi21 = df_4h["rsi21"]
    h_rsi36 = df_4h["rsi36"]
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di = df_d["plus_di"]
    minus_di = df_d["minus_di"]
    macd_line = df_d["macd"]

    # --- Detect troughs ---
    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    # --- Pre-compute WC21 crossover prices for B6 ---
    crossover_prices: list[float | None] = []
    prev_above = False
    xover_price: float | None = None
    for i in range(len(df_4h)):
        c = df_4h["close"].iloc[i]
        w = df_4h["wc21"].iloc[i] if "wc21" in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    # --- Date range filtering ---
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    mask_arr = np.asarray(mask)
    daily_indices = np.where(mask_arr)[0]
    if len(daily_indices) == 0:
        return pd.DataFrame(), []

    # --- Main scoring loop ---
    daily_results: list[dict] = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]

        # Resolve 4H bar: strict <= (v6 behavior)
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])

        # Resolve weekly bar
        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])

        # Trough positions
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)

        # B6 crossover price
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None

        # Evaluate all signals
        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di, minus_di, macd_line,
            b6_xover,
        )

        # Aggregate pool points
        pool_pts: dict[str, float] = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(
                sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id
            )

        core = min(100, pool_pts["A"] + pool_pts["B"] + pool_pts["C"])
        bonus = pool_pts["BA"] + pool_pts["BB"] + pool_pts["BC"]
        total = core + bonus

        action, pos_pct = classify_score(total)

        daily_results.append({
            "date": bt_date,
            "close": df_d["close"].iloc[pos],
            "pool_a": pool_pts["A"],
            "pool_b": pool_pts["B"],
            "pool_c": pool_pts["C"],
            "bonus_a": pool_pts["BA"],
            "bonus_b": pool_pts["BB"],
            "bonus_c": pool_pts["BC"],
            "core": core,
            "bonus": bonus,
            "total": total,
            "action": action,
            "pos_pct": pos_pct,
            "signals": sigs,
            "d_trough_pos": d_trough_pos,
            "bars_from_trough": pos - d_trough_pos if d_trough_pos is not None else None,
            "rsi21": d_rsi21.iloc[pos],
        })

    # Build daily DataFrame (exclude signals dict)
    daily_df = pd.DataFrame(
        [{k: v for k, v in r.items() if k != "signals"} for r in daily_results]
    )
    if daily_df.empty:
        return daily_df, []

    # --- Trade extraction (default: NONE mode for backward compat) ---
    trades = extract_trades(
        daily_results, df_d,
        exit_mode="NONE",
        divergence_rsi_drop=DIVERGENCE_RSI_DROP,
        divergence_cooldown=DIVERGENCE_COOLDOWN,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
    )
    return daily_df, trades


# =========================================================================
# Trade extraction with selectable exit mode
# =========================================================================

def extract_trades(
    daily_results: list[dict],
    df_d: pd.DataFrame,
    exit_mode: str = "FIXED_SL",
    sl_percent: float = 5.0,
    divergence_rsi_drop: float = 3.0,
    divergence_cooldown: int = 5,
    exit_threshold: float = 50,
    entry_threshold: float = 70,
) -> list[dict]:
    """Extract trades from daily scoring results.

    Parameters
    ----------
    daily_results : list[dict]
        Output rows from ``run_backtest`` (must include 'signals' key).
    df_d : pd.DataFrame
        Daily OHLCV DataFrame (used for open/high lookups).
    exit_mode : str
        One of:
          - "NONE"         — score<exit_threshold + divergence exits only
          - "FIXED_SL"     — hard SL from entry (gap-down aware)
          - "TRAILING_SL"  — SL trails from peak close
          - "DI_CROSSOVER" — exit on +DI crossing below -DI
    sl_percent : float
        Stop-loss percentage for FIXED_SL / TRAILING_SL.
    divergence_rsi_drop : float
        RSI must drop this many pts below peak to trigger divergence exit.
    divergence_cooldown : int
        Trading days after any non-score exit before re-entry allowed.
    exit_threshold : float
        Score below which an in-trade position is exited.
    entry_threshold : float
        Score at or above which a new entry is allowed.

    Returns
    -------
    list[dict] — event dicts with keys: type, date, close, score, …
    """
    events: list[dict] = []
    in_trade = False
    entry_price: float | None = None
    entry_date = None
    cooldown_until: int | None = None

    peak_rsi: float | None = None
    peak_rsi_price: float | None = None
    peak_rsi_date = None
    peak_close: float | None = None

    prev_plus_di: float | None = None
    prev_minus_di: float | None = None

    sl_threshold_mult = 1.0 - sl_percent / 100.0 if sl_percent > 0 else 0.0

    for i, r in enumerate(daily_results):
        date = r["date"]
        score = r["total"]
        close = r["close"]
        rsi = r["rsi21"]
        action = r["action"]

        # Current open / DI from df_d
        try:
            open_price = df_d["open"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            open_price = close
        try:
            cur_plus_di = df_d["plus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_plus_di = np.nan
        try:
            cur_minus_di = df_d["minus_di"].iloc[df_d.index.get_loc(date)]
        except (KeyError, ValueError):
            cur_minus_di = np.nan

        # ============================================================ IN TRADE
        if in_trade:
            # Update trailing-SL peak
            if exit_mode == "TRAILING_SL" and close > peak_close:
                peak_close = close

            # 1. SL / crossover exit (highest precedence)
            trigger = None
            fill_price = None

            if exit_mode == "FIXED_SL" and sl_percent > 0:
                sl_price = entry_price * sl_threshold_mult
                if close <= sl_price or open_price <= sl_price:
                    fill_price = min(open_price, sl_price)
                    trigger = "FIXED_SL"

            elif exit_mode == "TRAILING_SL" and sl_percent > 0 and peak_close is not None:
                sl_price = peak_close * sl_threshold_mult
                if close <= sl_price or open_price <= sl_price:
                    fill_price = min(open_price, sl_price)
                    trigger = "TRAILING_SL"

            elif exit_mode == "DI_CROSSOVER":
                if (
                    prev_plus_di is not None
                    and prev_minus_di is not None
                    and not np.isnan(cur_plus_di)
                    and not np.isnan(cur_minus_di)
                    and prev_plus_di > prev_minus_di
                    and cur_plus_di < cur_minus_di
                ):
                    fill_price = close
                    trigger = "DI_CROSSOVER"

            if trigger is not None:
                pnl = (fill_price - entry_price) / entry_price * 100.0
                if trigger == "FIXED_SL":
                    reason = (
                        f"SL_HIT (-{sl_percent}% fixed from entry "
                        f"{entry_price:.2f}, fill ₹{fill_price:.2f})"
                    )
                    classification = "SL EXIT"
                elif trigger == "TRAILING_SL":
                    reason = (
                        f"TRAILING_SL (-{sl_percent}% from peak "
                        f"{peak_close:.2f}, fill ₹{fill_price:.2f})"
                    )
                    classification = "TRAILING SL EXIT"
                elif trigger == "DI_CROSSOVER":
                    reason = (
                        f"DI_CROSSOVER (+DI {prev_plus_di:.1f}→{cur_plus_di:.1f}, "
                        f"-DI {prev_minus_di:.1f}→{cur_minus_di:.1f})"
                    )
                    classification = "DI CROSSOVER EXIT"
                else:
                    reason = trigger
                    classification = "EXIT"

                events.append({
                    "type": "EXIT",
                    "date": date,
                    "close": fill_price,
                    "score": round(score, 2),
                    "classification": classification,
                    "entry_price": entry_price,
                    "entry_date": entry_date,
                    "pnl": round(pnl, 2),
                    "exit_reason": reason,
                    "bars_from_trough": r["bars_from_trough"],
                    "pool_a": round(r["pool_a"], 2),
                    "pool_b": round(r["pool_b"], 2),
                    "pool_c": round(r["pool_c"], 2),
                    "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"], 2),
                })
                in_trade = False
                cooldown_until = i + divergence_cooldown
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di
                prev_minus_di = cur_minus_di
                continue

            # 2. Divergence exit
            if peak_rsi is not None and rsi > peak_rsi:
                peak_rsi = rsi
                try:
                    peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
                except (KeyError, ValueError):
                    peak_rsi_price = close
                peak_rsi_date = date

            if (
                peak_rsi is not None
                and peak_rsi_price is not None
                and close > peak_rsi_price
                and rsi < (peak_rsi - divergence_rsi_drop)
            ):
                pnl = (close - entry_price) / entry_price * 100.0
                rsi_drop = round(peak_rsi - rsi, 2)
                strength = "STRONG" if rsi_drop > 5 else "MODERATE"
                events.append({
                    "type": "EXIT",
                    "date": date,
                    "close": close,
                    "score": round(score, 2),
                    "classification": "DIVERGENCE EXIT",
                    "entry_price": entry_price,
                    "entry_date": entry_date,
                    "pnl": round(pnl, 2),
                    "exit_reason": (
                        f"DIVERGENCE ({strength}, RSI {peak_rsi:.2f}→{rsi:.2f}, "
                        f"drop={rsi_drop}pts)"
                    ),
                    "bars_from_trough": r["bars_from_trough"],
                    "pool_a": round(r["pool_a"], 2),
                    "pool_b": round(r["pool_b"], 2),
                    "pool_c": round(r["pool_c"], 2),
                    "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"], 2),
                })
                in_trade = False
                cooldown_until = i + divergence_cooldown
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di
                prev_minus_di = cur_minus_di
                continue

            # 3. Score-based exit
            if score < exit_threshold:
                pnl = (close - entry_price) / entry_price * 100.0
                events.append({
                    "type": "EXIT",
                    "date": date,
                    "close": close,
                    "score": round(score, 2),
                    "classification": "EXIT",
                    "entry_price": entry_price,
                    "entry_date": entry_date,
                    "pnl": round(pnl, 2),
                    "exit_reason": "SCORE<50",
                    "bars_from_trough": r["bars_from_trough"],
                    "pool_a": round(r["pool_a"], 2),
                    "pool_b": round(r["pool_b"], 2),
                    "pool_c": round(r["pool_c"], 2),
                    "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"], 2),
                })
                in_trade = False
                peak_rsi = None
                peak_rsi_price = None
                peak_rsi_date = None
                peak_close = None
                prev_plus_di = cur_plus_di
                prev_minus_di = cur_minus_di
                continue

            # 4. Hold
            if score >= 90:
                hold_type = "HOLD-FULL STRONG"
            elif score >= 80:
                hold_type = "HOLD-FULL"
            elif score >= 70:
                hold_type = "HOLD-STD"
            else:
                hold_type = "WATCHLIST"
            events.append({
                "type": hold_type,
                "date": date,
                "close": close,
                "score": round(score, 2),
                "classification": action,
                "entry_price": entry_price,
                "entry_date": entry_date,
                "bars_from_trough": r["bars_from_trough"],
                "pool_a": round(r["pool_a"], 2),
                "pool_b": round(r["pool_b"], 2),
                "pool_c": round(r["pool_c"], 2),
                "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"], 2),
            })
            prev_plus_di = cur_plus_di
            prev_minus_di = cur_minus_di
            continue

        # ======================================================== NOT IN TRADE
        if not in_trade and score >= entry_threshold:
            if cooldown_until is not None and i < cooldown_until:
                prev_plus_di = cur_plus_di
                prev_minus_di = cur_minus_di
                continue

            in_trade = True
            entry_price = close
            entry_date = date
            peak_rsi = rsi
            try:
                peak_rsi_price = df_d["high"].iloc[df_d.index.get_loc(date)]
            except (KeyError, ValueError):
                peak_rsi_price = close
            peak_rsi_date = date
            peak_close = close
            events.append({
                "type": "ENTRY",
                "date": date,
                "close": close,
                "score": round(score, 2),
                "classification": action,
                "entry_price": close,
                "entry_date": date,
                "bars_from_trough": r["bars_from_trough"],
                "pool_a": round(r["pool_a"], 2),
                "pool_b": round(r["pool_b"], 2),
                "pool_c": round(r["pool_c"], 2),
                "bonus": round(r["bonus_a"] + r["bonus_b"] + r["bonus_c"], 2),
            })

        prev_plus_di = cur_plus_di
        prev_minus_di = cur_minus_di

    # --- Period-end exit for any open trade ---
    if in_trade and daily_results:
        last = daily_results[-1]
        pnl = (last["close"] - entry_price) / entry_price * 100.0
        events.append({
            "type": "EXIT",
            "date": last["date"],
            "close": last["close"],
            "score": round(last["total"], 2),
            "classification": "EXIT",
            "entry_price": entry_price,
            "entry_date": entry_date,
            "pnl": round(pnl, 2),
            "exit_reason": "PERIOD_END",
            "bars_from_trough": last["bars_from_trough"],
            "pool_a": round(last["pool_a"], 2),
            "pool_b": round(last["pool_b"], 2),
            "pool_c": round(last["pool_c"], 2),
            "bonus": round(last["bonus_a"] + last["bonus_b"] + last["bonus_c"], 2),
        })

    return events


# =========================================================================
# High-level: load → score → extract → KPIs
# =========================================================================

def run_stock_backtest(
    data_dir: str,
    symbol: str,
    start_date: str,
    end_date: str,
    exit_mode: str = "FIXED_SL",
    sl_percent: float = 5.0,
    entry_threshold: float = 70,
    exit_threshold: float = 50,
) -> dict:
    """End-to-end backtest for one stock.

    Steps:
      1. Load data via ``eod2_loader.load_eod2_stock``.
      2. Run ``run_backtest`` to get daily scores.
      3. Run ``extract_trades`` with the chosen exit mode.
      4. Compute KPIs (cum_pnl, win_rate, max_drawdown, …).

    Returns
    -------
    dict with keys: symbol, exit_mode, daily_df, trades, cum_pnl,
    win_rate, avg_pnl_per_trade, max_drawdown, n_trades, sl_exits,
    div_exits, score_exits, period_end_exits, entries, completed.
    """
    from .eod2_loader import load_eod2_stock

    # (a) Load
    df_d, df_4h, df_w = load_eod2_stock(data_dir, symbol)

    # (b) Score
    daily_df, _default_trades = run_backtest(
        df_d, df_4h, df_w, start_date, end_date,
        entry_threshold=entry_threshold,
        exit_threshold=exit_threshold,
    )
    if daily_df.empty:
        return {
            "symbol": symbol,
            "exit_mode": exit_mode,
            "daily_df": daily_df,
            "trades": [],
            "cum_pnl": 0.0,
            "win_rate": 0.0,
            "avg_pnl_per_trade": 0.0,
            "max_drawdown": 0.0,
            "n_trades": 0,
            "sl_exits": [],
            "div_exits": [],
            "score_exits": [],
            "period_end_exits": [],
            "entries": [],
            "completed": [],
        }

    # Re-extract trades with the requested exit mode.
    # We need the full daily_results (with signals) — rebuild from run_backtest
    # or re-run with the exit mode integrated.
    # Simplest: re-run scoring (it's fast) and then extract.
    # But run_backtest already did the scoring loop. We just need the raw
    # daily_results list. Let's re-run the scoring part to get it.

    # Actually, we already have daily_df but it lacks the 'signals' key.
    # Re-run run_backtest internal logic to get daily_results with signals.
    # To avoid code duplication, we'll re-call run_backtest and ignore its
    # trades, then call extract_trades separately.

    # For efficiency, we can re-run just the scoring part:
    d_rsi21 = df_d["rsi21"]
    d_rsi36 = df_d["rsi36"]
    h_rsi21 = df_4h["rsi21"]
    h_rsi36 = df_4h["rsi36"]
    w_rsi21 = compute_weekly_rsi(df_w, 21)
    w_rsi56 = compute_weekly_rsi(df_w, 56)
    plus_di_s = df_d["plus_di"]
    minus_di_s = df_d["minus_di"]
    macd_line_s = df_d["macd"]

    d_troughs = detect_troughs(d_rsi21, 40.0, 11)
    h_troughs = detect_troughs(h_rsi21, 38.0, 5)

    crossover_prices: list[float | None] = []
    prev_above = False
    xover_price: float | None = None
    for i in range(len(df_4h)):
        c = df_4h["close"].iloc[i]
        w = df_4h["wc21"].iloc[i] if "wc21" in df_4h.columns else np.nan
        if np.isnan(c) or np.isnan(w):
            prev_above = False
            crossover_prices.append(None)
            continue
        cur_above = c > w
        if cur_above and not prev_above:
            xover_price = c
        elif not cur_above:
            xover_price = None
        prev_above = cur_above
        crossover_prices.append(xover_price)

    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)
    mask = (df_d.index >= start_ts) & (df_d.index <= end_ts)
    daily_indices = np.where(np.asarray(mask))[0]

    daily_results: list[dict] = []
    for pos in daily_indices:
        bt_date = df_d.index[pos]
        mask_4h = df_4h.index <= bt_date
        if not mask_4h.any():
            continue
        h_idx = int(np.where(np.asarray(mask_4h))[0][-1])
        mask_w = df_w.index <= bt_date
        if not mask_w.any():
            continue
        w_idx = int(np.where(np.asarray(mask_w))[0][-1])
        d_trough_pos = get_latest_trough_pos(d_troughs, pos)
        h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
        b6_xover = crossover_prices[h_idx] if h_idx < len(crossover_prices) else None

        sigs = eval_signals(
            df_d, df_4h, df_w, pos, h_idx, w_idx,
            d_trough_pos, h_trough_pos,
            d_rsi21, d_rsi36, h_rsi21, h_rsi36,
            w_rsi21, w_rsi56,
            plus_di_s, minus_di_s, macd_line_s,
            b6_xover,
        )

        pool_pts: dict[str, float] = {}
        for pool_id in POOL_ORDER:
            pool_pts[pool_id] = sum(
                sigs[sid][0] for sid, _, pool, _ in SIGNAL_DEFS if pool == pool_id
            )
        core = min(100, pool_pts["A"] + pool_pts["B"] + pool_pts["C"])
        bonus = pool_pts["BA"] + pool_pts["BB"] + pool_pts["BC"]
        total = core + bonus
        action, pos_pct = classify_score(total)

        daily_results.append({
            "date": bt_date,
            "close": df_d["close"].iloc[pos],
            "pool_a": pool_pts["A"],
            "pool_b": pool_pts["B"],
            "pool_c": pool_pts["C"],
            "bonus_a": pool_pts["BA"],
            "bonus_b": pool_pts["BB"],
            "bonus_c": pool_pts["BC"],
            "core": core,
            "bonus": bonus,
            "total": total,
            "action": action,
            "pos_pct": pos_pct,
            "signals": sigs,
            "d_trough_pos": d_trough_pos,
            "bars_from_trough": pos - d_trough_pos if d_trough_pos is not None else None,
            "rsi21": d_rsi21.iloc[pos],
        })

    # (c) Extract trades with the chosen exit mode
    trades = extract_trades(
        daily_results, df_d,
        exit_mode=exit_mode,
        sl_percent=sl_percent,
        divergence_rsi_drop=DIVERGENCE_RSI_DROP,
        divergence_cooldown=DIVERGENCE_COOLDOWN,
        exit_threshold=exit_threshold,
        entry_threshold=entry_threshold,
    )

    # (d) KPIs
    entries = [e for e in trades if e["type"] == "ENTRY"]
    exits = [e for e in trades if e["type"] == "EXIT"]
    completed = [e for e in exits if "pnl" in e and e.get("exit_reason") != ""]
    cum_pnl = sum(e["pnl"] for e in completed) if completed else 0.0
    winning = [e for e in completed if e["pnl"] > 0]
    win_rate = round(len(winning) / len(completed) * 100, 1) if completed else 0.0
    avg_pnl = round(cum_pnl / len(completed), 2) if completed else 0.0

    sl_exits = [
        e for e in exits
        if "SL_HIT" in e.get("exit_reason", "") or "TRAILING_SL" in e.get("exit_reason", "")
    ]
    div_exits = [e for e in exits if "DIVERGENCE" in e.get("exit_reason", "")]
    score_exits = [e for e in exits if e.get("exit_reason") == "SCORE<50"]
    period_end_exits = [e for e in exits if e.get("exit_reason") == "PERIOD_END"]

    # Max drawdown from peak cumulative P&L
    pnl_series = [e["pnl"] for e in completed]
    if pnl_series:
        cum = np.cumsum(pnl_series)
        running_max = np.maximum.accumulate(cum)
        drawdowns = cum - running_max
        max_dd = round(float(min(drawdowns)) if len(drawdowns) > 0 else 0.0, 2)
    else:
        max_dd = 0.0

    return {
        "symbol": symbol,
        "exit_mode": exit_mode,
        "daily_df": daily_df,
        "trades": trades,
        "cum_pnl": cum_pnl,
        "win_rate": win_rate,
        "avg_pnl_per_trade": avg_pnl,
        "max_drawdown": max_dd,
        "n_trades": len(completed),
        "sl_exits": sl_exits,
        "div_exits": div_exits,
        "score_exits": score_exits,
        "period_end_exits": period_end_exits,
        "entries": entries,
        "completed": completed,
    }